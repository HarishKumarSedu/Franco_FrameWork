# ----------------------------------------------------------------------------
# swire.py
# Gabriel Seitz
# 2017-2-14
# contains functions for the SoundWire communication class
# ----------------------------------------------------------------------------

# Imports
# ----------------------------------------------------------------------------
from ...utilities import repack
# ----------------------------------------------------------------------------


# Definitions
# ----------------------------------------------------------------------------
class SoundWire(object):
    """Communication class for SoundWire. A handle (send function) must be assigned to perform writes, reads and pings.

    """

    def __init__(self, send=None, dev_addr=0, map_size=2, little_endian=True, check_busy=False, indirect=False, verbose=False):
        """Instantiate a SoundWire object.

        Args:
            send (func): method that can send and receive writes, reads and pings
            num (int): Device Address={} assigned through enumeration
            map_size (int): number of bytes of the memory address pointer
            little_endian (bool): True for data bytes in the order of LSB to MSB, False for MSB to LSB
            verbose (bool): option to print detailed information
            check_busy(bool): True to wait for CMD_IN_PROGRESS, False to skip
            indirect(bool): True to perform an indirect transaction, False for direct

        Returns:
            SoundWire: SoundWire handle.

        """
        self._verbose = verbose
        self._send = send
        self._dev_addr = dev_addr
        self._map_size = map_size
        self._little_endian = little_endian
        self._check_busy = check_busy
        self._indirect = indirect

    def set_verbose(self, state):
        """Control printing behavior.

        Args:
            state (int, bool): turn on or off verbose print statements

        """
        self._verbose = True if state else False

    def set_handle(self, send, num):
        """Set the 'send' handle.

        Args:
            send (obj): function that can send and receive writes, reads and pings
            num (int): Device Address={} assigned through enumeration

        """
        if num is None:
            raise RuntimeError("DevAddr = None")

        self._send = send
        self._dev_addr = num

    def set_bulk_handle(self, send_bulk, num):
        """Set the 'bulk transport protocol handle.

        Args:
            send_bulk (obj): bulk register access function that can send and read
            num (int): Device Address assigned through enumeration
        """
        if num is None:
            raise RuntimeError("DevAddr = None")

        self._send_bulk = send_bulk

        if self._dev_addr is None:
            self._dev_addr = num
        elif self._dev_addr != num:
            raise RuntimeError("Device already enumerated as "+hex(self._dev_addr))
        else:  # self._dev_addr == num
            pass

    def extend_address(self, addr_high=None, addr_low=None):
        """Program the registers which extend the register address per the MiPi spec.

        Args:
            addr_high (int): value to set ADDRESS_HIGH
            addr_low (int): value to set ADDRESS_LOW

        """
        if addr_high is not None:
            self.write(0x48, addr_high, word_size=1)

        if addr_low is not None:
            self.write(0x49, addr_low, word_size=1)

    def write(self, register, value, word_size=1):
        """Write a single value to a register.

        Args:
            register (int): register address (lowest 2 bytes)
            value (int): value to write
            word_size (int): number of bytes per data element

        """
        if self._check_busy:
            while (self.read(0xd0) & 0x4) != 0:
                print("Waiting for CMD_IN_PROGRESS...")

        if word_size > 1:
            value_bytes = repack.int_to_array(value, word_size, invert=self._little_endian)
            self.write_block(register, value_bytes, word_size=1)  # treat word as a write_block with 4 values
        else:
            self._send(3, self._dev_addr, register, value)
            if self._verbose:
                print("SWIRE Write: Device Address={}; Register Address={:#x}; Value={:#x};".format(self._dev_addr, register, value))

    def write_block(self, register, values, word_size=1):
        """Write multiple values to a starting register location.

        Args:
            register (int): starting register address
            values (list of ints): values to write
            word_size (int): number of bytes per data element

        """
        for i, value in enumerate(values):
            self.write(register+i, value, word_size=word_size)  # increment register and call write()

    def write_bulk(self, register, values):
        """Write multiple byte to a starting register location using Bulk Register Access.

        Args:
            register (int): Starting register address
            length (int): Number of bytes to read
            dev_reg (book): True - Device register or False - SWIRE register

        Returns:
            None

        """
        length = len(values)
        self._send_bulk(1, self._dev_addr, register, length, values)
        return

    def read_bulk(self, register, length):
        """Read multiple bytes from a starting register location using Bulk Register Access.

        Args:
            register (int): Starting register address
            length (int): Number of bytes to read
            dev_reg (book): True - Device register or False - SWIRE register

        Returns:
            dataread (list): List of bytes read back

        """
        return self._send_bulk(0, self._dev_addr, register, length)

    def read(self, register, word_size=1):
        """Read from a single register.

        Args:
            register (int): register address
            word_size (int): number of bytes per data element

        Returns:
            value (int): value of the register

        """
        if self._check_busy:
            while (self.read(0xd0) & 0x4) != 0:
                print("Waiting for CMD_IN_PROGRESS...")

        if self._indirect:
            value = self._send(2, self._dev_addr, register)  # try read
            status = self.read(0xd0)
            if (status & 0x4) != 0 or word_size > 1:  # check for LAST_LATE
                while (status & 0x3) != 3:
                    print("Waiting for CMD_DONE and RDATA_RDY...")
                    status = self.read(0xd0)
                if word_size > 1:
                    value = self.read(0xd8) | (self.read(0xd9) << 8) | (self.read(0xda) << 16) | (self.read(0xdb) << 24)
                else:
                    value = self.read(0xd8)
            else:
                if self._verbose:
                    print("SWIRE Read: Device Address={}; Register Address={:#x}; Value={:#x};".format(self._dev_addr, register, value))
        else:
            if word_size > 1:
                value_bytes = self.read_block(register, 4, word_size=1)
                if self._little_endian:
                    value_bytes.reverse()
                value = repack.array_to_int(value_bytes)
            else:
                value = self._send(2, self._dev_addr, register)
                if self._verbose:
                    print("SWIRE Read: Device Address={}; Register Address={:#x}; Value={:#x};".format(self._dev_addr, register, value))

        return value

    def read_block(self, register, num=1, word_size=1):
        """Read multiple values from a starting register location.

        Args:
            register (int): starting register address
            num (int): number of registers to read
            word_size (int): number of bytes per data element

        Returns:
            values (list of ints): values of the registers

        """
        data_in = []
        for i in range(num * word_size):
            value = self.read(register+i)
            data_in.append(value)

        # reformat byte array to word array
        values = repack.array_to_array(data_in, word_size, invert=True)

        return values

    def configure_data_port(self, base, config, num_ch, bank=None):
        """Configure the frame shape. Updates "active_bank" variable.

        Args:
            base (int): starting address of data port registers
            config (dict): contains settings for 'word_length', 'sample_interval', 'offset1', 'offset2', 'hstart', 'hstop'
            num_ch (int): number of channels to enable
            bank (int): bank to configure, can be forced to 0 or 1

        """
        # Unless user specified, configure inactive bank
        if bank is None:
            bank = 1 if self.read(0x44) & 0x40 == 0 else 0

        # number of bits
        self.write(base+0x03, config['word_length']-1)

        # SAMPLE_INTERVAL_LOW
        self.write(base+0x22+bank*0x10, (config['sample_interval']-1) & 0xff)

        # SAMPLE_INTERVAL_HIGH
        self.write(base+0x23+bank*0x10, ((config['sample_interval']-1) & 0xff00) >> 8)

        # OFFSET1
        self.write(base+0x24+bank*0x10, config['offset1'])

        # OFFSET2
        self.write(base+0x25+bank*0x10, config['offset2'])

        # HSTART and HSTOP
        val = (config['hstart'] << 4) | config['hstop']
        self.write(base+0x26+bank*0x10, val)

        # Prepare Channels
        val = sum([1 << i for i in range(num_ch)])
        self.write(base+0x5, val)

        # Enable Channels
        val = sum([1 << i for i in range(num_ch)])
        self.write(base+0x20+bank*0x10, val)
# ----------------------------------------------------------------------------

# ----------------------------------------------------------------------------
# compatability.py
# Gabriel Seitz
# 2018-5-30
# contains methods to maintain compatability between Python2 and Python3
# ----------------------------------------------------------------------------

# Imports
# ----------------------------------------------------------------------------
# try:
#     py_ver = sys.version_info
# except NameError:
#     import sys
#     py_ver = sys.version_info
#     del(sys)
# ----------------------------------------------------------------------------

# Definitions
# ----------------------------------------------------------------------------
try:
    xrange
except NameError:
    xrange = range

try:
    long
except NameError:
    long = int
# ----------------------------------------------------------------------------

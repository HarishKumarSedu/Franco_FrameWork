# ----------------------------------------------------------------------------
# gpio.py
# Gabriel Seitz
# 2018-07-30
# contains the communication class that implements the CirrusLink GPIO protocol
# ----------------------------------------------------------------------------

# Imports
# ----------------------------------------------------------------------------
# ----------------------------------------------------------------------------

# Definitions
# ----------------------------------------------------------------------------
class GPIO(object):
    """Communication class for GPIO.

    """

    def __init__(self, pin, direction='preserve', verbose=False):
        """Instantiate an GPIO object.

        Args:
            clink (obj): CirrusLinkClient object
            pin (int): number corresponding to pin, can be 0-31
            direction (str): pin direction, can be "in", "out", "high", "low", or "preserve"
            verbose (bool): option to print detailed information

        Returns:
            GPIO: gpio handle

        """
        self._verbose = verbose
        self._pin = pin
        self._cache = {}
        
        direction = direction.lower()
            
        if direction in ['in', 'input', 'hiz', 'hi-z']:
            self.set_direction(0)
        
        if direction == 'low':
            self.write(0)
        if direction == 'high':
            self.write(1)
            
        if direction in ['out', 'output', 'high', 'low']:
            self.set_direction(1)


    def set_verbose(self, state):
        """Control printing behavior

        Args:
            state (int, bool): turn on or off verbose print statements

        """
        self._verbose = True if state else False
    
    
    def set_direction(self, direction):
        """configure the input/output direction of the GPIO pin

        Args:
            direction (str, int, bool): can be 'out'=1 or 'in'=0

        """
        if isinstance(direction, str):
            if direction.lower() in ['out', 'output']:
                direction = 1
            if direction.lower() in ['in', 'input', 'hiz', 'hi-z']:
                direction = 0
        
        self._cache['direction'] = direction

        if self._verbose:
            print("GPIO Configuration: Pin = {}; Direction = {}".format(self._pin, direction))

    
    def write(self, state):
        """Set the output state. The direction must be set to output.

        Args:
            state (int, bool): drive pin high/low

        """
        self._cache['state'] = state

        if self._verbose:
            print("GPIO Write: Pin = {}; State = {}".format(self._pin, state))
        
    
    def read(self):
        """Get the current state

        Returns:
            state (int): high/low status of pin

        """
        state = self._cache['state']

        if self._verbose:
            print("GPIO Read: Pin = {}; State = {}".format(self._pin, state))

        return state
# ----------------------------------------------------------------------------
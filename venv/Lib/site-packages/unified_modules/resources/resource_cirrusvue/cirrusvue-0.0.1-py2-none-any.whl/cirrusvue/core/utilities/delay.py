# ----------------------------------------------------------------------------
# delay.py
# Gabriel Seitz
# 2018-5-29
# contains set of common functions that could be useful
# ----------------------------------------------------------------------------

# Imports
# ----------------------------------------------------------------------------
from time import sleep
# ----------------------------------------------------------------------------

# Definitions
# ---------------------------------------------------------------------------- 
def delay_h(hours):
    """Sleep for the specified number of hours.

    Args:
        hours (int, long, float): duration in hours.

    """
    sleep(hours*60*60)

def delay_m(minutes):
    """Sleep for the specified number of minutes.

    Args:
        minutes (int, long, float): duration in minutes.

    """
    sleep(minutes*60)


def delay_s(seconds):
    """Sleep for the specified number of seconds.

    Args:
        seconds (int, long, float): duration in seconds.

    """
    sleep(seconds)


def delay_ms(milliseconds):
    """Sleep for the specified number of milliseconds.

    Args:
        milliseconds (int, long, float): duration in milliseconds.

    """
    sleep(milliseconds / 1000.0)

    
def delay_us(microseconds):
    """Sleep for the specified number of microseconds.

    Args:
        microseconds (int, long, float): duration in microseconds.

    """
    sleep(microseconds / 1000000.0)
# ----------------------------------------------------------------------------


















































































# ----------------------------------------------------------------------------
# i2c.py
# Gabriel Seitz
# 2018-07-30
# contains the communication class that implements the Virtual I2C protocol
# ----------------------------------------------------------------------------

# Imports
# ----------------------------------------------------------------------------
# ----------------------------------------------------------------------------

# Definitions
# ----------------------------------------------------------------------------
class I2C(object):
    """Communication class for I2C. 

    """

    def __init__(self, bus, i2c_addr, map_size=1, word_size=1, bus_speed=0, repeated_start=True, verbose=False):
        """Instantiate an I2C object.

        Args:
            bus (int): I2C bus number, for the AudioHub: "0"=3.3V external, "1"=high speed DUT, "2"=internal SOM, "3"=internal AudioHub
            i2c_addr (int): 8bit I2C address
            bus_speed (int): clock rate, can be "0"=100kHz, "1"=400kHz, "2"=1MHz, "3"=20kHz.
            map_size (int): number of bytes in the memory address pointer
            repeated_start (bool): True to read using a repeated start condition, False for stop-start
            verbose (bool): option to print detailed information

        Returns:
            I2C: i2c handle.

        """
        self._verbose = verbose
        self._i2c_addr = i2c_addr
        self._bus = bus
        self._bus_speed = bus_speed
        self._map_size = map_size
        self._word_size = word_size
        self._repeated_start = repeated_start
        self._cache = {}
        self._addr_stride = 1


    def set_verbose(self, state):
        """Control printing behavior

        Args:
            state (int, bool): turn on or off verbose print statements

        """
        self._verbose = True if state else False


    def write(self, address, value):
        """Write a single value to a register.

        Args:
            address (int): register address
            value (int): value to write

        """
        self.write_block(address, [value])
        

    def write_block(self, address, values):
        """Write multiple values to a starting register location.

        Args:
            address (int): starting register address
            values (list of ints): values to write

        """
        for i, value in enumerate(values):
            self._cache[address + i*self._addr_stride] = value

        if self._verbose:
            if len(values) == 1:
                value = values[0]
                print("I2C Write: Bus={0}; I2C Address=0x{1:02x}; Register Address=0x{2:0{3}x}; Value=0x{4:0{5}x};".format(self._bus, self._i2c_addr, address, self._map_size*2, value, self._word_size*2))
            else:
                print("I2C Write: Bus={0}; I2C Address=0x{1:02x}; Register Address=0x{2:0{3}x};".format(self._bus, self._i2c_addr, address, self._map_size*2))
                for value in values:
                    print("\tValue=0x{0:0{1}x};".format(value, self._word_size*2))


    def read(self, address):
        """Read from a single register.

        Args:
            address (int): register address

        Returns:
            value (int): value of the register

        """
        values = self.read_block(address, length=1)
        value = values[0]
        return value


    def read_block(self, address, length=1):
        """Read multiple values from a starting register location.

        Args:
            address (int): starting register address
            length (int): number of registers to read

        Returns:
            values (list of ints): values of the registers

        """
        values = [self._cache[address + i*self._addr_stride] for i in range(length)]

        if self._verbose:
            if len(values) == 1:
                value = values[0]
                print("I2C Read: Bus={0}; I2C Address=0x{1:02x}; Register Address=0x{2:0{3}x}; Value=0x{4:0{5}x};".format(self._bus, self._i2c_addr, address, self._map_size*2, value, self._word_size*2))
            else:
                print("I2C Read: Bus={0}; I2C Address=0x{1:02x}; Register Address=0x{2:0{3}x};".format(self._bus, self._i2c_addr, address, self._map_size*2))
                for value in values:
                    print("\tValue={0:#0{1}x};".format(value, self._word_size*2))

        return values
# ----------------------------------------------------------------------------
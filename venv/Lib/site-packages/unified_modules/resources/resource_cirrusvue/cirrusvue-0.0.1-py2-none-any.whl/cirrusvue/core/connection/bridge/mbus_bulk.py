# ----------------------------------------------------------------------------
# mbus_bulk.py
# Gabriel Seitz
# 2017-5-17
# contains functions for the (mostly untested) MikeyBus Bulk class
# ----------------------------------------------------------------------------

# Definitions
# ----------------------------------------------------------------------------
class MikeyBusBulk(object):
    """Communication class for MikeyBus Bulk.
    Uses handles from the host to transmit and receive bulk packets.

    """

    def __init__(self, transmit, receive, wait_time=10, verbose=False):
        """Instantiate a MikeyBus Bulk object.

        Args:
            transmit (func): method to send downlink packet with inputs pkt_type (int), payload (list), fid (int)
            receive (func): method to wait for and get uplink packet, returns payload (list)
            wait_time (int, float): default time to wait for device initiated packets
            verbose (bool): option to print detailed information

        Returns:
            MikeyBusBulk: MikeyBus Bulk handle.

        """
        self._verbose = verbose
        self._tx = transmit
        self._rx = receive
        self._wait_time = wait_time


    def set_verbose(self, state):
        """Control printing behavior

        Args:
            state (int, bool): turn on or off verbose print statements

        """
        self._verbose = True if state else False


    def set_handle(self, transmit, receive):
        """Pass handles from the MikeyBus Host to perform Bulk

        Args:
            transmit (func): method to send downlink packet with inputs pkt_type (int), payload (list) and fid (int)
            receive (func): method to wait for and get uplink packet, returns payload (list)

        """
        self._tx = transmit
        self._rx = receive
        
        
    def write(self, endpoint, base_cmd, cmd_data):
        """Perform a vendor specific Set command (fid=0xff)

        Args:
            endpoint (int): target endpoint
            base_cmd (int): base command (register)
            cmd_data (int, list of int): data to write

        """
        # if int, convert to list
        data = cmd_data if type(cmd_data) is list else [cmd_data]
        
        # create vendor-specific payload (Set) and send designator
        self._tx(pkt_type=0, fid=0xff, payload=[3+len(data), base_cmd|3, endpoint] + data)
        
        
    def read(self, endpoint, base_cmd, cmd_data=None):
        """Perform a vendor specific Get command (fid=0xff) then Ret

        Args:
            endpoint (int): target endpoint
            base_cmd (int): base command (register)
            cmd_data (list of int): data to write
            
        Return:
            cmd_data (int, list of int): data read back, multiple bytes are returned as a list

        """
        # send designator (Get)
        if cmd_data is None:
            self._tx(pkt_type=0, fid=0xff, payload=[3, base_cmd|1, endpoint])
        else:
            self._tx(pkt_type=0, fid=0xff, payload=[3+len(cmd_data), base_cmd|1, endpoint] + cmd_data)
        
        # receive designator (Ret)
        payload = self._rx()
        
        # check for errors
        if payload[0] != len(payload) or payload[1] != base_cmd|2 or payload[2] != endpoint:
            raise RuntimeError("Device returned unexpected response")
        
        # grab value
        cmd_data = payload[3:]
        
        if len(cmd_data) is 1:
            cmd_data = cmd_data[0]
            
        return cmd_data
        
        
    def GetDevInfo(self):
        """Issue a GetDevInfo and receive the RetDevInfo

        Returns:
            dev_info (list of int): Unicode Encoded String

        """
        self._tx(pkt_type=0, fid=0x00, payload=[0x02, 0x01])
        payload = self._rx()

        if payload[0] != len(payload) or payload[1] != 0x02:
            raise RuntimeError("Device returned unexpected response")

        dev_info = payload[2:]

        return dev_info


    def GetStrDesignator(self, string_index):
        """Issue a GetStrDesignator and receive the RetStrDesignator

        Args:
            string_index (int): string index value

        Returns:
            str_designator (list of int): Unicode Encoded String

        """
        self._tx(pkt_type=0, fid=0x00, payload=[0x03, 0x03, string_index])
        payload = self._rx()

        if payload[0] != len(payload) or payload[1] != 0x04 or payload[2] != string_index:
            raise RuntimeError("Device returned unexpected response")

        str_designator = payload[3:]

        return str_designator


    def GetConfiguration(self, config_number):
        """Issue a GetConfiguration and receive the RetConfiguration

        Args:
            config_number (int): configuration number

        Returns:
            config_class (int): Configuration Class
            config_subclass (int): Configuration Subclass
            function_groups (list of int): Function Group Type [1:N]

        """
        self._tx(pkt_type=0, fid=0x00, payload=[0x03, 0x05, config_number])
        payload = self._rx()

        if payload[0] != len(payload) or payload[1] != 0x06:
            raise RuntimeError("Device returned unexpected response")

        config_class = payload[2]
        config_subclass = payload[3]
        function_groups = payload[5:]

        return config_class, config_subclass, function_groups


    def SetConfiguration(self, config_id):
        """Issue a SetConfiguration

        Args:
            config_id (int): Configuration ID

        """
        self._tx(pkt_type=0, fid=0x00, payload=[0x03, 0x07, config_id])


    def GetFunctionGroupProperties(self, fid):
        """Issue a GetFunctionGroupProperties and receive the RetFunctionGroupProperties

        Args:
            fid (int): Function Group ID

        Returns:
            property_id (list of int): Property ID

        """
        self._tx(pkt_type=0, payload=[0x03, 0x0b, fid])
        payload = self._rx()

        if payload[0] != len(payload) or payload[1] != 0x0c:
            raise RuntimeError("Device returned unexpected response")

        property_id = payload[2:]

        return property_id


    def GetFunctionGroupPropertyInfo(self, fid, property_id):
        """Issue a GetFunctionGroupProperties and receive the RetFunctionGroupProperties

        Args:
            fid (int): Function Group ID
            property_id (int): Property ID

        Returns:
            info (list of int): property information in Function Group-specific format

        """
        self._tx(pkt_type=0, payload=[0x04, 0x0b, fid, property_id])
        payload = self._rx()

        if payload[0] != len(payload) or payload[1] != 0x0c:
            raise RuntimeError("Device returned unexpected response")

        info = payload[2:]

        return info


    def SetFunctionGroupPropertyInfo(self, fid, property_id, info):
        """Issue a SetFunctionGroupPropertyInfo

        Args:
            fid (int): Function Group ID
            property_id (int): Property ID
            info (list of int): property information in Function Group-specific format

        """
        self._tx(pkt_type=0, payload=[4+len(info), 0x0b, fid, property_id] + info)

        try:  # wait for a possible RetFunctionGroupPropertyChanged
            payload = self._rx()
        except RuntimeError:
            pass

        if payload[0] != 4 or payload[1] != 0x10 or payload[3] != fid or payload[4] != property_id:
            raise RuntimeError("Device returned unexpected response")


    def GetErrorStatus(self):
        """Issue a GetErrorStatus and receive the RetErrorStatus

        Returns:
            status (list of int): error status packet

        """
        self._tx(pkt_type=0, payload=[0x02, 0x08])
        payload = self._rx()

        if payload[0] != len(payload) or payload[1] != 0x09:
            raise RuntimeError("Device returned unexpected response")

        status = payload[2:]

        return status


    def ResetErrorStatus(self):
        """Issue a ResetErrorStatus

        """
        self._tx(pkt_type=0, payload=[0x02, 0x0a])


    def HostRetErrorStatus(self, info):
        """Receive a HostGetErrorStatus and issue a HostRetErrorStatus

        Args:
            info (list of int): error status packet (bytes 3:N)

        """
        payload = self._rx(timeout=self._wait_time)

        if payload[0] != 0x02 or payload[1] != 0x0a:
            raise RuntimeError("Device returned unexpected response")

        self._tx(pkt_type=0, payload=[2+len(info), 0x1d]+info)


    def HostResetErrorStatus(self, info):
        """Receive a HostResetErrorStatus and don't do anything

        """
        payload = self._rx(timeout=self._wait_time)

        if payload[0] != 0x02 or payload[1] != 0x1e:
            raise RuntimeError("Device returned unexpected response")


    def SetAudioErrorControl(self, m, n, ae_thresh, ae_hyst, mute_ramp_ctrl):
        """Issue a SetAudioErrorControl

        Args:
            m (int): M
            n (int): N
            ae_thresh (int): AE  threshold
            ae_hyst (int): AE hysterisis
            mute_ramp_ctrl (int): mute ramp control

        """
        self._tx(pkt_type=0, payload=[0x08, 0x11, (m&0x3f00)<<8, m&0xff, n, ae_thresh, ae_hyst, mute_ramp_ctrl])


    def GetAudioErrorControl(self):
        """Issue a GetAudioErrorControl and receive the RetAudioErrorControl

        Returns:
            m (int): M
            n (int): N
            ae_thresh (int): AE  threshold
            ae_hyst (int): AE hysterisis
            mute_ramp_ctrl (int): mute ramp control
            acec (int): ACEC

        """
        self._tx(pkt_type=0, payload=[0x02, 0x12])
        payload = self._rx()

        if payload[0] != len(payload) or payload[1] != 0x13:
            raise RuntimeError("Device returned unexpected response")

        m = (payload[2]<<8) | payload[3]
        n = payload[4]
        ae_thresh = payload[5]
        ae_hyst = payload[6]
        mute_ramp_ctrl = payload[7]
        acec = payload[8]

        return m, n, ae_thresh, ae_hyst, mute_ramp_ctrl, acec


    def DeviceTransmitTestModeStart(self, test_pattern):
        """Issue a DeviceTransmitTestModeStart

        Args:
            test_pattern (list of int): test pattern to be transmitted

        """
        self._tx(pkt_type=0, payload=[2+len(test_pattern), 0x1f, 0x14] + test_pattern)


    def DeviceTransmitTestModeStop(self):
        """Issue a DeviceTransmitTestModeStop

        """
        self._tx(pkt_type=0, payload=[0x02, 0x15])


    def DeviceReceiveTestModeStart(self):
        """Issue a DeviceReceiveTestModeStart

        """
        self._tx(pkt_type=0, payload=[0x02, 0x16])


    def DeviceReceiveTestModeStop(self):
        """Issue a DeviceReceiveTestModeStop

        """
        self._tx(pkt_type=0, payload=[0x02, 0x17])


    def HostTransmitTestModeStart(self):
        """Receive a HostTransmitTestModeStart

        Returns:
            test_pattern (list of int): test pattern to be transmitted

        """
        payload = self._rx(timeout=self._wait_time)

        if payload[0] != 0x1f or payload[1] != 0x18:
            raise RuntimeError("Device returned unexpected response")

        test_pattern = payload[2:]

        return test_pattern


    def HostTransmitTestModeStop(self):
        """Receive a HostTransmitTestModeStop

        """
        payload = self._rx(timeout=self._wait_time)

        if payload[0] != 0x02 or payload[1] != 0x19:
            raise RuntimeError("Device returned unexpected response")


    def HostReceiveTestModeStart(self):
        """Receive a HostReceiveTestModeStart

        """
        payload = self._rx(timeout=self._wait_time)

        if payload[0] != 0x02 or payload[1] != 0x1a:
            raise RuntimeError("Device returned unexpected response")


    def HostReceiveTestModeStop(self):
        """Receive a HostReceiveTestModeStart

        """
        payload = self._rx(timeout=self._wait_time)

        if payload[0] != 0x02 or payload[1] != 0x1b:
            raise RuntimeError("Device returned unexpected response")


    def SetDifferentialAmplitude(self, amplitude):
        """Issue a SetDifferentialAmplitude

        Args:
            amplitude (int): 0=enhanced, 1=normal, 2=reduced

        """
        self._tx(pkt_type=0, payload=[0x03, 0x1f, amplitude])
# ----------------------------------------------------------------------------
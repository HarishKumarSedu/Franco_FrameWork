# ----------------------------------------------------------------------------
# repack.py
# Gabriel Seitz
# 2016-11-1
# contains generic functions for manipulating integers and arrays
# ----------------------------------------------------------------------------

# Imports
# ----------------------------------------------------------------------------
from .compatability import *
# ----------------------------------------------------------------------------

# Functions
# ----------------------------------------------------------------------------
def int_to_array(input_value, output_length, int_size=1, invert=False):
    """segments a larger integer into an array of smaller integers

    Args:
        input_value (int): integer value to be converted
        output_length (int): desired number of segments
        int_size (int): number of bytes to be in one segment
        invert (bool): set True to reverse byte order (little endian)

    Returns:
        output_array (list of ints): array of ints

    Example: int to 32 bit byte array
        int_to_array(0x0123, 4)
        -> [0x00, 0x00, 0x01, 0x23]

    """
    if input_value >= 2**(output_length*int_size*8):
        raise ValueError("input value ({:#x}) is larger than the max bytes ({}) specified for the output array".format(input_value, output_length*int_size))
    
    mask = 2**(int_size*8) - 1
    output_array = [int((input_value>>i)&mask) for i in xrange(0, output_length*int_size*8, int_size*8)]

    if not invert:
        output_array = output_array[::-1]

    return output_array


def array_to_int(input_array, item_size=1, invert=False):
    """combines an array of integers into one integer

    Args:
        input_array (list of int): list of data chunks to be combined
        item_size (int): number of bytes per item in the input array
        invert (bool): set True to reverse byte order (little endian)

    Returns:
        value (int): concatenated value resulting from hex array

    Example:
        array_to_int([0x01, 2, 0x34])
        -> 0x010234

    """
    bits = item_size*8  # 8 bits per byte
    max_value = 2**bits

    if invert:
        input_array = input_array[::-1]

    value = 0
    for item in input_array:
        if item >= max_value or item < 0:
            raise ValueError("Invalid input, item in list ({:#x}) is larger than specified size ({:#x})".format(item, item_size))
        else:
            value = value<<bits | item

    return value
    
    
def array_to_array(input_array, item_size=1, invert=False):
    """Converts a longer array of smaller integers to a shorter array of larger integers

    Args:
        input_array (list of int): array of values to be converted
        item_size (int): desired number of bytes per item in the returned array

    Returns:
        output_array (list): list of concatenated values from input array

    Example:
        array_to_array([0x01, 2, 0x34, 0], 2)
        -> [0x0102, 0x3400]

    """
    if len(input_array)%item_size:
        raise ValueError("length of input_array ({}) must be divisible by size ({})".format(len(input_array), item_size))
    
    output_array = [array_to_int(input_array[i:i+item_size], invert=invert) for i in xrange(0, len(input_array), item_size)]

    return output_array
# ----------------------------------------------------------------------------

















































































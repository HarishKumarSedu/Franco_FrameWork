# ----------------------------------------------------------------------------
# clocking.py
# Gabriel Seitz
# 2016-11-28
# contains functions to calculate clock settings
# ----------------------------------------------------------------------------

# Imports
# ----------------------------------------------------------------------------
from fractions import Fraction
# ----------------------------------------------------------------------------

# Definitions
# ----------------------------------------------------------------------------
def get_divide_ratio(master_clock, frame_clock, channel_width, channel_num):
    """calculates the divide ratio (numerator and denominator) to generate a bit clock

    Args:
        master_clock (int): master clock rate in kHz
        frame_clock (int): desired frame clock rate in kHz
        channel_width (int): bits per channel
        channel_num (int): number of active channels

    Returns:
        numerator (int)
        denominator (int)

    Raises:
        ValueError if the input settings conflict
    """

    bit_clock = frame_clock*channel_width*channel_num

    if (bit_clock > master_clock):
        raise ValueError("Error: calculated bit clock ("+str(bit_clock) +"kHz) is faster than master clock ("+str(master_clock)+"kHz).")

    if frame_clock in [8, 12, 16, 24, 32, 48, 96]:
        if channel_width == 25:
            lcd = 60
        else:
            lcd = 375*4
    elif frame_clock in [11.025, 22.05, 44.1]:
        if channel_width == 25:
            raise ValueError("Error: Invalid clock settings. Frame rate does not support 25 bit channels.")
        else:
            lcd = 10000
    else:
        raise ValueError("Clocking settings currently not supported.")

    # try: 
    ratio = Fraction(int(bit_clock*lcd/master_clock), lcd)
    # except:
        # raise ValueError("Error calculating divide ratios.")

    return (ratio.numerator, ratio.denominator)
# ----------------------------------------------------------------------------

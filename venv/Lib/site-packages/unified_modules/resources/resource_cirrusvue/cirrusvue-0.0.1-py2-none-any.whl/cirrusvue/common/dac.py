# ----------------------------------------------------------------------------
# dac.py
# Dakota Koelling
# 2018-07-04
# contains classes for a DAC
# ----------------------------------------------------------------------------

# Imports
# ----------------------------------------------------------------------------
from .generic import GenericDevice
from typing import List, Union
# ----------------------------------------------------------------------------

# Definitions
# ----------------------------------------------------------------------------


class DAC(GenericDevice):
    """DAC device class

    """

    def __init__(self, number, com, definition_file=None, page_address=None):
        """Instantiate a DAC device object

        Args:
            number (int): DAC index number
            com (obj): communication object containing write() and read() methods
            definition_file (list): path to device definition file
            page_address (int): address of page register

        """

        self.number = number
        self.com = com
        GenericDevice.__init__(com, definition_file, page_address)

    def write_to_dac(self, dacs: Union[str, List[str]], hex_value: Union[int, List[int]], update: bool = True):
        """Program the TI DAC7578

        Args:
            dacs (str OR List[str]): DAC outputs to set
                Pass multiple DACs as a cell of strings. Single DACs are passed in
                as either a cell or string.
            hex_value (int OR List[int]): hex value to set DAC (0x000 to 0xFFF)
                Pass multiple hex values as a cell of strings. Single hex values
                are passed in as either a cell or string. Single values will be
                used for every DAC that is specified.
            update (bool): write AND update dac output
        NOTE: Unless only one hex_value is passed in, the number of DACs must
            match the number of hex_values. If one hex_value is passed, this value
            will be used for all DACs that are specified.
        Ex: Write 0 to all DAC channels
            eeb_write_to_dac(eeb.DAC_ADDR, dacs=['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'], hex_value=0x000);
        """

        if isinstance(hex_value, int):
            hex_value = '{:03x}'.format(hex_value)[:3]  # Get value (use upper 12-bits - lower bits will be ignored)
            hex_value = [hex_value for _ in range(8)]  # Use value for all DACs
        elif isinstance(hex_value, list) and len(hex_value) == 1:
            hex_value = [hex_value[1] for _ in range(8)]  # Use value for all DACs
        elif len(dacs) != len(hex_value):
            assert False, 'The number of DACs being set must match the number of values passed!'

        if update:
            command = '3'  # Write and update DAC
        else:
            command = '0'  # Write only selected DAC

        for i in range(len(dacs)):
            dac_ch = dacs[i].upper()
            dac_channels = {
                'A': '0',
                'B': '1',
                'C': '2',
                'D': '3',
                'E': '4',
                'F': '5',
                'G': '6',
                'H': '7'
            }

            assert dac_ch in dac_channels.keys(), ('DAC ' + dac_ch + ' does not exist!')
            dac_reg = dac_channels.get(dac_ch)
            register = int(command + dac_reg, 16)  # Command and DAC to update
            value_write = int(hex_value[i] + '0', 16)  # 16 bits total, but last nibble is don't care (use 0)
            self.com.write(register, value_write)  # Write value to DAC

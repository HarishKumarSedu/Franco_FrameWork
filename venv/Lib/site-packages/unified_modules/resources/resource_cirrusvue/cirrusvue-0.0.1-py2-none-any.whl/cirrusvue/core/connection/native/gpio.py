# ----------------------------------------------------------------------------
# gpio.py
# Gabriel Seitz
# 2018-05-31
# contains functions for the GPIO class
# ----------------------------------------------------------------------------

# Imports
# ----------------------------------------------------------------------------
from . import periphery
# ----------------------------------------------------------------------------

# Definitions
# ----------------------------------------------------------------------------
class GPIO(object):
    """Communication class for GPIO. A handle is created and called directly to issue transactions.

    """

    def __init__(self, pin, direction="preserve", verbose=False):
        """Instantiate an GPIO object.

        Args:
            pin (int): number corresponding to pin, can be 0-31
            direction (str): pin direction, can be "in", "out", "high", "low", or "preserve"
            verbose (bool): option to print detailed information

        Returns:
            GPIO: gpio handle

        """
        self._verbose = verbose
        self._handle = periphery.GPIO(pin, direction)
        if self._verbose:
            print("Opened handle " +str(self._handle))


    def __del__(self):
        if self._verbose:
            print("Closing handle " +str(self._handle))
        self._handle.close()


    def set_verbose(self, state):
        """Control printing behavior

        Args:
            state (int, bool): turn on or off verbose print statements

        """
        self._verbose = True if state else False
    
    
    def set_direction(self, direction):
        """configure the input/output direction of the GPIO pin

        Args:
            direction (str, int, bool): can be 'out'=1 or 'in'=0

        """
        if isinstance(direction, (int, bool)):
            direction = 'out' if direction else 'in'
        elif isinstance(direction, str):
            if direction.lower() in ['out', 'output']:
                direction = 'out'
            if direction.lower() in ['in', 'input', 'hiz', 'hi-z']:
                direction = 'in'

        self._handle._set_direction(direction)

        if self._verbose:
            print("GPIO Configuration: Pin = {}; Direction = {}".format(self._pin, direction))
    

    def write(self, state):
        """Set the output state. The direction must be set to output.

        Args:
            state (int, bool): drive pin high/low

        """
        self._handle.write(state)

        if self._verbose:
            print("GPIO Write: Pin = {}; State = {}".format(self._pin, state))
        
    
    def read(self):
        """Get the current state

        Returns:
            state (int): high/low status of pin

        """
        state = self._handle.read()

        if self._verbose:
            print("GPIO Read: Pin = {}; State = {}".format(self._pin, state))

        return state
# ----------------------------------------------------------------------------
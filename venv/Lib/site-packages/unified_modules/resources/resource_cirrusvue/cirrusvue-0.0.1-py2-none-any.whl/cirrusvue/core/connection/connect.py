class Connect(object):
    """Class to abstract importing connection classes

    """
    _CIRRUSLINK = 'cirruslink'
    _NATIVE = 'native'
    _SCSLINK = 'scslink'
    _VIRTUAL = 'virtual'

    def __init__(self, interface, system=None, path_to_scs_link=None):
        """Instantiate a connection object.
        
        
        Args:
            interface (str): method of connecting, can be "usb", "ethernet", "serial", "native" or "scs"
            system (str): specify target system, this varies depending on the interface
                CirrusLink: hostname or ip address
                SCSLink: board name, case sensitive
                Native: N/A
            path_to_scs_link (str): folder path to scs_link.exe
            
        """
        interface = interface.lower()
        if interface in ['usb', 'ethernet']:
            self.type = self._CIRRUSLINK
            from .cirruslink.ethernet import CirrusLinkClient
            self._handle = CirrusLinkClient(system)
            from .cirruslink.i2c import I2C     #@UnusedImport
            from .cirruslink.spi import SPI     #@UnusedImport
            from .cirruslink.gpio import GPIO   #@UnusedImport
        elif interface in ['serial', 'cdcserial', 'cdc_serial']:
            self.type = self._CIRRUSLINK
            from .cirruslink.vcom import CirrusLinkClient    #@UnusedImport
            self._handle = CirrusLinkClient(system)
            from .cirruslink.i2c import I2C      #@UnusedImport
            from .cirruslink.spi import SPI      #@UnusedImport
            from .cirruslink.gpio import GPIO    #@UnusedImport
        elif interface in ['scs', 'scslink', 'scs_link']:
            self.type = self._SCSLINK
            from studiolink.StudioLink import StudioLink
            scs_link = StudioLink(path_to_scs_link)
            for CLSystem in scs_link.getCLSystems():
                if system in CLSystem.getName():
                    self._handle = CLSystem
                    break
            else:
                raise RuntimeError("No matching systems found.")
        elif interface in ['linux', 'zynq', 'native', 'embedded']:
            self.type = self._NATIVE
            self._handle = None
            from .native.i2c import I2C          #@UnusedImport
            from .native.spi import SPI          #@UnusedImport
            from .native.gpio import GPIO        #@UnusedImport

        elif interface in ['virtual', 'sim', 'simulated']:
            self.type = self._VIRTUAL
            self._handle = None
            from .virtual.i2c import I2C         #@UnusedImport
            from .virtual.spi import SPI         #@UnusedImport
            from .virtual.gpio import GPIO       #@UnusedImport
            
        else:
            raise ValueError("Invalid interface: {}".format(interface))

        from .bridge.mbus_bulk import MikeyBusBulk
        from .bridge.swire import SoundWire

        self._I2C = I2C
        self._SPI = SPI
        self._GPIO = GPIO
        self._MikeyBusBulk = MikeyBusBulk
        self._SoundWire = SoundWire
        
    def __del__(self):
        try:
            del(self._handle)
        except AttributeError:
            pass
        
    def get_i2c(self, *args, **kwargs):
        """Instantiate a I2C object.

        Args:
            bus (int): I2C bus number, for the AudioHub: "0"=3.3V external, "1"=high speed DUT, "2"=internal SOM, "3"=internal AudioHub
            i2c_addr (int): 8bit I2C address
            bus_speed (int): clock rate, can be "0"=100kHz, "1"=400kHz, "2"=1MHz, "3"=20kHz.
            map_size (int): number of bytes in the memory address pointer
            repeated_start (bool): True to read using a repeated start condition, False for stop-start

        Returns:
            I2C: i2c handle

        """
        if self._handle is None:
            i2c = self._I2C(*args, **kwargs)
        else:
            i2c = self._I2C(self._handle, *args, **kwargs)

        return i2c
        

    def get_spi(self, *args, **kwargs):
        """Instantiate a SPI object.

        Args:
            bus (int): SPI bus number, for the AudioHub "1" is the only bus
            chip_select (int): number corresponding to a chip select pin
            addr_size (int): number of bytes to address a register
            data_size (int): number of bytes in a register
            speed (int): clock rate in MHz
            apb_mode (bool): 'True' to use the APB format or 'False' to send address bytes then value bytes

        Returns:
            SPI: spi handle.

        """
        if self._handle is None:
            spi = self._SPI(*args, **kwargs)
        else:
            spi = self._SPI(self._handle, *args, **kwargs)
        return spi
        

    def get_gpio(self, *args, **kwargs):
        """Instantiate an GPIO object.

        Args:
            pin (int): number corresponding to pin, can be 0-31
            direction (str): pin direction, can be "in", "out", "high", "low", or "preserve"

        Returns:
            GPIO: gpio handle

        """
        if self._handle is None:
            gpio = self._GPIO(*args, **kwargs)
        else:
            gpio = self._GPIO(self._handle, *args, **kwargs)
        return gpio
        

    def get_bulk(self, *args, **kwargs):
        """Instantiate a MikeyBus Bulk object.

        Args:
            transmit (func): method to send downlink packet with inputs pkt_type (int), payload (list), fid (int)
            receive (func): method to wait for and get uplink packet, returns payload (list)
            wait_time (int, float): default time to wait for device initiated packets

        Returns:
            MikeyBusBulk: MikeyBus Bulk handle.

        """
        bulk = self._MikeyBusBulk(*args, **kwargs)
        return bulk
        

    def get_swire(self, *args, **kwargs):
        """Instantiate a SoundWire object.

        Args:
            send (func): function that can send and receive writes, reads and pings
            num (int): Device Address={} assigned through enumeration
            map_size (int): number of bytes of the memory address pointer
            little_endian (bool): True for data bytes in the order of LSB to MSB, False for MSB to LSB

        Returns:
            SoundWire: SoundWire handle.

        """
        swire = self._SoundWire(*args, **kwargs)
        return swire
        
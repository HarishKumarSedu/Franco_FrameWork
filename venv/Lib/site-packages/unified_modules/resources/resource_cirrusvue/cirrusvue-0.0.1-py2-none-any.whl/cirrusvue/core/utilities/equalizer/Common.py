# Copyright (c) 2016-2018 Cirrus Logic, Inc and
# Cirrus Logic International Semiconductor Ltd.  All rights reserved.
#
# This software as well as any related documentation is furnished under
# license and may only be used or copied in accordance with the terms of the
# license.  The information in this file is furnished for informational use
# only, is subject to change without notice, and should not be construed as
# a commitment by Cirrus Logic.  Cirrus Logic assumes no responsibility or
# liability for any errors or inaccuracies that may appear in this document
# or any software that may be provided in association with this document.
#
# Except as permitted by such license, no part of this document may be
# reproduced, stored in a retrieval system, or transmitted in any form or by
# any means without the express written consent of Cirrus Logic.
#
# Warning
#   This software is specifically written for Cirrus Logic devices.
#   It may not be used with other devices.
#

import copy
import errno
import math
import os
import re
import numpy as np
import matplotlib.pyplot as plt


class Common(object):
    """
    Library object to hold all common helper functions and constants
    for EQ Panel and biquad manipulation.
    """
    FS_48K = 48937.5
    # Note(aiden): FS_192K is not currently used - may need updating
    FS_192K = 192000
    DEFAULT_FORMAT = "S1.30"

    @classmethod
    def flatten_dict(cls, d, parent_str='', sep='|'):
        """
        Takes a nested dict structure (i.e. json type) and flattens
        it out (whilst concatenating the parent name to each child key)

        NB: converts all keys to strings

        :param d: a nested `dict`
        :param parent_str: a `str` used in recursion to add in parent info
        :param sep: a `str` delimiter to separate parent & child in string

        :returns: dict(dict_items), a `dict` with same structure
        """
        dict_items = []

        for k, v in d.items():
            new_key = parent_str + sep + str(k) if parent_str else str(k)
            if isinstance(v, list):
                # convert to dictionary:
                # add List key for recovery
                new_key += "[L]"
                v = dict([(i, el) for i, el in enumerate(v)])
                dict_items.extend(cls.flatten_dict(v, new_key, sep).items())
            elif isinstance(v, dict):
                # add Dict key for recovery
                new_key += "[D]"
                dict_items.extend(cls.flatten_dict(v, new_key, sep).items())
            else:
                dict_items.append((new_key, v))
        return dict(dict_items)

    @classmethod
    def make_sure_path_exists(cls, path):
        """
        Robust method for ensuring a path exists

        :param path: string with folderpath
        """
        try:
            if not os.path.exists(path):
                os.makedirs(path)
        except OSError as exception:
            if exception.errno != errno.EEXIST:
                raise

    @classmethod
    def linear_gain(cls, dB):
        """
        Takes number in dB and converts to linear gain

        :param dB: gain in decibels
        :returns: linear gain
        """
        if dB == -float("inf"):
            return 0
        else:
            return math.pow(10.0, dB / 20.0)

    @classmethod
    def db_gain(cls, linear_gain):
        """
        Takes linear gain and converts to dB

        :param linear_gain: linear gain
        :returns: gain in dB
        """
        if linear_gain == 0:
            return -float("inf")
        else:
            return (20 * math.log(linear_gain, 10))

    @classmethod
    def un_flatten_dict(cls, d, sep="|"):
        """
        Takes a dict flattened by flatten_dict() and fattens it up again

        NB: all values will now be strings and will need to be cast by
            function caller

        :param d: `dict` to be unpacked
        :param sep: delimiter

        :returns: an expanded `dict`, reversing use of sep as delimiter
        for parent_child
        """
        out = {}

        unpack = {}

        # loop through flattened dict and build out and unpack dicts
        for k, v_str in d.items():
            # find type of v_str and cast:
            v = cls.cast_string(v_str)

            key_split = k.split(sep)
            if len(key_split) == 1:
                # assume that we're at a leaf, so add to out
                out[key_split[0]] = v
            elif len(key_split) == 2:
                if key_split[0] not in out:
                    # we convert dict to list if neccessary after
                    out[key_split[0]] = {key_split[1]: v}
                else:
                    out[key_split[0]][key_split[1]] = v
            elif len(key_split) > 2:
                if key_split[0] not in unpack:
                    unpack[key_split[0]] = {sep.join(key_split[1:]): v}
                else:
                    unpack[key_split[0]][sep.join(key_split[1:])] = v

        # once unpack is built, loop through and *unpack* unpack into out
        for k in unpack:
            unpacked = cls.un_flatten_dict(unpack[k], sep)
            if k in out:
                for k2 in unpacked:
                    out[k][k2] = unpacked[k2]
            else:
                out[k] = unpacked

        for k, v in out.items():
            if "[L]" in k:
                out[k] = cls.dict_to_list(out[k])
            # strip out container type info from key string
            out[k.replace("[L]", "").replace("[D]", "")] = out.pop(k)

        return out

    @staticmethod
    def dict_to_list(list_dict):
        """
        Takes a dict with contiguous ints as keys (effectively
        representing a list) and converts it back into a list

        :param list_dict: dict convertable into list
        (i.e. {1: "foo", 2: "bar"})
        :returns: list with same info
        """
        new_list = [None] * len(list_dict)
        for i_str, val in list_dict.items():
            new_list[int(i_str)] = val
        return new_list

    @classmethod
    def cast_string(cls, in_string):
        """
        Used with data coming from csv write - converts a string into
        apparent type.
        Can detect `float`, `int`, `bool`, `str` and `None` types

        :param in_string: the string to be converted, if not a str,
            function returns string untouched

        :returns: in_string cast to apparent type
        """
        if not isinstance(in_string, str):
            return in_string
        elif re.match(r"^-?\d+?\.\d+?$", in_string) is not None:
            out = float(in_string)
        elif re.match(r"^-?\d+?$", in_string) is not None:
            out = int(in_string)
        elif in_string in ("True", "False"):
            out = in_string == "True"
        elif in_string in ("None", ""):
            out = None
        elif isinstance(in_string, str):
            out = in_string
        return out

    @classmethod
    def poly_val(cls, coeffs, array):
        """
        Takes a polynomial defined by :coeffs: and evaluates the result
        elementwise over array.

        :param coeffs: a list of coefficients in descending powers
        (i.e. [1, 7, 9] = x^2 + 7x^1 + 9x^0)
        :param array: a list of numbers (can be float, int, complex)
        over which the polynomial must be evaluated

        :returns: list of results
        """
        coeffs = coeffs[::-1]

        results = []

        for el in array:
            result = 0
            for i, coef in enumerate(coeffs):
                result += coef * (el**i)
            results.append(result)

        return results

    @classmethod
    def hex2dec(cls, fixed_point_value, verbose=0):
        """Convert S1.30 fixed point hex to fractions.

        Args:
            (int) S1.30 fixed-point hex

        Return:
            fractions (float) between -2 to 2
        """
        fraction = float((fixed_point_value & 0x3FFFFFFF) << 2)
        integer = (fixed_point_value & 0x40000000) >> 30

        # fraction_dec = fraction/16/16/16/16/16/16/16/16
        fraction_dec = fraction/4294967296

        result = integer+fraction_dec
        result = (-result) if (fixed_point_value & 0x80000000) else result
        if verbose:
            print fraction
            print integer
            print fraction_dec
            print result
        return result

    @classmethod
    def dec2hex(cls, fractions, verbose=0):
        """Convert fractions to S1.30 fixed point hex.

        Args:
            fractions (float) between -2 to 2

        Return:
            (int) S1.30 fixed-point hex
        """
        # fixed_point = fractions*16*16*16*16*16*16*16*16
        fixed_point = fractions*4294967296
        fixed_point = int(fixed_point)
        fixed_point = fixed_point >> 2
        if fixed_point < 0:
            fixed_point_str = "0x{0:0{1}X}".format(fixed_point & ((1 << 32) - 1), 8)
        else:
            fixed_point_str = "0x{0:0{1}X}".format(fixed_point, 8)
        if verbose:
            print fixed_point_str
        return fixed_point_str

    @classmethod
    def get_freq_points(cls, start_freq, stop_freq, points=100, log=1, verbose=0):
        """Generate and return a list of frequency points in log or linear scale.

        Args:
            start_freq (float)
            stop_freq (float)
            points (int): number of frequency points
            log (int): 0 for linear scale, 1 for logarithmic scale
            verbose (int): 0 to mute print statement, 1 to print frequency points returned

        Returns:
            list of frequency points in float

        """
        if start_freq > stop_freq:
            raise RuntimeError("Start Frequency is greater than Stop Frequency.")

        start_freq = float(start_freq)
        stop_freq = float(stop_freq)
        points = int(points)

        if log:
            freq_points = np.logspace(math.log(start_freq, 20), math.log(stop_freq, 20), points, base=20).tolist()
        else:
            freq_points = np.linspace(start_freq, stop_freq, points).tolist()

        if verbose:
            print "Start frequency: " + str(start_freq)
            if log:
                print "Start frequency (log base 20): " + str(math.log(start_freq, 20))
            print "Stop frequency: " + str(stop_freq)
            if log:
                print "Stop frequency (log base 20): " + str(math.log(stop_freq, 20))
            print "Frequency points:/n" + freq_points

        return freq_points

    @classmethod
    def plot(cls, start_freq, stop_freq, freq_list, mag_list, title="Magnitude Response"):
        """Plot magnitude response graph."""
        plt.figure()
        plt.plot(freq_list, mag_list)
        plt.title(title)
        plt.xscale('log')
        plt.xlim([start_freq, stop_freq])
        plt.xlabel('Frequency (Hz)')
        plt.ylabel('Magnitude (dB)')
        plt.grid(True, 'both')
        plt.show()

# ----------------------------------------------------------------------------
# crc.py
# Gabriel Seitz
# 2018-05-18
# contains functions to calculate a cyclical redundancy check
# ----------------------------------------------------------------------------

# Imports
# ----------------------------------------------------------------------------
from .compatability import *
# ----------------------------------------------------------------------------

# Definitions
# ----------------------------------------------------------------------------
def crc16(input, poly=0xa001):
    """Calculate the CRC-16

    Args:
        input (list of int): array to perform calculation on
        poly (int): LSB-first code, 0xa001 = (x^0 + x^2 + x^15) + x^16

    """
    crc = 0
    for byte in input:
        temp_val = crc ^ byte
        for i in xrange(8):
            if temp_val & 1:
                temp_val = (temp_val >> 1) ^ poly
            else:
                temp_val = (temp_val >> 1)
        crc = temp_val
    return crc
# ----------------------------------------------------------------------------
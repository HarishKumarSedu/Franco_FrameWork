# ----------------------------------------------------------------------------
# spi.py
# Gabriel Seitz
# 2018-05-22
# contains the communication class that implements the CirrusLink SPI protocol
# ----------------------------------------------------------------------------

# Imports
# ----------------------------------------------------------------------------
from ...utilities import repack, apb
# ----------------------------------------------------------------------------

# Definitions
# ----------------------------------------------------------------------------
class SPI(object):
    """Communication class for SPI.

    """
    _CLASS_SPI_CONFIG = 0x20
    _CLASS_FD_SPI = 0x21
    _CLASS_APB_SPI = 0x27

    def __init__(self, clink, bus, chip_select, addr_size=4, word_size=4, speed=12, apb_mode=True, verbose=False):
        """Instantiate an SPI object.

        Args:
            clink (obj): CirrusLinkClient object
            bus (int): SPI bus number, for the AudioHub "1" is the only bus
            chip_select (int): number corresponding to a chip select pin
            addr_size (int): number of bytes to address a register
            data_size (int): number of bytes in a register
            speed (int): clock rate in MHz
            apb_mode (bool): 'True' to use the APB format or 'False' to send address bytes then value bytes
            verbose (bool): option to print detailed information

        Returns:
            SPI: spi handle.

        """
        self._verbose = verbose
        self._clink = clink
        self._bus = bus
        self._chip_select = chip_select
        self._addr_size = addr_size
        self._word_size = word_size
        self._speed = speed * 1000000
        self._apb_mode = apb_mode


    def set_verbose(self, state):
        """Control printing behavior

        Args:
            state (int, bool): turn on or off verbose print statements

        """
        self._verbose = True if state else False

        
    def _create_apb_class_ext(self, apb_reg_addr, apb_block_len, apb_cmd):
        """Create common CirrusLink CLASS_EXT used by other functions.
        Default behavior is full-duplex.

        """
        class_ext = []
        
        # APB_CTRL
        apb_ctrl = apb.create_apb_ctrl('apb', apb_cmd)
        class_ext.append(apb_ctrl)
        
        # APB_ADDR[H, M, L]
        class_ext.extend(repack.int_to_array(apb_reg_addr, 3))
        
        # APB_BLEN[H, L]
        class_ext.extend(repack.int_to_array(apb_block_len, 2))
        
        # APB_CMD
        class_ext.append(apb_cmd)
        
        # CHIP_SEL
        class_ext.append(self._chip_select)
        
        return class_ext


    def write(self, address, value):
        """Write a single value to a register.

        Args:
            address (int): address of register
            value (int): value to write

        """
        self.write_block(address, [value])


    def write_block(self, address, values):
        """Write multiple values to a starting register location.

        Args:
            address (int): starting address of registers
            values (list of ints): values to write

        """
        # convert values to a list of bytes
        value_bytes = []
        for value in values:
            value_bytes.extend(repack.int_to_array(value, self._word_size))
        
        # get basic args and payload
        if self._apb_mode:
            clink_class = self._CLASS_APB_SPI
            apb_cmd = 0xB5 if self._word_size==1 else 0xB2
            clink_class_ext = self._create_apb_class_ext(address, len(values), apb_cmd)
            payload = value_bytes
        else:
            raise NotImplementedError
            clink_class = self._CLASS_FD_SPI
            clink_class_ext = [self._chip_select]
            address_bytes = repack.int_to_array(address, self._addr_size)
            payload = address_bytes.extend(value_bytes)
        
        # Issue transaction
        self._clink.send(clink_class, clink_class_ext, payload)

        if self._verbose:
            if len(values) == 1:
                value = values[0]
                print("SPI Write: Bus={0}; Chip Select={1}; Register Address=0x{2:0{3}x}; Value=0x{4:0{5}x};".format(self._bus, self._chip_select, address, self._addr_size*2, value, self._word_size*2))
            else:            
                print("SPI Write: Bus={0}; Chip Select={1}; Register Address=0x{2:0{3}x};".format(self._bus, self._chip_select, address, self._addr_size*2))
                for value in values:
                    print("\tRegister Value=0x{0:0{1}x};".format(value, self._word_size*2))


    def read(self, address):
        """Read from a single register.

        Args:
            address (int): address of register

        Returns:
            value (int): value of the register

        """
        values = self.read_block(address, length=1)
        value = values[0]
        return value


    def read_block(self, address, length=1):
        """Read multiple values from a starting register location.

        Args:
            address (int): starting address of registers
            length (int): number of registers to read

        Returns:
            values (list of ints): values of the registers

        """
        # get basic args and payload
        if self._apb_mode:
            clink_class = self._CLASS_APB_SPI
            apb_cmd = 0xC6 if self._word_size==1 else 0xC4
            clink_class_ext = self._create_apb_class_ext(address, length, apb_cmd)
            payload = None
        else:
            raise NotImplementedError
            clink_class = self._CLASS_FD_SPI
            clink_class_ext = [self._chip_select]
            address_bytes = repack.int_to_array(address, self._addr_size)
            dummy_bytes = repack.int_to_array(0, length*self._word_size)
            payload = address_bytes.extend(dummy_bytes)
        
        # Issue transaction
        data_bytes = self._clink.send(clink_class, clink_class_ext, payload)
        
        if not self._apb_mode:
            data_bytes = data_bytes[len(address_bytes):]
        
        values = repack.array_to_array(data_bytes, self._word_size)

        if self._verbose:
            if len(values) == 1:
                value = values[0]
                print("SPI Read: Bus={0}; Chip Select={1}; Register Address=0x{2:0{3}x}; Value=0x{4:0{5}x};".format(self._bus, self._chip_select, address, self._addr_size*2, value, self._word_size*2))   
            else:
                print("SPI Read: Bus={0}; Chip Select={1}; Register Address=0x{2:0{3}x};".format(self._bus, self._chip_select, address, self._addr_size*2))
                for value in values:
                    print("\tRegister Value=0x{0:0{1}x};".format(value, self._word_size*2))

        return values


    def transfer(self, data_out):
        """Perform a full-duplex transaction.

        Args:
            data_out (list of ints): data bytes to be sent out on MOSI

        Returns:
            values (list of ints): data bytes returned on MISO

        """        
        # Issue transaction
        data_in = self._clink.send(self._CLASS_FD_SPI, [self._chip_select], data_out)

        if self._verbose:
            print("SPI Transfer: Bus={}; Chip Select={};".format(self._bus, self._chip_select))
            for byte_out, byte_in in zip(data_out, data_in):
                print("\tMOSI Byte={:#04x}; MISO Byte={:#04x};".format(byte_out, byte_in))
        
        return data_in
# ----------------------------------------------------------------------------
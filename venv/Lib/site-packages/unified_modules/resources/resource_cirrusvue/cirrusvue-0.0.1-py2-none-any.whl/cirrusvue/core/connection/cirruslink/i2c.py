# ----------------------------------------------------------------------------
# i2c.py
# Gabriel Seitz
# 2018-05-18
# contains the communication class that implements the CirrusLink I2C protocol
# ----------------------------------------------------------------------------
# achange
# Imports
# ----------------------------------------------------------------------------
from ...utilities import repack
# ----------------------------------------------------------------------------

# Definitions
# ----------------------------------------------------------------------------
class I2C(object):
    """Communication class for I2C. 

    """
    _CLASS_I2C = 0x16
    _RESET = 1  #  reset I2C controller every transaction
    _I2C_ADDR_LEN = 0  # 7 bit I2C addresses only

    def __init__(self, clink, bus, i2c_addr, map_size=1, word_size=1, bus_speed=0, repeated_start=True, verbose=False):
        """Instantiate an I2C object.

        Args:
            clink (obj): CirrusLinkClient object
            bus (int): I2C bus number, for the AudioHub: "0"=3.3V external, "1"=high speed DUT, "2"=internal SOM, "3"=internal AudioHub
            i2c_addr (int): 8bit I2C address
            bus_speed (int): clock rate, can be "0"=100kHz, "1"=400kHz, "2"=1MHz, "3"=20kHz.
            map_size (int): number of bytes in the memory address pointer
            repeated_start (bool): True to read using a repeated start condition, False for stop-start
            verbose (bool): option to print detailed information

        Returns:
            I2C: i2c handle.

        """
        self._verbose = verbose
        self._clink = clink
        self._i2c_addr = i2c_addr
        self._bus = bus
        self._bus_speed = bus_speed
        self._map_size = map_size
        self._word_size = word_size
        self._repeated_start = repeated_start


    def set_verbose(self, state):
        """Control printing behavior

        Args:
            state (int, bool): turn on or off verbose print statements

        """
        self._verbose = True if state else False


    def _create_class_ext(self, reg_addr, read_len=0):
        """Create common CirrusLink CLASS_EXT used by other functions.

        """
        class_ext = []
        
        class_ext.extend([self._RESET<<7 | self._repeated_start << 6 | self._bus])
        
        class_ext.extend([self._I2C_ADDR_LEN<<7 | self._bus_speed<<4 | (read_len!=0)<<3 | self._map_size])
        
        class_ext.extend(repack.int_to_array(read_len, 2))
        
        class_ext.extend(repack.int_to_array(reg_addr, 4))  # always 4 bytes per the protocol
        
        class_ext.extend(repack.int_to_array(self._i2c_addr, 2))
        
        return class_ext


    def write(self, address, value):
        """Write a single value to a register.

        Args:
            address (int): register address
            value (int): value to write

        """
        self.write_block(address, [value])
        

    def write_block(self, address, values):
        """Write multiple values to a starting register location.

        Args:
            address (int): starting register address
            values (list of ints): values to write

        """
        # get basic args
        clink_class_ext = self._create_class_ext(address)
        
        # convert values to a list of bytes
        data_out = []
        for value in values:
            data_out.extend(repack.int_to_array(value, self._word_size))
        
        # Issue transaction
        self._clink.send(self._CLASS_I2C, clink_class_ext, data_out)

        if self._verbose:
            if len(values) == 1:
                value = values[0]
                print("I2C Write: Bus={0}; I2C Address=0x{1:02x}; Register Address=0x{2:0{3}x}; Value=0x{4:0{5}x};".format(self._bus, self._i2c_addr, address, self._map_size*2, value, self._word_size*2))
            else:
                print("I2C Write: Bus={0}; I2C Address=0x{1:02x}; Register Address=0x{2:0{3}x};".format(self._bus, self._i2c_addr, address, self._map_size*2))
                for value in values:
                    print("\tValue=0x{0:0{1}x};".format(value, self._word_size*2))


    def read(self, address):
        """Read from a single register.

        Args:
            address (int): register address

        Returns:
            value (int): value of the register

        """
        values = self.read_block(address, length=1)
        value = values[0]
        return value


    def read_block(self, address, length=1):
        """Read multiple values from a starting register location.

        Args:
            address (int): starting register address
            length (int): number of registers to read

        Returns:
            values (list of ints): values of the registers

        """
        # get basic args
        clink_class_ext = self._create_class_ext(address, length*self._word_size)
        
        # Issue transaction
        data_bytes = self._clink.send(self._CLASS_I2C, clink_class_ext)
        
        values = repack.array_to_array(data_bytes, self._word_size)

        if self._verbose:
            if len(values) == 1:
                value = values[0]
                print("I2C Read: Bus={0}; I2C Address=0x{1:02x}; Register Address=0x{2:0{3}x}; Value=0x{4:0{5}x};".format(self._bus, self._i2c_addr, address, self._map_size*2, value, self._word_size*2))
            else:
                print("I2C Read: Bus={0}; I2C Address=0x{1:02x}; Register Address=0x{2:0{3}x};".format(self._bus, self._i2c_addr, address, self._map_size*2))
                for value in values:
                    print("\tValue={0:#0{1}x};".format(value, self._word_size*2))

        return values
# ----------------------------------------------------------------------------
class Connect(object):
    """Class to abstract importing connection classes

    """

    def __init__(self, interface, system=None, path_to_scs_link=None):
        """Instantiate a connection object.
        
        
        Args:
            interface (str): method of connecting, can be "usb", "ethernet", "serial", "native" or "scs"
            system (str): specify target system, this varies depending on the interface
                CirrusLink: hostname or ip address
                SCSLink: board name, case sensitive
                Native: N/A
            path_to_scs_link (str): folder path to scs_link.exe
            
        """
        interface = interface.lower()

        if interface in ['usb', 'ethernet']:
            from .cirruslink.ethernet import CirrusLinkClient
            self._handle = CirrusLinkClient(system)

            from .cirruslink.i2c import I2C
            from .cirruslink.spi import SPI
            from .cirruslink.gpio import GPIO
            
        elif interface in ['serial', 'cdcserial', 'cdc_serial']:
            from .cirruslink.ethernet import CirrusLinkClient
            self._handle = CirrusLinkClient(system)

            from .cirruslink.i2c import I2C
            from .cirruslink.spi import SPI
            from .cirruslink.gpio import GPIO
            
        elif interface in ['scs', 'scslink', 'scs_link']:
            from studiolink.StudioLink import StudioLink
            scs_link = StudioLink(path_to_scs_link)
            for CLSystem in scs_link.getCLSystems():
                if system in CLSystem.getName():
                    self._handle = CLSystem
                    print("Found: {}".format(self._handle.getName()))
                    break
            else:
                raise RuntimeError("No matching systems found.")
                
        elif interface in ['linux', 'zynq', 'native', 'embedded']:
            self._handle = None

            from .native.i2c import I2C
            from .native.spi import SPI
            from .native.gpio import GPIO
            
        else:
            raise ValueError("Invalid interface: {}".format(interface))

        self._I2C = I2C
        self._SPI = SPI
        self._GPIO = GPIO
        

    def get_i2c(self, *args, **kwargs):
        """
        """
        if self._handle is None:
            i2c = self._I2C(*args, **kwargs)
        else:
            i2c = self._I2C(self._handle, *args, **kwargs)

        return i2c
        

    def get_spi(self, *args, **kwargs):
        """
        """
        if self._handle is None:
            spi = self._SPI(*args, **kwargs)
        else:
            spi = self._SPI(self._handle, *args, **kwargs)
        return spi
        

    def get_gpio(self, *args, **kwargs):
        """
        """
        if self._handle is None:
            gpio = self._GPIO(*args, **kwargs)
        else:
            gpio = self._GPIO(self._handle, *args, **kwargs)
        return gpio
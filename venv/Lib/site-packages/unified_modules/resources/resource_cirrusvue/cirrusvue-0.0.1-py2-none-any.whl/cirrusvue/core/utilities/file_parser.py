# ----------------------------------------------------------------------------
# file_parser.py
# Gabriel Seitz
# 2016-11-1
# contains file path utilities
# ----------------------------------------------------------------------------

# Imports
# ----------------------------------------------------------------------------
import os
# ----------------------------------------------------------------------------

# Definitions
# ----------------------------------------------------------------------------
def get_absolute_path(starting_file, relative_path):
    """create a file path that's robust and cross platform

    Args:
        starting_file (?): beginning point of relative path, usually __file__ 
        relative_path (list): sequence of steps from start to target file

    """
    file_path = os.path.join(os.path.dirname(starting_file), *relative_path)
    
    return file_path


def find_in_line(current_line, start_indicator, end_indicator):
    """Search string and return text between unique identifiers

    Args:
        current_line (string): string containing text to be extracted
        start_indicator (string, int):
            string - unique identifier before desired text
            int - integer number of characters before end_indicator
        end_indicator (string, int):
            string - unique identifier after desired text
            int - integer number of characters after start_indicator

    Returns:
        found_string (string): text between start and end indexes

    Example:
        current_line = "The text you are looking for is here: [super secret!, and this doesn't matter]"
        start_indicator = " ["; end_indicator = ", "
        found_string -> "super secret!"

    """
    # search starting string and length
    if type(start_indicator) is str and type(end_indicator) is int:
        start_indicator_index = current_line.index(start_indicator) + len(start_indicator)   # Searches for the start indicator and skips it
        end_indicator_index = start_indicator_index + end_indicator      # Ending index is x characters after the starting index

    # search by ending string and length
    elif type(start_indicator) is int and type(end_indicator) is str:
        end_indicator_index = current_line.index(end_indicator)    # Searches for the last indicator
        start_indicator_index = end_indicator_index - start_indicator    # Starting index is x characters before the ending index

    # search by starting string and ending string
    elif type(start_indicator) is str and type(end_indicator) is str:
        start_indicator_index = current_line.index(start_indicator) + len(start_indicator)   # Searches for the start indicator and skips it
        end_indicator_index = current_line.index(end_indicator, start_indicator_index)     # Searches end indicator after start

    else:
        raise ValueError("Invalid input types.")

    found_string = current_line[start_indicator_index:end_indicator_index]  # Grabs the desired text using the beggining/end locations

    return found_string
# ----------------------------------------------------------------------------

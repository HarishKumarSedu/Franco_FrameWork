# ----------------------------------------------------------------------------
# spi.py
# Gabriel Seitz
# 2016-10-26
# contains the communication class that calls the Linux SPI kernel driver
# ----------------------------------------------------------------------------

# Imports
# ----------------------------------------------------------------------------
from . import periphery
from ...utilities import repack, apb
# ----------------------------------------------------------------------------

# Definitions
# ----------------------------------------------------------------------------
class SPI(object):
    """Communication class for SPI. A handle is created and called directly to issue transactions.

    """

    def __init__(self, bus, chip_select, addr_size=4, word_size=4, speed=12, apb_mode=True, spi_clk_mode=0, verbose=False):
        """Instantiate a SPI object

        Args:
            bus (int): SPI bus number, for the AudioHub "1" is the only bus
            chip_select (int): number corresponding to a chip select pin
            addr_size (int): number of bytes to address a register
            data_size (int): number of bytes in a register
            speed (int): clock rate in MHz
            apb_mode (bool): 'True' to use the APB format or 'False' to send address bytes then value bytes
            spi_clk_mode (int): refer to CPOL and CPHA
            verbose (bool): option to print detailed information

        Returns:
            SPI: spi handle.

        """
        self._verbose = verbose
        self._bus = bus
        self._chip_select = chip_select
        self._speed = speed * 1000000
        self._addr_size = addr_size
        self._word_size = word_size
        self._apb_mode = apb_mode
        self._spi_clk_mode = spi_clk_mode

        self._handle = periphery.SPI('/dev/crus_spi{}.{}'.format(self._bus, self._chip_select), self._spi_clk_mode, self._speed)
        if self._verbose:
            print("Opened handle {}".format(self._handle))


    def __del__(self):
        if self._verbose:
            print("Closing handle {}".format(self._handle))
        self._handle.close()


    def set_verbose(self, state):
        """Control printing behavior

        Args:
            state (int, bool): turn on or off verbose print statements

        """
        self._verbose = True if state else False


    # def set_speed(self, speed):
    #     """Set the clock rate.

    #     Args:
    #         speed (int): clock rate in MHz

    #     """
    #     self._speed = speed * 1000000
    #     self._handle._set_max_speed(self._speed)


    def write(self, address, value):
        """Write a single value to register.

        Args:
            address (int): register address
            value (int): value to write

        """
        self.write_block(address, [value])


    def write_block(self, address, values):
        """Write multiple values to a starting APB register location. Maximum bytes is 4096.

        Args:
            address (int): starting register address
            values (list of ints): values to write.

        """
        # convert values to a list of bytes
        value_bytes = []
        for value in values:
            value_bytes.extend(repack.int_to_array(value, self._word_size, invert=True))

        if self._apb_mode:
            # create command response byte
            apb_cmd = 0xB5 if self._word_size==1 else 0xB2
            apb_ctrl = apb.create_apb_ctrl('apb', apb_cmd)
            cmd_resp = apb.create_cmd_resp('apb', apb_ctrl, address, len(values), apb_cmd)
            data_out = value_bytes
        else:
            raise NotImplementedError
            apb_ctrl = apb.create_apb_ctrl('fd')
            cmd_resp = apb.create_cmd_resp('fd', apb_ctrl)
            address_bytes = repack.int_to_array(address, self._addr_size)
            data_out = address_bytes.extend(value_bytes)

        # Perform SPI transaction
        self._handle.transfer(data_out, cmd_resp)

        if self._verbose:
            if len(values) == 1:
                value = values[0]
                print("SPI Write: Bus={0}; Chip Select={1}; Register Address=0x{2:0{3}x}; Value=0x{4:0{5}x};".format(self._bus, self._chip_select, address, self._addr_size*2, value, self._word_size*2))
            else:            
                print("SPI Write: Bus={0}; Chip Select={1}; Register Address=0x{2:0{3}x};".format(self._bus, self._chip_select, address, self._addr_size*2))
                for value in values:
                    print("\tRegister Value=0x{0:0{1}x};".format(value, self._word_size*2))


    def read(self, address):
        """Read from a single APB register.

        Args:
            address (int): register address

        Returns:
            value (int): value of the register

        """
        values = self.read_block(address, length=1)
        value = values[0]
        return value


    def read_block(self, address, length=1):
        """Read multiple values from a starting register address. Max length is 4096 bytes.

        Args:
            address (int): starting register address
            length (int): number of registers to read

        Returns:
            values (list of ints): values of the registers

        """
        dummy_bytes = repack.int_to_array(0, self._word_size*length)    
        if self._apb_mode:
            # create command response byte
            apb_cmd = 0xC6 if self._word_size==1 else 0xC4
            apb_ctrl = apb.create_apb_ctrl('apb', apb_cmd)
            cmd_resp = apb.create_cmd_resp('apb', apb_ctrl, address, length, apb_cmd)
            payload = dummy_bytes
        else:
            raise NotImplementedError
            apb_ctrl = apb.create_apb_ctrl('fd')
            cmd_resp = apb.create_cmd_resp('fd', apb_ctrl)
            address_bytes = repack.int_to_array(address, self._addr_size)
            payload = address_bytes.extend(dummy_bytes)

        data_in = self._handle.transfer(payload, cmd_resp)

        # reformat data_in to an array of bytes/words
        values = repack.array_to_array(data_in, self._word_size, invert=True)

        if self._verbose:
            if len(values) == 1:
                value = values[0]
                print("SPI Read: Bus={0}; Chip Select={1}; Register Address=0x{2:0{3}x}; Value=0x{4:0{5}x};".format(self._bus, self._chip_select, address, self._addr_size*2, value, self._word_size*2))   
            else:
                print("SPI Read: Bus={0}; Chip Select={1}; Register Address=0x{2:0{3}x};".format(self._bus, self._chip_select, address, self._addr_size*2))
                for value in values:
                    print("\tRegister Value=0x{0:0{1}x};".format(value, self._word_size*2))

        return values


    def transfer(self, data_out, keep_cs=False):
        """Perform a full-duplex transaction. Observed ~20uS gap every 128 bytes, probably due to kernel driver.

        Args:
            data_out (list of ints): data bytes to be sent out on MOSI
            keep_cs (bool): True to keep CSb asserted after completion, False to de-assert

        Returns:
            values (list of ints): data bytes returned on MISO

        """
        # create cmd resp buffer for driver
        apb_ctrl = apb.create_apb_ctrl('fd')
        cmd_resp = apb.create_cmd_resp('fd', apb_ctrl)

        data_in = self._handle.transfer(data_out, cmd_resp, keep_cs)

        if self._verbose:
            print("SPI Transfer: Bus={}; Chip Select={};".format(self._bus, self._chip_select))
            for byte_out, byte_in in zip(data_out, data_in):
                print("\tMOSI Byte=0x{:04x}; MISO Byte=0x{:04x};".format(byte_out, byte_in))

        return data_in
# ----------------------------------------------------------------------------
# ----------------------------------------------------------------------------
# i2c.py
# Gabriel Seitz
# 2016-10-26
# contains functions for the I2C class
# ----------------------------------------------------------------------------

# Imports
# ----------------------------------------------------------------------------
from . import periphery
from ...utilities import repack
# ----------------------------------------------------------------------------

# Definitions
# ----------------------------------------------------------------------------
class I2C(object):
    """Communication class for I2C. A handle is created and called directly to issue transactions.

    """

    def __init__(self, bus, i2c_addr, map_size=1, word_size=1, bus_speed=0, repeated_start=True, verbose=False):
        """Instantiate a I2C object and print handle information.

        Args:
            bus (int): I2C bus number, for the AudioHub: "0"=3.3V external, "1"=high speed DUT, "2"=internal SOM, "3"=internal AudioHub
            i2c_addr (int): 8bit I2C address
            bus_speed (int): clock rate, can be "0"=100kHz, "1"=400kHz, "2"=1MHz, "3"=20kHz.
            map_size (int): number of bytes in the memory address pointer
            repeated_start (bool): True to read using a repeated start condition, False for stop-start
            verbose (bool): option to print detailed information

        Returns:
            I2C: i2c object

        """
        self._verbose = verbose
        self._bus = bus
        self._i2c_addr = i2c_addr>>1
        self._map_size = map_size
        self._word_size = word_size
        self._bus_speed = bus_speed
        self._repeated_start = repeated_start

        self._handle = periphery.I2C("/dev/i2c-" +str(self._bus))
        if self._verbose:
            print("Opened handle " +str(self._handle))


    def __del__(self):
        if self._verbose:
            print("Closing handle " +str(self._handle))
        self._handle.close()


    def set_verbose(self, state):
        """Control printing behavior

        Args:
            state (int, bool): turn on or off verbose print statements

        """
        self._verbose = True if state else False


    # def set_speed(self, speed):
    #     """Set the clock rate. Will take effect when the next transaction occurs.

    #     Args:
    #         speed (int): clock rate in kHz **not currently supported, use XI2C**

    #     """
    #     raise NotImplementedError("Use CirrusLink to set the speed.")
    #     self._bus_speed = speed


    # def set_i2c_addr(self, i2c_addr):
    #     """Set the i2c address.

    #     Args:
    #         i2c_addr (int): 8bit I2C address

    #     """
    #     self._i2c_addr = i2c_addr>>1


    # def set_map_size(self, map_size):
    #     """Set the size of the memory address pointer.

    #     Args:
    #         map_size (int): number of bytes in the memory address pointer

    #     """
    #     self._map_size = map_size


    # def set_bus(self, bus):
    #     """Select I2C bus. Will close handle and reopen a new one.

    #     Args:
    #         bus (int): I2C bus number, for the AudioHub: "0"=3.3V external, "1"=high speed DUT, "2"=internal SOM, "3"=internal AudioHUB

    #     """
    #     self._bus = bus
    #     print("Closing handle " +str(self._handle))
    #     self._handle.close()
    #     self._handle = periphery.I2C("/dev/i2c-" +str(self._bus))
    #     print("Opened handle " +str(self._handle))


    def write(self, address, value):
        """Write a single value to a register.

        Args:
            address (int): register address
            value (int): value to write

        """
        self.write_block(address, [value])


    def write_block(self, address, values):
        """Write multiple values to a starting register location.

        Args:
            address (int): starting register address
            values (list of ints): values to write

        """
        # convert register address to list of bytes
        data_out = repack.int_to_array(address, self._map_size, 1)

        # add register value to list of transferred bytes
        for value in values:
            data_out.extend(repack.int_to_array(value, self._word_size, 1))

        msgs = [self._handle.Message(data_out)]
        self._handle.transfer(self._i2c_addr, msgs)

        if self._verbose:
            if len(values) == 1:
                value = values[0]
                print("I2C Write: Bus={0}; I2C Address=0x{1:02x}; Register Address=0x{2:0{3}x}; Value=0x{4:0{5}x};".format(self._bus, self._i2c_addr, address, self._map_size*2, value, self._word_size*2))
            else:
                print("I2C Write: Bus={0}; I2C Address=0x{1:02x}; Register Address=0x{2:0{3}x};".format(self._bus, self._i2c_addr, address, self._map_size*2))
                for value in values:
                    print("\tValue=0x{0:0{1}x};".format(value, self._word_size*2))


    def read(self, address):
        """Read from a single register.

        Args:
            address (int): register address

        Returns:
            value (int): value of the register

        """
        values = self.read_block(address, length=1)
        value = values[0]
        return value


    def read_block(self, address, length=1):
        """Read multiple values from a starting register location.

        Args:
            address (int): starting register address
            length (int): number of registers to read

        Returns:
            values (list of ints): values of the registers

        """
        # convert register address to list of bytes
        reg_array = repack.int_to_array(address, self._map_size, 1)

        # send total number of bytes to be read
        read_bytes = [0x00]*self._word_size*length

        # combine and send message
        if not self._repeated_start:
            msg1 = [self._handle.Message(reg_array)]
            self._handle.transfer(self._i2c_addr, msg1)  # aborted write
            msg2 = [self._handle.Message(read_bytes, read=True)]
            self._handle.transfer(self._i2c_addr, msg2)  # read data
            data_in = msg2[0].data
        else:
            msgs = [self._handle.Message(reg_array), self._handle.Message(read_bytes, read=True)]
            self._handle.transfer(self._i2c_addr, msgs)
            data_in = msgs[1].data

        # convert list of bytes to list of data elements
        values = repack.array_to_array(data_in, self._word_size)

        if self._verbose:
            if len(values) == 1:
                value = values[0]
                print("I2C Read: Bus={0}; I2C Address=0x{1:02x}; Register Address=0x{2:0{3}x}; Value=0x{4:0{5}x};".format(self._bus, self._i2c_addr, address, self._map_size*2, value, self._word_size*2))
            else:
                print("I2C Read: Bus={0}; I2C Address=0x{1:02x}; Register Address=0x{2:0{3}x};".format(self._bus, self._i2c_addr, address, self._map_size*2))
                for value in values:
                    print("\tValue=0x{0:0{1}x};".format(value, self._word_size*2))

        return values
# ----------------------------------------------------------------------------
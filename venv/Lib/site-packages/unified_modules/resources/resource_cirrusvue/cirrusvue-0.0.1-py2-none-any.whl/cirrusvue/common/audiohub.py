# ----------------------------------------------------------------------------
# audiohub.py
# Gabriel Seitz
# 2016-11-15
# contains the AudioHub Version 1 class
# ----------------------------------------------------------------------------

# Imports
# ----------------------------------------------------------------------------
#from cirrusvue.core.utilities.compatability import *
from cirrusvue.core.utilities import delay, repack
from .generic import GenericDevice
# ----------------------------------------------------------------------------

# Definitions
# ----------------------------------------------------------------------------
class AudioHub(object):
    """Device class for AudioHub. Contains other device classes.
    
    """

    lookup_mux = {}
    mclk = 'MCLK'
    sclk = 'SCLK'
    lrck = 'LRCK'
    sdata = 'SDATA'
    pdm_clk = 'PDM_CLK'
    pdm_data = 'PDM_DATA'

    # MCLK mux options
    lookup_mux[mclk] = {
    '12 MHz': 0x02,
    '12 MHz clock': 0x02,
    '12.288 MHz': 0x03,
    '12.288 MHz clock': 0x03,
    '11.2896 MHz': 0x04,
    '11.2896 MHz clock': 0x04,
    'SAIO_MCLK1': 0x05,
    'SAIO_MCLK2': 0x06,
    'PDMIO_CLK1': 0x07,
    'PDMIO_CLK2': 0x08,
    'DEV_MCLK2': 0x09,
    'PLL1': 0x0A,
    'PLL1 CLK_OUT': 0x0A,
    'PLL2': 0x0B,
    'PLL2 CLK_OUT': 0x0B,
    'SPDIF_RX_RMCK': 0x0C,
    'S/PDIF Rx RMCK': 0x0C,
    'AC0': 0x0D,
    'AC0 MCLK': 0x0D,
    '24 MHz': 0x0E,
    '24 MHz clock': 0x0E,
    '24.576 MHz': 0x0F,
    '24.576 MHz clock': 0x0F,
    '22.5792 MHz': 0x10,
    '22.5792 MHz clock': 0x10
    }

    # SCLK mux options
    lookup_mux[sclk] = {
    '2.4 MHz': 0x02,
    '2.4 MHz clock': 0x02,
    'SAI': 0x03,
    'SAI SCLK': 0x03,
    'SAO': 0x04,
    'SAO SCLK': 0x04,
    'DEV_AIF1': 0x05,
    'DEV_AIF1 SCLK': 0x05,
    'DEV_AIF2': 0x06,
    'DEV_AIF2 SCLK': 0x06,
    'DEV_AIF3': 0x07,
    'DEV_AIF3 SCLK': 0x07,
    'PLL1': 0x08,
    'PLL1 CLK_OUT': 0x08,
    'PLL2': 0x09,
    'PLL2 CLK_OUT': 0x09,
    'SPDIF_RX_ISCLK': 0x0A,
    'SPDIF Rx ISCLK': 0x0A,
    'SPDIF_RX': 0x0B,
    'SPDIF Rx OSCLK1': 0x0B,
    'SPDIF_TX': 0x0C,
    'SPDIF Tx ISCLK': 0x0C,
    'XUSB': 0x0D,
    'USB Audio SCLK': 0x0D,
    'AC0': 0x0E,
    'AC0 SCLK': 0x0E
    }

    # LRCK mux options
    lookup_mux[lrck] = {
    '48 kHz': 0x02,
    '48 kHz clock': 0x02,
    'SAI': 0x03,
    'SAI LRCK': 0x03,
    'SAO': 0x04,
    'SAO LRCK': 0x04,
    'DEV_AIF1': 0x05,
    'DEV_AIF1 LRCK': 0x05,
    'DEV_AIF2': 0x06,
    'DEV_AIF2 LRCK': 0x06,
    'DEV_AIF3': 0x07,
    'DEV_AIF3 LRCK': 0x07,
    'SPDIF_RX_ILRCK': 0x08,
    'SPDIF Rx ILRCK': 0x08,
    'SPDIF_RX': 0x09,
    'SPDIF Rx OLRCK1': 0x09,
    'SPDIF_TX': 0x0A,
    'SPDIF Tx ILRCK': 0x0A,
    'XUSB': 0x0B,
    'USB Audio LRCK': 0x0B,
    'AC0': 0x0C,
    'AC0 LRCK': 0x0C
    }

    # SDATA mux options
    lookup_mux[sdata] = {
    'SAI_DATA1': 0x02,
    'SAI DATA1': 0x02,
    'SAI_DATA2': 0x03,
    'SAI DATA2': 0x03,
    'SAI_DATA3': 0x04,
    'SAI DATA3': 0x04,
    'SAI_DATA4': 0x05,
    'SAI DATA4': 0x05,
    'DEV_AIF1_SDATA1': 0x06,
    'DEV_AIF1 SDATA1': 0x06,
    'DEV_AIF1_SDATA2': 0x07,
    'DEV_AIF1 SDATA2': 0x07,
    'DEV_AIF2_SDATA1': 0x08,
    'DEV_AIF2 SDATA1': 0x08,
    'DEV_AIF2_SDATA2': 0x09,
    'DEV_AIF2 SDATA2': 0x09,
    'DEV_AIF3_SDATA1': 0x0A,
    'DEV_AIF3 SDATA1': 0x0A,
    'DEV_AIF3_SDATA2': 0x0B,
    'DEV_AIF3 SDATA2': 0x0B,
    'SPDIF_RX_SDOUT1': 0x0C,
    'SPDIF Rx SDOUT1': 0x0C,
    'XUSB_SDOUT1': 0x0D,
    'USB Audio SDOUT1': 0x0D,
    'XUSB_SDOUT2': 0x0E,
    'USB Audio SDOUT2': 0x0E,
    'AC0_SDOUT1': 0x0F,
    'AC0 SDOUT1': 0x0F,
    'AC0_SDOUT2': 0x10,
    'AC0 SDOUT2': 0x10,
    'AC0_SDOUT3': 0x11,
    'AC0 SDOUT3': 0x11,
    'AC0_SDOUT4': 0x12,
    'AC0 SDOUT4': 0x12
    }

    # PDM clock mux options
    lookup_mux[pdm_clk] = {
    'PDMIO1': 0x02,
    'PDMIO CLK1': 0x02,
    'PDMIO2': 0x03,
    'PDMIO CLK2': 0x03,
    'DEV_PDM1': 0x04,
    'DEV_PDM1 CLK': 0x04,
    'DEV_PDM2': 0x05,
    'DEV_PDM2 CLK': 0x05,
    'DEV_PDM3': 0x06,
    'DEV_PDM3 CLK': 0x06,
    'DEV_PDM4': 0x07,
    'DEV_PDM4 CLK': 0x07,
    'DEV_PDM5': 0x08,
    'DEV_PDM5 CLK': 0x08,
    'DEV_PDM6': 0x09,
    'DEV_PDM6 CLK': 0x09,
    'DEV_PDM7': 0x0A,
    'DEV_PDM7 CLK': 0x0A
    }

    # PDM DATA mux options
    lookup_mux[pdm_data] = {
    'PDMIO1': 0x02,
    'PDMIO1 DATA': 0x02,
    'PDMIO2': 0x03,
    'PDMIO2 DATA': 0x03,
    'DEV_PDM1': 0x04,
    'DEV_PDM1 DATA': 0x04,
    'DEV_PDM2': 0x05,
    'DEV_PDM2 DATA': 0x05,
    'DEV_PDM3': 0x06,
    'DEV_PDM3 DATA': 0x06,
    'DEV_PDM4': 0x07,
    'DEV_PDM4 DATA': 0x07,
    'DEV_PDM5': 0x08,
    'DEV_PDM5 DATA': 0x08,
    'DEV_PDM6': 0x09,
    'DEV_PDM6 DATA': 0x09,
    'DEV_PDM7': 0x0A,
    'DEV_PDM7 DATA': 0x0A
    }

    def __init__(self, link, dev_map=None, rev=None):
        self._link = link
        self.fpga = GenericDevice(link.get_i2c(bus=2, i2c_addr=0x38), GenericDevice.definition_path(__file__, ['audiohub_fpga.xml']))
        self.io = GenericDevice(link.get_i2c(bus=0, i2c_addr=0xee), GenericDevice.definition_path(__file__, ['tca9539_hub_exp1.xml']))
        self.spdif_tx = GenericDevice(link.get_i2c(bus=0, i2c_addr=0x22), GenericDevice.definition_path(__file__, ['cs8406.xml']))
        self.spdif_rx = GenericDevice(link.get_i2c(bus=0, i2c_addr=0x20), GenericDevice.definition_path(__file__, ['cs8422.xml']))
        self.pll1 = GenericDevice(link.get_i2c(bus=0, i2c_addr=0x9c), GenericDevice.definition_path(__file__, ['cs2300.xml']))
        self.pll2 = GenericDevice(link.get_i2c(bus=0, i2c_addr=0x9e), GenericDevice.definition_path(__file__, ['cs2300.xml']))
        self.dev_map = dev_map
        
        if rev == 'RevX':
            raise NotImplementedError
            #self.swm = SoundWireMaster(driver='lmemio')   
        
# ----------------------------------------------------------------------------
# system commands
# ----------------------------------------------------------------------------
    def initialize(self):
        """Perform an initial set of writes.

        """
        self.fpga.write_field('DEV_GLOBAL_HIZ', 0)
        self.io.write_register(0x06, 0x00)
        self.io.write_register(0x07, 0x00)


    def reset_dut(self):
        """Toggle the DUT_RESET pin.

        """
        self.fpga.write_field('FORCE_DUT_RESETN', 1)
        delay.delay_s(.1)
        self.fpga.write_field('FORCE_DUT_RESETN', 0)
        delay.delay_s(.2)  # wait for reset line to deassert


    def reset_sys(self):
        """Toggle the SYS_RESET pin.

        """
        self.fpga.write_field('FORCE_SYS_RESETN', 1)
        delay.delay_s(.1)
        self.fpga.write_field('FORCE_SYS_RESETN', 0)
        delay.delay_s(.2)  # wait for reset line to deassert
# ----------------------------------------------------------------------------

# ----------------------------------------------------------------------------
# configure methods
# ----------------------------------------------------------------------------
    def configure_usb(self, mode, format='I2S'):
        """Configure the USB Audio Module

        Args:
            mode (int): selects sample rate and bits per channel
                - Mode 0: 44.1kHz sample rate, 32 bits per word (MCLK set to 11.2896MHz)
                - Mode 1: 48kHz sample rate, 25 bits per word (MCLK set to 12MHz)
                - Mode 2: 48kHz sample rate, 32 bits per word (MCLK set to 12.288MHz)
            format(str): selects between "I2S" and "TDM" modes of operation

        """
        # configure I2S vs TDM settings
        if format == 'I2S':
            lookup = {0: 4, 1: 2, 2: 3}
            self.fpga.write_field('XUSB_MCLK_SEL', lookup[mode])
            self.fpga.write_field('XUSB_MCLK_RATE', 0x01)   # ~12MHz master clock
            self.fpga.write_field('XUSB_TDM', 0x00)
            self.fpga.write_field('XUSB_CLK_FAM', mode)
            self.fpga.write_field('XUSB_LRCK_RATE', 0x00)  # ~48kHz
            self.fpga.write_field('XUSB_LRCK_MODE', 0x00)
            self.fpga.write_field('XUSB_LRCK_POL', 0x01)
            self.fpga.write_field('XUSB_LRCK_SHIFT', 0x01)
        elif format == 'TDM':
            lookup = {0: 0x10, 1: 0x0e, 2: 0x0f}
            self.fpga.write_field('XUSB_MCLK_SEL', lookup[mode])
            self.fpga.write_field('XUSB_MCLK_RATE', 0x00)   # ~24MHz master clock
            self.fpga.write_field('XUSB_TDM', 0x01)
            self.fpga.write_field('XUSB_CLK_FAM', mode)
            self.fpga.write_field('XUSB_LRCK_RATE', 0x00)  # ~48kHz
            self.fpga.write_field('XUSB_LRCK_MODE', 0x02)
            self.fpga.write_field('XUSB_LRCK_POL', 0x00)
            self.fpga.write_field('XUSB_LRCK_SHIFT', 0x00)
        else:
            raise ValueError(format)


    def configure_pll(self, pll, out_clk):
        """configure a PLL to generate a clock based on the internal 48kHz clock

        Args:
            pll (int, string): select between PLL1 and PLL2
            out_clk (int, float): output clock in MHz

        """
        if pll in [1, '1', 'pll1', 'PLL1']:
            pll = self.pll1
            name = 'PLL1'
        elif pll in [2, '2', 'pll2', 'PLL2']:
            pll = self.pll2
            name = 'PLL2'
        else:
            raise ValueError(pll)

        self.fpga.write_field(name +'_REF_CLK_SEL', 2)  # 48kHz

        coef = int(round(out_clk/.048*(2**20)))
        coefs = [(coef>>(8*i))&0xff for i in range(4)]

        pll.write_register(0x05, 0x09)  # freeze register writes
        pll.write_register(0x02, 0x00)  # enable AUX, enable CKL_OUT
        pll.write_register(0x03, 0x07)  # Ratio Mod = 1, enable PLL Lock, enable CP
        pll.write_register(0x06, coefs[3])  # Byte 3
        pll.write_register(0x07, coefs[2])  # Byte 2
        pll.write_register(0x08, coefs[1])  # Byte 1
        pll.write_register(0x09, coefs[0])  # Byte 0
        pll.write_register(0x16, 0x10)  # disable clock skipping, AUX_OUT is PUSH-PULL, enable CP
        pll.write_register(0x17, 0x08)  # clocks low when unlocked, high precision 12.20
        pll.write_register(0x1e, 0x70)  # min loop bandwidth = 128Hz
        pll.write_register(0x05, 0x01)  # clear freeze bit, register writes take effect, enable CP ]


    def configure_spdif(self, master=True, src=False, clk_ratio=256):
        """Configures the S/PDIF RX and TX. An internal PLL generates the TX MCLK = LRCKx256.
        1) Using the SRC means the LRCK is fixed at XTI/clk_ratio and therefore 
        the rate does not match the input stream.
        2) Bypassing the SRC means LRCK and RMCK match the input stream but are asynchronous 
        to the rest of the system unless RMCK is used as the MCLK.

        Args:
            master (bool, int): sets whether the S/PDIF RX masters the serial audio clocks
            src (bool, int): sets whether the ASRC is in the path or bypassed
            clk_ratio (int): ratio of MCLK/LRCK. Sets the LRCK rate if using the SRC otherwise sets the RMCK rate.

        """
        lookup_clk_ratio = {64:0, 96:1, 128:2, 192:3, 256:4, 384:5, 512:6, 768:7, 1024:8}
        if src:
            self.spdif_rx.write_field('SAO_CLK', lookup_clk_ratio[clk_ratio])  # SAO_MCLK/OLRCK1 ratio
            self.spdif_rx.write_field('SAO_MCLK', 0)  # XTI XTO
            self.spdif_rx.write_field('SRCD', 1)  # AES3 -> SRC
            self.spdif_rx.write_field('SDOUT1', 0)  # SRC -> SDOUT1
        else:
            self.spdif_rx.write_field('RMCK_CTL', 0)  # RMCK output from frame rate
            self.spdif_rx.write_field('RMCK', lookup_clk_ratio[clk_ratio])  # RMCK = 256xFsi
            self.spdif_rx.write_field('SAO_MCLK', 1)  # Recovered MCLK
            self.spdif_rx.write_field('SDOUT1', 1)  # AES3 -> SDOUT1
        self.spdif_rx.write_field('SOFSEL1', 1)  # I2S
        self.spdif_rx.write_field('SOMS1', master)  # SPDIF RX masters OSCLK1&OLRCK1 or not
        self.spdif_rx.write_field('PDN', 0)

        # setup SPDIF TX
        self.spdif_tx.write_register(0x03, 0x40)  # TX disabled
        self.spdif_tx.write_register(0x01, 0x00)  # default, AES3 not muted
        self.spdif_tx.write_register(0x02, 0x00)  # AES3 operates as stereo
        self.spdif_tx.write_register(0x05, 0x05)  # set as 24 bit I2S slave (LRCK is high for right channel)
        self.spdif_tx.write_register(0x04, 0x40)  # power up device, OMCK = 256 x Fs
        self.spdif_tx.write_register(0x03, 0x00)  # TX enabled, normal operation
    
    
    def program_board_id(self, value, bus=0, addr=0xA0):
        """Program the EEPROM with a Board ID value.
        
        """
        eeprom = GenericDevice(self._link.get_i2c(bus=bus, i2c_addr=addr, map_size=2))
        
        board_id_bytes = repack.int_to_array(value, 4)
        
        eeprom.write_register(12, board_id_bytes[3])  # bits 31-24
        delay.delay_ms(10)
        eeprom.write_register(13, board_id_bytes[2])  # bits 23-16
        delay.delay_ms(10)
        eeprom.write_register(14, board_id_bytes[1])  # bits 15-8
        delay.delay_ms(10)
        eeprom.write_register(15, board_id_bytes[0])  # bits 7-0
        delay.delay_ms(10)
    
    
    def read_board_id(self, bus=0, addr=0xA0):
        """Read the EEPROM that contains the board ID.
        
        """
        eeprom = GenericDevice(self._link.get_i2c(bus=bus, i2c_addr=addr, map_size=2))
        
        board_id_bytes = []        
        board_id_bytes.append(eeprom.read_register(12))  # bits 31-24
        board_id_bytes.append(eeprom.read_register(13))  # bits 23-16
        board_id_bytes.append(eeprom.read_register(14))  # bits 15-8
        board_id_bytes.append(eeprom.read_register(15))  # bits 7-0
        
        board_id_bytes.reverse()
        board_id = repack.array_to_int(board_id_bytes)

        return board_id
# ----------------------------------------------------------------------------

# ----------------------------------------------------------------------------
# low level routing methods
# ----------------------------------------------------------------------------
    def _mux_mclk(self, pin, source=None):
        """Setup one MCLK signal (direction + mux source)

        Args:
            pin (str): pin name to configure
            source (str): name of mux source, set to 'None' for Hi-Z

        """
        pin_name = pin  # no modifications required?

        if source is None:
            self.fpga.write_field(pin_name+ '_DIR', 0x01)
            if 'SAIO' in pin:
                    self.io.write_field(pin_name + '_DIR_3V3', 0x00)
        else:
            if 'SAIO' in pin:
                    self.io.write_field(pin_name + '_DIR_3V3', 0x01)
            self.fpga.write_field(pin_name + '_SEL', self.lookup_mux[self.mclk][source])
            if 'DEV' in pin:
                self.fpga.write_field(pin_name + '_FUNC', 0x02)
            if 'DEV' in pin or 'SAIO' in pin:
                self.fpga.write_field(pin_name + '_DIR', 0x00)


    def _mux_sclk(self, pin, source=None, prefix=None):
        """Setup one SCLK signal (direction + mux source)

        Args:
            pin (str): pin name to configure
            source (str): name of mux source, set to 'None' for Hi-Z
            prefix (str): set to "I" to use "SPDIF_RX_ISCLK"

        """
        # Resolve naming difference for SPDIF (e.g. 'x_OSCLK' vs 'x_SCLK')
        if prefix is None:
            if 'SPDIF' in pin:
                if 'RX' in pin:
                    prefix = 'O'
                elif 'TX' in pin:
                    prefix = 'I'
                else:
                    raise ValueError(pin)
            else:
                prefix=''
        pin_name = pin + '_' + prefix + 'SCLK'

        if source is None:
            self.fpga.write_field(pin_name+ '_DIR', 0x01)
            if 'SAI' in pin or 'SAO' in pin:
                    self.io.write_field(pin_name + '_DIR_3V3', 0x00)
        else:
            if 'SAI' in pin or 'SAO' in pin:
                    self.io.write_field(pin_name + '_DIR_3V3', 0x01)
            self.fpga.write_field(pin_name + '_SEL', self.lookup_mux[self.sclk][source])
            if 'DEV' in pin:
                self.fpga.write_field(pin_name + '_FUNC', 0x02)
            self.fpga.write_field(pin_name + '_DIR', 0x00)


    def _mux_lrck(self, pin, source=None, prefix=None):
        """Setup one LRCK signal (direction + mux source)

        Args:
            pin (str): pin name to configure
            source (str): name of mux source, set to 'None' for Hi-Z
            prefix (str): set to "I" if trying to use "SPDIF_RX_ILRCK"

        """
        # Resolve naming difference for SPDIF (e.g. 'x_OLRCK' vs 'x_LRCK')
        if prefix is None:
            if 'SPDIF' in pin:
                if 'RX' in pin:
                    prefix = 'O'
                elif 'TX' in pin:
                    prefix = 'I'
                else:
                    raise ValueError(pin)
            else:
                prefix=''
        pin_name = pin + '_' + prefix + 'LRCK'

        if source is None:
            self.fpga.write_field(pin_name+ '_DIR', 0x01)
            if 'SAI' in pin or 'SAO' in pin:
                    self.io.write_field(pin_name + '_DIR_3V3', 0x00)
        else:
            if 'SAI' in pin or 'SAO' in pin:
                    self.io.write_field(pin_name + '_DIR_3V3', 0x01)
            self.fpga.write_field(pin_name + '_SEL', self.lookup_mux[self.lrck][source])
            if 'DEV' in pin:
                self.fpga.write_field(pin_name + '_FUNC', 0x02)
            self.fpga.write_field(pin_name + '_DIR', 0x00)


    def _mux_sdata(self, pin, source=None):
        """Setup one PCM Data signal (direction + mux source)

        Args:
            pin (str): pin name to configure
            source (str): name of mux source, set to 'None' for Hi-Z

        """
        pin_name = pin  # no modifications required?

        if source is None:
            if 'DEV' in pin:
                self.fpga.write_field(pin_name+ '_DIR', 0x01)
        else:
            self.fpga.write_field(pin_name + '_SEL', self.lookup_mux[self.sdata][source])
            if 'DEV' in pin:
                self.fpga.write_field(pin_name + '_FUNC', 0x02)
                self.fpga.write_field(pin_name + '_DIR', 0x00)


    def _mux_pdm_clk(self, pin, source=None):
        """Setup one PDM Clock signal (direction + mux source)

        Args:
            pin (str): pin name to configure
            source (str): name of mux source, set to 'None' for Hi-Z

        """
        pin_name = pin + '_CLK'

        if source is None:
            self.fpga.write_field(pin_name+ '_DIR', 0x01)
            if 'PDMIO' in pin:
                    self.io.write_field(pin_name + '_DIR_3V3', 0x00)
        else:
            if 'PDMIO' in pin:
                    self.io.write_field(pin_name + '_DIR_3V3', 0x01)
            self.fpga.write_field(pin_name + '_SEL', self.lookup_mux[self.pdm_clk][source])
            if 'DEV' in pin:
                self.fpga.write_field(pin_name + '_FUNC', 0x02)
            self.fpga.write_field(pin_name + '_DIR', 0x00)


    def _mux_pdm_data(self, pin, source=None):
        """Setup one PDM Clock signal (direction + mux source)

        Args:
            pin (str): pin name to configure
            source (str): name of mux source, set to 'None' for Hi-Z

        """
        pin_name = pin + '_DATA'

        if source is None:
            self.fpga.write_field(pin_name+ '_DIR', 0x01)
            if 'PDMIO' in pin:
                    self.io.write_field(pin_name + '_DIR_3V3', 0x00)
        else:
            if 'PDMIO' in pin:
                    self.io.write_field(pin_name + '_DIR_3V3', 0x01)
            self.fpga.write_field(pin_name + '_SEL', self.lookup_mux[self.pdm_data][source])
            if 'DEV' in pin:
                self.fpga.write_field(pin_name + '_FUNC', 0x02)
            self.fpga.write_field(pin_name + '_DIR', 0x00)
# ----------------------------------------------------------------------------


# ----------------------------------------------------------------------------
# high level routing methods
# ----------------------------------------------------------------------------
    def route_mclk(self, source):
        """Route a single MCLK source to everything!

        Args:
            source (str): source of the master clock

        """
        for name in ['SAIO_MCLK1', 'SAIO_MCLK2', 'SPDIF_RX_XTI',
                            'AC0_MCLK', 'XUSB_MCLK', 'DEV_MCLK1', 'DEV_MCLK2']:
            if name in source:
                self._mux_mclk(name)  # input (can't source itself)
            else:
                self._mux_mclk(name, source)


    def route_saio(self, dev_port, master):
        """Connect SAIO headers to a device AIF port. SAO is always slaved.
        DEV_AIFx_SDATA1 is routed from SAI SDATA1
        DEV_AIFx_SDATA2 is routed to SAO SDATA1

        Args:
            device (string): device AIF port, will attempt to lookup mapping
            master (bool): specifies clock direction, set True for device master

        """
        # attempt to lookup device <-> audiohub mapping
        if self.dev_map is not None:
            try:
                dev_port = self.dev_map[dev_port]
            except KeyError:
                pass

        # route device and SAI clocks
        if master == 1:
            self._mux_sclk(dev_port)
            self._mux_lrck(dev_port)
            self._mux_sclk('SAI', dev_port)
            self._mux_lrck('SAI', dev_port)
        elif master == 0:
            self._mux_sclk('SAI')
            self._mux_lrck('SAI')
            self._mux_sclk(dev_port, 'SAI')
            self._mux_lrck(dev_port, 'SAI')
        else:
            raise ValueError(master)

        # route data and SAO clocks (always slave)
        self._mux_sclk('SAO', dev_port)
        self._mux_lrck('SAO', dev_port)
        self._mux_sdata(dev_port + '_SDATA1', 'SAI_DATA1')
        self._mux_sdata(dev_port + '_SDATA2')
        self._mux_sdata('SAO_DATA1', dev_port + '_SDATA2')


    def route_spdif(self, dev_port, master):
        """Connect S/PDIF RX and TX to a device AIF port. S/PDIF TX is always slaved.
        DEV_AIFx_SDATA1 is routed from SPDIF_RX_SDOUT1
        DEV_AIFx_SDATA2 is routed to SPDIF_TX_SDIN

        Args:
            device (string): device AIF port, will attempt to lookup mapping
            master (bool): specifies clock direction, set True for device master

        """
        # attempt to lookup device <-> audiohub mapping
        if self.dev_map is not None:
            try:
                dev_port = self.dev_map[dev_port]
            except KeyError:
                pass

        # route S/PDIF RX and device clocks
        if master == 1:
            self._mux_sclk(dev_port)
            self._mux_lrck(dev_port)
            self._mux_sclk('SPDIF_RX', dev_port)
            self._mux_lrck('SPDIF_RX', dev_port)
        elif master == 0:
            self._mux_sclk('SPDIF_RX')
            self._mux_lrck('SPDIF_RX')
            self._mux_sclk(dev_port, 'SPDIF_RX')
            self._mux_lrck(dev_port, 'SPDIF_RX')
        else:
            raise ValueError(master)

        # route data and SPDIF clocks (always slave)
        self._mux_sclk('SPDIF_TX', dev_port)
        self._mux_lrck('SPDIF_TX', dev_port)
        self._mux_sdata(dev_port + '_SDATA1', 'SPDIF_RX_SDOUT1')
        self._mux_sdata(dev_port + '_SDATA2')
        self._mux_sdata('SPDIF_TX_SDIN', dev_port + '_SDATA2')


    def route_usb(self, dev_port):
        """Connect USB Audio Module (master only) to a device AIF port
        DEV_AIFx_SDATA1 is routed from USB Audio SDOUT1
        DEV_AIFx_SDATA2 is routed to USB Audio SDIN1

        Args:
            device (string): device AIF port, will attempt to lookup mapping
            master (bool): specifies clock direction, set True for device master

        """
        # attempt to lookup device <-> audiohub mapping
        if self.dev_map is not None:
            try:
                dev_port = self.dev_map[dev_port]
            except KeyError:
                pass

        # route clocks and data (USB always master)
        self._mux_sclk(dev_port, 'XUSB')
        self._mux_lrck(dev_port, 'XUSB')
        self._mux_sdata(dev_port + '_SDATA1', 'XUSB_SDOUT1')
        self._mux_sdata(dev_port + '_SDATA2')
        self._mux_sdata('XUSB_SDIN1', dev_port + '_SDATA2')


    def route_pdmio(self, hdr, dev_port, clk_dir, data_dir):
        """Connect a PDMIO header to a device PDM port.

        Args:
            hdr (int): PDMIO header, can be 1 or 2
            dev_port (string): device PDM port, will attempt to lookup mapping
            clk_dir (bool): specifies clock direction, set True for device -> HDR
            data_dir (bool): specifies data direction, set True for device -> HDR

        """
        # attempt to lookup device <-> audiohub mapping
        if self.dev_map is not None:
            try:
                dev_port = self.dev_map[dev_port]
            except KeyError:
                pass

        # get name of PDMIO header
        if hdr in [1, '1', 'PDMIO1', 'pdmio1']:
            hdr_name = 'PDMIO1'
        elif hdr in [2, '2', 'PDMIO2', 'pdmio2']:
            hdr_name = 'PDMIO2'
        else:
            raise ValueError(hdr)

        # route PDM CLK
        if clk_dir == True:
            self._mux_pdm_clk(dev_port)
            self._mux_pdm_clk(hdr_name, dev_port)
        elif clk_dir == False:
            self._mux_pdm_clk(hdr_name)
            self._mux_pdm_clk(dev_port, hdr_name)
        else:
            raise ValueError(clk_dir)

        # route PDM Data
        if data_dir == True:
            self._mux_pdm_data(dev_port)
            self._mux_pdm_data(hdr_name, dev_port)
        elif data_dir == False:
            self._mux_pdm_data(hdr_name)
            self._mux_pdm_data(dev_port, hdr_name)
        else:
            raise ValueError(data_dir)
# ----------------------------------------------------------------------------
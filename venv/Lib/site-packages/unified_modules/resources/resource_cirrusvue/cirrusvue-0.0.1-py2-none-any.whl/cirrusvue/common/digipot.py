# ----------------------------------------------------------------------------
# digipot.py
# Dakota Koelling
# 2018-07-16
# contains classes for a Digipot
# ----------------------------------------------------------------------------

# Imports
# ----------------------------------------------------------------------------
from .generic import GenericDevice
import math
# ----------------------------------------------------------------------------

# Definitions
# ----------------------------------------------------------------------------


class Digipot(GenericDevice):
    """Digipot device class

    """

    def __init__(self, number: int, com, definition_file=None, page_address=None):
        """instantiate a generic I2C device object

        Args:
            number (int): Digipot number
            com (obj): commmunication object containing write() and read() methods
            definition_file (list): path to device definition file
            page_address (int): address of page register

        """

        self.number = number
        GenericDevice.__init__(com, definition_file, page_address)

    def set_digpot(self, res_ohms: float):
        """set_digpot(res_ohms)

        NOTE: To set a DIGPOT into standby, pass in "inf" for "res_ohms". Its
        resistance is about 10Mohms.

        [INPUTS]
          res_ohms (float): value to set DIGPOT

        ex: eeb.set_digpot(eeb.MIC1_BIAS_POT, 1500)  # set MIC1_BIAS DIGPOT to 1.5kohms
        """
        digpot_slope = self.slope
        digpot_intercept = self.intercept

        if self.channel == 'A':
            channel_code = 0x10  # Digipot pin O1 is tied to the shutdown pin, so bit 4 must stay high
        elif self.channel == 'B':
            channel_code = 0x90  # Digipot pin O1 is tied to the shutdown pin, so bit 4 must stay high
        else:
            assert False, 'Digipot channel must be ''A'' or ''B''! Current channel is ' + self.channel

        if isempty(digpot_slope) or isempty(digpot_intercept):
            error('Digipot slope and intercept are not found for ' + self.name + ' (map name: ' + self.map_name + ')!!')

        if res_ohms == inf:
            self.com.write('20', '00')  # Set the shutdown bit (shuts down both channels of the DIGPOT)
            self.value = math.inf  # store value to DIGPOT
        else:
            value_dec = (res_ohms - digpot_intercept) / digpot_slope  # calculate the value that needs to be written to the DIGPOT
            if value_dec > 255:
                value_dec = 255  # force to maximum
                digpot_lim = (digpot_slope * value_dec) + digpot_intercept
                fprintf(2, 'WARNING: Digipot minimum is ' + str(digpot_lim) + ' ohms!\n')
                fprintf(2, '         Setting ' + str(digpot_lim) + ' ohms instead...\n')
            elif value_dec < 0:
                value_dec = 0  # force to minimum
                digpot_lim = (digpot_slope * value_dec) + digpot_intercept
                fprintf(2, 'WARNING: Digipot maximim is ' + str(digpot_lim) + ' ohms!\n')
                fprintf(2, '         Setting ' + str(digpot_lim) + ' ohms instead...\n')
            else:
                value_dec = round(value_dec)  # round to nearest integer if in range

            self.com.write(channel_code, value_dec)  # write to DIGPOT

            cal_ohms = (value_dec * digpot_slope) + digpot_intercept  # Calculate actual resistance using calibration data
            self.value = cal_ohms  # store value to DIGPOT

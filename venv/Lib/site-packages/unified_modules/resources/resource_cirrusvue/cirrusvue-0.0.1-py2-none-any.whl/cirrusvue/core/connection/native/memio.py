# ----------------------------------------------------------------------------
# memio.py
# Gabriel Seitz
# 2017-3-6
# contains functions for the direct memory access class
# ----------------------------------------------------------------------------

# Imports
# ----------------------------------------------------------------------------
from . import periphery
# ----------------------------------------------------------------------------

# Attributes
# ----------------------------------------------------------------------------
def modify_address(access):
    from functools import wraps
    @wraps(access)
    def wrapper(self, register, *args, **kwargs):
        if self._stride*register > self._size or register < 0:
            raise ValueError("Attempted access to address ({:#x}) is outside of memory space ({:#x})".format(register, self._size))

        address = self._stride*register  # calculate address in physical memory

        return access(self, address, *args, **kwargs)  # call and return original function

    return wrapper
# ----------------------------------------------------------------------------

# Definitions
# ----------------------------------------------------------------------------
class MMIO(object):
    """Communication class for direct memory access. A handle is created and called directly to issue transactions.
    
    """

    def __init__(self, base, size, stride=4, verbose=False):
        """Instantiate a LinuxMemIO object and print handle information.

        Args:
            base (int): starting address
            size (int): total number of registers 
            stride (int): number of addresses that make up a single register
            verbose (bool): option to print detailed information

        Returns:
            LinuxMemIO: memio handle.

        """
        self._verbose = verbose
        self._base = base
        self._size = size * stride  # size of memory block
        self._stride = stride

        self._handle = periphery.MMIO(base, self._size)
        if self._verbose:
            print("Opened handle " +str(self._handle))


    def __del__(self):
        if self._verbose:
            print("Closing handle " +str(self._handle))
        self._handle.close()


    def set_verbose(self, state):
        """Control printing behavior

        Args:
            state (int, bool): turn on or off verbose print statements

        """
        self._verbose = True if state else False


    @modify_address
    def write(self, register, value, word_size=4):
        """Write a single value to a register.

        Args:
            register (int): register address
            value (int): value to write

        """
        if word_size == 4:
            self._handle.write32(register, value)
        elif word_size == 2:
            self._handle.write16(register, value)
        elif word_size == 1:
            self._handle.write8(register, value)
        else:
            raise ValueError(word_size)

        if self._verbose:
            print("MMIO Write: Base Address={:#x}; Register Address={:#x}; Value={:#x};".format(self._base, register, value))


    @modify_address
    def read(self, register, word_size=4):
        """Read from a single register.

        Args:
            register (int): register address
            
        Returns:
            value (int): value of the register
        
        """
        if word_size == 4:
            value = self._handle.read32(register)
        elif word_size == 2:
            value = self._handle.read16(register)
        elif word_size == 1:
            value = self._handle.read8(register)
        else:
            raise ValueError(word_size)

        if self._verbose:
            print("MMIO Read: Base Address={:#x}; Register Address={:#x}; Value={:#x};".format(self._base, register, value))

        return value
# ----------------------------------------------------------------------------







































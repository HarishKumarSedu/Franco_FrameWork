# ----------------------------------------------------------------------------
# spi.py
# Gabriel Seitz
# 2018-07-30
# contains the communication class that implements the Virtual SPI protocol
# ----------------------------------------------------------------------------

# Imports
# ----------------------------------------------------------------------------
# ----------------------------------------------------------------------------

# Definitions
# ----------------------------------------------------------------------------
class SPI(object):
    """Communication class for SPI.

    """

    def __init__(self, bus, chip_select, addr_size=4, word_size=4, speed=12, apb_mode=True, verbose=False):
        """Instantiate an SPI object.

        Args:
            bus (int): SPI bus number, for the AudioHub "1" is the only bus
            chip_select (int): number corresponding to a chip select pin
            addr_size (int): number of bytes to address a register
            data_size (int): number of bytes in a register
            speed (int): clock rate in MHz
            apb_mode (bool): 'True' to use the APB format or 'False' to send address bytes then value bytes
            verbose (bool): option to print detailed information

        Returns:
            SPI: spi handle.

        """
        self._verbose = verbose
        self._bus = bus
        self._chip_select = chip_select
        self._addr_size = addr_size
        self._word_size = word_size
        self._speed = speed * 1000000
        self._apb_mode = apb_mode
        self._cache = {}
        self._addr_stride=1


    def set_verbose(self, state):
        """Control printing behavior

        Args:
            state (int, bool): turn on or off verbose print statements

        """
        self._verbose = True if state else False


    def write(self, address, value):
        """Write a single value to a register.

        Args:
            address (int): address of register
            value (int): value to write

        """
        self.write_block(address, [value])


    def write_block(self, address, values):
        """Write multiple values to a starting register location.

        Args:
            address (int): starting address of registers
            values (list of ints): values to write

        """
        for i, value in enumerate(values):
        	self._cache[address + i*self._addr_stride] = value

        if self._verbose:
            if len(values) == 1:
                value = values[0]
                print("SPI Write: Bus={0}; Chip Select={1}; Register Address=0x{2:0{3}x}; Value=0x{4:0{5}x};".format(self._bus, self._chip_select, address, self._addr_size*2, value, self._word_size*2))
            else:            
                print("SPI Write: Bus={0}; Chip Select={1}; Register Address=0x{2:0{3}x};".format(self._bus, self._chip_select, address, self._addr_size*2))
                for value in values:
                    print("\tRegister Value=0x{0:0{1}x};".format(value, self._word_size*2))


    def read(self, address):
        """Read from a single register.

        Args:
            address (int): address of register

        Returns:
            value (int): value of the register

        """
        values = self.read_block(address, length=1)
        value = values[0]
        return value


    def read_block(self, address, length=1):
        """Read multiple values from a starting register location.

        Args:
            address (int): starting address of registers
            length (int): number of registers to read

        Returns:
            values (list of ints): values of the registers

        """
        values = [self._cache[address + i*self._addr_stride] for i in range(length)]

        if self._verbose:
            if len(values) == 1:
                value = values[0]
                print("SPI Read: Bus={0}; Chip Select={1}; Register Address=0x{2:0{3}x}; Value=0x{4:0{5}x};".format(self._bus, self._chip_select, address, self._addr_size*2, value, self._word_size*2))   
            else:
                print("SPI Read: Bus={0}; Chip Select={1}; Register Address=0x{2:0{3}x};".format(self._bus, self._chip_select, address, self._addr_size*2))
                for value in values:
                    print("\tRegister Value=0x{0:0{1}x};".format(value, self._word_size*2))

        return values


    def transfer(self, data_out):
        """Perform a full-duplex transaction.

        Args:
            data_out (list of ints): data bytes to be sent out on MOSI

        Returns:
            values (list of ints): data bytes returned on MISO

        """
        data_in = data_out

        if self._verbose:
            print("SPI Transfer: Bus={}; Chip Select={};".format(self._bus, self._chip_select))
            for byte_out, byte_in in zip(data_out, data_in):
                print("\tMOSI Byte={:#04x}; MISO Byte={:#04x};".format(byte_out, byte_in))
        
        return data_in
# ----------------------------------------------------------------------------
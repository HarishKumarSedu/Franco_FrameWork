# ----------------------------------------------------------------------------
# convert.py
# Dakota Koelling
# 2016-11-1
# contains generic functions for converting type formats
# ----------------------------------------------------------------------------

# Imports
# ----------------------------------------------------------------------------

# ----------------------------------------------------------------------------

# Functions
# ----------------------------------------------------------------------------


def twoscomp_to_dec(tc_value, num_bits=-1, frac_bits=0):
    """Convert a two's complement number to decimal.

    [INPUT]
        tc_value (int): two's complement value to be converted to decimal
        num_bits (int): indicates the number of bits used to represent the two's
            complement value to be converted.
            If this is not specified, the number of bits will be estimated
            based on the values passed in. This estimation is done by using the
            number of bits contained in the minimum number of nibbles necessary
            to represent the passed-in values as hex (see examples 3-5).
        frac_bits (int): indicates the number of fractional bits used to represent
            the two's complement value to be converted.
            If this is not specified, this will be assumed to be 0.
    [OUTPUT]
        dec_value (int): tc_value converted decimal value

     Examples:
       1) twoscomp2dec('80')

          ans =
              -128

       2) twoscomp2dec(128)

           ans =
               -128

       3) twoscomp2dec('1F')

           ans =
                 31

       4) twoscomp2dec('1F', 5)

           ans =
                 -1

       5) twoscomp2dec('1F', 6)

           ans =
                 31

       6) twoscomp2dec('4', 4, 4)

           ans =
             0.2500
    """

    # Get number of bits and make any necessary data type conversions
    if isinstance(tc_value, str):
        dec_value = int(tc_value, 16)
    elif isinstance(tc_value, int):
        dec_value = tc_value
    else:
        assert False, 'Input must be hex or numeric'

    if num_bits == -1:
        num_bits = len(bin(tc_value)) - 2  # subtract 2 to remove '0b'

    # Calculate limits
    max_pos = (2 ** (num_bits - 1)) - 1
    max_neg = -(2 ** (num_bits - 1))
    conv_factor = 2 ** frac_bits

    # Convert negative values
    if dec_value > max_pos:  # negative value (first bit is 1)
        dec_value -= 2 ** num_bits  # convert values that should be negative

    # Convert two's complement to decimal
    dec_value /= conv_factor

    # Check for expected range
    max_value = max_pos / conv_factor
    min_value = max_neg / conv_factor

    if (dec_value < min_value) or (dec_value > max_value):
        assert False, 'Output value exceeds range of precision specified'

    return dec_value

# ----------------------------------------------------------------------------
# reg_map.py
# Gabriel Seitz
# 2016-11-1
# contains a function to import a device definitions file
# ----------------------------------------------------------------------------

# Imports
# ----------------------------------------------------------------------------
import codecs
from .compatability import *
from . import file_parser
# ----------------------------------------------------------------------------

# Attributes
# ----------------------------------------------------------------------------
class Fields(object):

    def __init__(self):
        pass


class BitField(object):

    def __init__(self, access, register, msb, lsb, mask, default):
        self.access = access
        self.register = register
        self.msb = msb
        self.lsb = lsb
        self.mask = mask
        self.default = default
# ----------------------------------------------------------------------------

# Definitions
# ----------------------------------------------------------------------------
def parse_xml(path_to_file, verbose=False):
    
    registers = {}       # create dictionary to hold all register dicts
    fields = {}     # create dictionary to hold all field dicts
    lookup_reg_addr = {}  # stupid temp dictionary to resolve SCS defining registers by name instead of address
    # name = 'None'
    mode = 'reg'    # remember whether it's a register or field
    # page_en = False
    reg_size = 8

    with codecs.open(path_to_file, 'r', encoding='utf-8') as fin:

        for line in fin:
            
            if verbose: print(line)

            if "<Registers " in line:  # store register size for later
                if "Width=\'" in line:  # single quote
                    reg_size = int(file_parser.find_in_line(line, "Width=\'", "\'"))
                elif "Width=\"" in line:  # double quote
                    reg_size = int(file_parser.find_in_line(line, "Width=\"", "\""))
                else:
                    raw_input("Warning! Parsed line is: " +line)

            elif "<Register>" in line:
                mode = 'reg'

            elif "<Field>" in line:
                mode = 'field'

            # elif "<IsPageRegister>true</IsPageRegister>" in line:
                # page_en = True

            elif "<Name>" in line:  # store register name for later
                if mode == 'reg':
                    reg_name = file_parser.find_in_line(line, ">", "<")
                else:  # mode == 'field'
                    field_name = file_parser.find_in_line(line, ">", "<")
                    fields[field_name] = {}

            elif "<Address>" in line:
                if mode == 'reg':
                    reg_addr = int(file_parser.find_in_line(line, ">", "<"), 0)
                    registers[reg_addr] = {'address': reg_addr, 'name': reg_name, 'length': reg_size}
                    lookup_reg_addr[reg_name] = reg_addr
                else:  # mode == 'field'
                    field_reg_name = file_parser.find_in_line(line, ">", "[")  # register name
                    fields[field_name]['register'] = lookup_reg_addr[field_reg_name]

                    # if page_en:
                        # fields[field_name]['page'] = int(registers[reg_addr]['page'],0)

                    bits = file_parser.find_in_line(line, "[", "]")
                    if ":" in bits:
                        bits = bits.split(":")
                        msb = int(bits[0])
                        lsb = int(bits[1])
                    else:  # single bit
                        msb = lsb = int(bits)

                    fields[field_name]['lsb'] = lsb
                    fields[field_name]['msb'] = msb
                    fields[field_name]['mask'] = sum([2**x for x in xrange(lsb, msb+1)])

            elif "<Page>" in line:
                if mode == 'reg':
                    registers[reg_addr]['page'] = file_parser.find_in_line(line, ">", "<")
                else:  # mode == 'field'
                    raw_input("Warning! Mode is: " +mode +"\nParsed line is: " +line)

            elif "<DefaultValue>" in line:
                if mode == 'reg':
                    registers[reg_addr]['default'] = int(file_parser.find_in_line(line, ">", "<"), 0)
                else:  # mode == 'field'
                    fields[field_name]['default'] = int(file_parser.find_in_line(line, ">", "<"), 0)

            elif "<Access>" in line:
                if mode == 'reg':
                    registers[reg_addr]['access'] = file_parser.find_in_line(line, ">", "<")
                else:  # mode == 'field'
                    fields[field_name]['access'] = file_parser.find_in_line(line, ">", "<")

            else:
                if verbose: print("skipped line\n\n")

    return fields, registers
    
    
def parse_json(path_to_file, verbose=False):

    import json

    registers = {}       # create dictionary to hold all register dicts
    fields = {}     # create dictionary to hold all field dicts

    with codecs.open(path_to_file, 'r', encoding='utf-8') as file:
        json_dict = json.load(file)
        
        # save bit field information
        for field_info in json_dict['bitfields']:
            fields[str(field_info['name'])] = {'default': int(field_info['default_value'], 0), 'access': str(field_info['access'])}
            if len(field_info['location'][0]) >= 4:  # paged device
                # fields[field_info['name']]['page'] = int(field_info['location'][0][0], 0)
                field_page = int(field_info['location'][0][0], 0) if int(json_dict['register_word_size'], 0) == 8 else 0
                field_addr = int(field_info['location'][0][1], 0)
                fields[field_info['name']]['register'] = (field_page<<8) + field_addr
                fields[field_info['name']]['msb'] = int(field_info['location'][0][2], 0)
                fields[field_info['name']]['lsb'] = int(field_info['location'][0][3], 0)
            else:
                fields[field_info['name']]['register'] = int(field_info['location'][0][0], 0)
                fields[field_info['name']]['msb'] = int(field_info['location'][0][1], 0)
                fields[field_info['name']]['lsb'] = int(field_info['location'][0][2], 0)
        
        # save register information
        if int(json_dict['register_word_size'], 0) == 8:  # include page value as MSB of address
            for reg_info in json_dict['registers']:
                reg_page = int(reg_info['page'], 0)
                reg_addr = int(reg_info['address'], 0)
                registers[(reg_page<<8) + reg_addr] = {
                    'page': reg_page,
                    'address': reg_addr,
                    'default': int(reg_info['default_value'], 0), 
                    'access': str(reg_info['access']), 
                    'name': str(reg_info['name_long'])
                    }
        else:
            for reg_info in json_dict['registers']:
                address = int(reg_info['address'], 0)
                registers[address] = {
                    'address': address,
                    'default': int(reg_info['default_value'], 0), 
                    'access': str(reg_info['access']), 
                    'name': str(reg_info['name_long'])
                    }
    
    # post processing, register length is max(msb) + 1
    for name, info in fields.iteritems():
        fields[name]['mask'] = sum([2**x for x in xrange(info['lsb'], info['msb']+1)])
        try:
            if info['msb']+1 > registers[info['address']]['length']:
                registers[info['register']]['length'] = info['msb']+1
        except KeyError:
            registers[info['register']]['length'] = info['msb']+1
            
    return fields, registers


def parse_cpmap(path_to_file, use_datasheet_name=False, verbose=False):

    registers = {}  # create dictionary for register information
    fields = {}  # create object to hold all field dicts

    with codecs.open(path_to_file, 'r', encoding='utf-8') as fin:
        for line in fin:

            if verbose: print(line)

            # skip lines without fields
            if '// !' not in line:
                if verbose: print("skipped line\n\n")
                continue

            split_line = line.split()

            # bitfield name
            for text in split_line:
                if '!' in text and text != '!NO_NAME':
                    ds_name = text[1:]
                    break
            else:
                ds_name = None

            # design name and access
            if '<R>' in split_line[0]:
                access = 'R/O'
                cp_name = split_line[0][3:]
            elif '<W>' in split_line[0]:
                access = 'W/O'
                cp_name = split_line[0][3:]
            else:
                access = 'R/W'
                cp_name = split_line[0]
            # remove brackets (if they exist)
            cp_name = cp_name.replace('[', '_').replace(']','')

            # register address
            address = int(split_line[1])

            # bit location
            bit_loc = file_parser.find_in_line(split_line[2], '[', ']')
            if ':' in split_line[2]:
                bit_loc = bit_loc.split(':')
                msb = int(bit_loc[0])
                lsb = int(bit_loc[1])
            else:
                msb = lsb = int(bit_loc)
            mask = sum([2**x for x in xrange(lsb, msb+1)])

            # default 
            default = split_line[3]
            default = default[default.find('h')+1:]

            # use datasheet name if enabled and ds_name exists
            if ds_name is not None and use_datasheet_name is True:
                name = ds_name
            else:
                name = cp_name

            if verbose: print("Found bit field name: " +name +"\n\n")

            # add field and its info to the container class
            # x = BitField(access, address, msb, lsb, mask, default) (deprecated code)
            # setattr(fields, name, x) (deprecated code)
            fields[name] = {'default': int(default, 16),
                            'access': access,
                            'address': address,
                            'msb': msb,
                            'lsb': lsb,
                            'mask': mask}

            # keep track of changes to register info based on fields
            try:
                if registers[address]:
                    if registers[address]['msb'] < msb:
                        registers[address]['msb'] = msb
                    if registers[address]['access'] != access:
                        registers[address]['access'] = 'R/W'
                    registers[address]['default'] |= ((default << lsb) & mask)
            except KeyError:
                registers[address] = {'default': int(default, 16),
                                      'access': access,
                                      'address': address,
                                      'msb': msb} # new register

    return fields, registers


def parse_html(path_to_file, verbose=False):

    registers = {}       # create dictionary to hold all register information
    fields = {}     # create dictionary to hold all field dicts
    mode = None  # used to divide the document into sections

    with codecs.open(path_to_file, 'r', encoding='utf-8') as fin:
        for line in fin:

            if verbose: print(line)

            if '<h3 style="text-align:left"><a name="' in line:
                if verbose: print(registers)
                reg_name, reg_addr = file_parser.find_in_line(line, '</a>', '</h3>').split()
                reg_addr = int(reg_addr, 16)

                # create new dictionary for each reg using its address
                registers[reg_addr] = {'address': reg_addr}

                # store attributes ('=None' will be populated later)
                registers[reg_addr]['name'] = reg_name
                registers[reg_addr]['length'] = None

                mode = 'length'  # set flag to look for size of register next

            elif mode == 'length':
                if '<th style=' in line:
                    size = int(file_parser.find_in_line(line, '>', '</th>')) + 1  # size is msb+1
                    if size > registers[reg_addr]['length']:  # length is highest bit
                        registers[reg_addr]['length'] = size
                elif '</thead>' in line:
                    mode = 'field_name'  # set flag to look for field names next

            elif mode == 'field_name':
                if '<a name=' in line:
                    field_name = file_parser.find_in_line(line, '</a>', '<br/>')
                    if field_name == "": continue  # skip blank field names
                    fields[field_name] = {}  # create new dictionary for each field
                    fields[field_name]['register'] = reg_addr
                elif '</table>' in line:
                    mode = 'field_parameters'  # set flag to look for field properties next
                    submode = 'field_name'  # set second flag to look for field name

            elif mode == 'field_parameters':
                if  submode == 'field_name' and '<td>' in line and '</td>' in line:
                    field_name = file_parser.find_in_line(line, '<td>', '</td>')  # re-find field name for properties
                    msb = lsb = access = description = None  # reset properties for new field
                    submode = 'location'  # set second flag to look for bit position

                elif '<td style=' in line:
                    if submode == 'location':
                        bits = file_parser.find_in_line(line, '>', '</td>')
                        if ":" in bits:
                            bits = bits.split(":")
                            msb = int(bits[0])
                            lsb = int(bits[1])
                        else:  # single bit
                            msb = lsb = int(bits)
                        fields[field_name]['lsb'] = lsb
                        fields[field_name]['msb'] = msb
                        fields[field_name]['mask'] = sum([2**x for x in xrange(lsb, msb+1)])
                        submode = 'access'  # set second flag to look for R/W access

                    elif submode == 'access':
                        access = file_parser.find_in_line(line, '>', '</td>')
                        if access == 'rw':
                            access = 'R/W'
                        elif access == 'ro':
                            access = 'R/O'
                        elif access == 'wo':
                            access = 'W/O'
                        fields[field_name]['access'] = access
                        submode = 'default'  # set second flag to look for default value

                    elif submode == 'default':
                        default = int(file_parser.find_in_line(line, 'h', '</td>'), 16)
                        fields[field_name]['default'] = default
                        submode = 'properties'  # set second flag to look for properties

                elif submode == 'properties' and'<td>' in line and '</td>' in line:
                        properties = file_parser.find_in_line(line, '<td>', '</td>')
                        # fields[field_name]['properties'] = properties
                        submode = 'description'  # set second flag to look for text description

                elif submode == 'description' and'<td>' in line and '</td>' in line:
                        description = file_parser.find_in_line(line, '<td>', '</td>')
                        # fields[field_name]['description'] = description
                        submode = 'field_name'  # set second flag to look for next field
                        
                        try:  # loops over every bitfield and adds it's default to the register default
                            registers[reg_addr]['default'] += (default<<lsb)
                        except KeyError:  # create parameter first time through (if undefined)
                            registers[reg_addr]['default'] = (default<<lsb)
                            
                        try:  # loops over every bitfield and checks that its access (e.g. R/W) is the same as the register
                            if registers[reg_addr]['access'] != access: print("Warning! Fields in the same register have difference accesses.")
                        except KeyError:  # create parameter first time through (if undefined)
                            registers[reg_addr]['access'] = access

                elif '</table>' in line:
                    mode = None  # set flag to look for next register

            else:
                if verbose: print('skipped line\n\n')
                
    return fields, registers
# ----------------------------------------------------------------------------

















































































from cirrusvue.core.connection import Connect

def discover_systems(search_time=2):
    """run mDNS to search for USB/Ethernet CirrusLink systems.
    Anecdotally, waiting 1 second captures all systems 95% of the time. 

    Args:
        search_time(int): number of seconds to wait for broadcast packets
    
    Returns:
        systems(list of dict): info on found systems, contains:
            'hostname' - hostname of system, does not include '.local' extension
            'hwid' - Board ID stored in system's EEPROM
            'nickname' - assigned nickname of system

    """
    import time, socket
    from zeroconf import ServiceBrowser, Zeroconf
    #try:
    #    from zeroconf import ServiceBrowser, Zeroconf
    #except ImportError:
    #    raise ImportError("zeroconf is currently required, run this command to install: pip install zeroconf==0.19.1")


    class MyListener:
        def remove_service(self, zeroconf, type, name):
            print("\nService %s removed" % (name,))

        def add_service(self, zeroconf, type, name):
            info = zeroconf.get_service_info(type, name)
            # print("\nService %s added, service info: %s" % (name, info))
            system_info = {
                'hostname': str(info.server).rstrip('.local.'),
                'hwid': info.properties[b'hwid'],
                'nickname': info.properties[b'nickname'],
                'address' : socket.inet_ntoa(info.address)}
            systems.append(system_info)

    # start mDNS/DNS
    systems = []
    zeroconf = Zeroconf()
    listener = MyListener()
    browser = ServiceBrowser(zeroconf, "_cirruslink._tcp.local.", listener)

    # wait for systems to show up before stopping the service
    time.sleep(search_time)
    zeroconf.close()

    return systems

def get_audiohub2(hubname = None, firstsystem = False, transport=None):
    systemfound = False
    if hubname == None:
        firstsystem = True
    link = None

    while transport is None:
        try:
            sel = int(raw_input('Select transport: 0 = RNDIS, 1 = VCOM > '))
            if sel == 0:
                transport = 'rndis'
                break
            elif sel == 1:
                transport = 'vcom'
                break
            else:
                print('Invalid selection, try again')
        except ValueError:
            print('Invalid selection, try again')
            pass

    if transport == 'rndis':
        usesystem = None
        print("Discovered Systems:")
        for system in discover_systems(search_time=2):
            print("\t* {}".format(system['hostname']))
            if systemfound == False:
                if (system['hostname'].find("ah2") != -1):
                    if firstsystem:
                        usesystem = system
                        systemfound = True
                    elif (system['hostname'].find(hubname) != -1):
                        usesystem = system
                        systemfound = True

        if usesystem is not None:
            print 'use system = ', usesystem['hostname']
            print '   address = ', usesystem['address']
            link = Connect('usb', usesystem['address'])
        else:
            if hubname is not None:
                raise RuntimeError('{} not found'.format(hubname))
            else:
                raise RuntimeError('ah2 device not found')

    elif transport == 'vcom':
        link = Connect('serial')
    else:
        raise RuntimeError('Transport must be "rndis" or "vcom"')

    return link
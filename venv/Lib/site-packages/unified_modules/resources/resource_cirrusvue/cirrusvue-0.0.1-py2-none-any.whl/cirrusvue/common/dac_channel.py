# ----------------------------------------------------------------------------
# dac_channel.py
# Dakota Koelling
# 2018-07-14
# contains classes for a DAC channel
# ----------------------------------------------------------------------------

# Imports
# ----------------------------------------------------------------------------
import time
from .dac import *
from .isense import *
# ----------------------------------------------------------------------------

# Definitions
# ----------------------------------------------------------------------------


class DACChannel:
    """DAC channel class

    """

    def __init__(self, name: str, channel: str, max_volt: float, dac: DAC, fpga, intercept: float = 0.0, slope: float = 0.0,
                    map_name: str = None, cal_num: int = -1, isns: ISense = None):
        """Instantiate a DAC channel object

        Args:
            name (str): Channel name
            channel (str): Channel letter
            max_volt (float): Maximum voltage to set
            dac (DAC): DAC object containing this channel
            fpga (obj): Control FPGA for pin control
            intercept (float): intercept
            slope (float): slope
            map_name (str): not really sure
            cal_num (int): Order in calibration map
            isns (ISense): ISense object measuring this channel

        """

        self.name = name
        # FIX ME: this may no longer be needed once database isn't used for calibration information
        if not map_name:
            map_name = name
        self.map_name = map_name
        self.channel = channel
        self.max_volt = max_volt
        self.dac = dac
        self.fpga = fpga
        self.cal_num = cal_num
        self.isns = isns

        # These will be set after calibration
        self.intercept = intercept
        self.slope = slope
        self.value = 0

    def set_supply(self, value: float, v_dac: int = -1, update: bool = True):
        """set_supply

            value: numeric value to set DAC (in Volts) [class: double]
            v_dac: DAC supply voltage being used (in Volts) [class: double]
                Leave blank or pass in -1 if using default setting (from calibration).
            example: eeb.set_dac_supply(eeb.VDD_D, 1.2); set VDD_D to 1.2V
        """

        dac_max_res = (2 ** 12) - 1  # DAC has 12-bit resolution

        assert self.slope and self.intercept, ('DAC slope and intercept are not found for ' + self.name +
                                               ' (map name: ' + self.map_name + ')!!')

        if value > self.max_volt:
            assert False, ('DAC limit for ' + self.name + ' is ' + str(self.max_volt) + ' V!')

        curr_val_dec = round((value - self.intercept) / self.slope)  # calculate value to write to DAC

        # Calibration was done with V_DAC = +5.5V_LDO_OPA1. This compensates for a different V_DAC.
        if v_dac != -1:
            comp_ratio = ((self.slope * dac_max_res) + self.intercept) / v_dac  # V_DAC compensation ratio
            curr_val_dec = curr_val_dec * comp_ratio

        if curr_val_dec > dac_max_res:
            curr_val_dec = dac_max_res  # force to max
        elif curr_val_dec < 0:
            curr_val_dec = 0  # force to min
        else:
            curr_val_dec = round(curr_val_dec)  # round to nearest integer if in range

        self.dac.write_to_dac(self.channel, curr_val_dec, update)  # write value to DAC
        self.value = value  # store value in DAC

    def toggle_ldac(self):
        """Toggle LDAC pin to load output values

        """

        # Update DACs using LDAC pin (FPGA control is inverted)
        ldac_ctrl = None  # TODO fpga.('cp_dac' + self.dac.number + '_ldac')
        self.fpga.write_field(ldac_ctrl, '1')  # set LDAC (clear LDACb)
        time.sleep(0.0001)
        self.fpga.write_field(ldac_ctrl, '0')  # clear LDAC (set LDACb)

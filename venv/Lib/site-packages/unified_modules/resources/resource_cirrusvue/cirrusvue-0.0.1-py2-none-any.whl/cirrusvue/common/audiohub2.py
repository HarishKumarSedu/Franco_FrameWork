# ----------------------------------------------------------------------------
# audiohub.py
# Gabriel Seitz
# 2016-11-15
# contains the AudioHub Version 1 class
# ----------------------------------------------------------------------------

# Imports
# ----------------------------------------------------------------------------
from cirrusvue.core.utilities import delay, repack
from cirrusvue.common.generic import GenericDevice
# ----------------------------------------------------------------------------

# Definitions
# ----------------------------------------------------------------------------
class AudioHub(object):
    """Device class for AudioHub2.
    
    """
    _lookup_mux = {
        'Logic Low': 0x00,
        'Logic High': 0x01,
        'SAI_MCLK': 0x05,
        'SAI_BCLK': 0x06,
        'SAI_FCLK': 0x07,
        'SAI_SDI1': 0x08,
        'SAI_SDI2': 0x09,
        'SAO_MCLK': 0x0c,
        'SAO_BCLK': 0x0d,
        'SAO_FCLK': 0x0e,
        'SAO_SDO1': 0x0f,
        'SAO_SDO2': 0x10,
        'PDMIO_MCLK': 0x13,
        'PDMIO_CLK1': 0x14,
        'PDMIO_DAT1': 0x15,
        'PDMIO_CLK2': 0x16,
        'PDMIO_DAT2': 0x17,
        'XUSB_BCLK': 0x1a,
        'XUSB_FCLK': 0x1b,
        'XUSB_SDO1': 0x1c,
        'XUSB_SDO2': 0x1d,
        'XUSB_SDO3': 0x1e,
        'XUSB_SDO4': 0x1f,
        'DEV_MCLK1': 0x22,
        'DEV_MCLK2': 0x23,
        'DEV_AUXCLK': 0x24,
        'DEV_ASP1_BCLK': 0x28,
        'DEV_ASP1_FCLK': 0x29,
        'DEV_ASP1_DATA1': 0x2a,
        'DEV_ASP1_DATA2': 0x2b,
        'DEV_ASP2_BCLK': 0x2e,
        'DEV_ASP2_FCLK': 0x2f,
        'DEV_ASP2_DATA1': 0x30,
        'DEV_ASP2_DATA2': 0x31,
        'DEV_ASP3_BCLK': 0x34,
        'DEV_ASP3_FCLK': 0x35,
        'DEV_ASP3_DATA1': 0x36,
        'DEV_ASP3_DATA2': 0x37,
        'DEV_PDM1_CLK': 0x3a,
        'DEV_PDM1_DATA': 0x3b,
        'DEV_PDM2_CLK': 0x3c,
        'DEV_PDM2_DATA': 0x3d,
        'DEV_PDM3_CLK': 0x3e,
        'DEV_PDM3_DATA': 0x3f,
        'DEV_PDM4_CLK': 0x40,
        'DEV_PDM4_DATA': 0x41,
        'DEV_PDM5_CLK': 0x42,
        'DEV_PDM5_DATA': 0x43,
        'DEV_PDM6_CLK': 0x44,
        'DEV_PDM6_DATA': 0x45,
        'DEV_PDM7_CLK': 0x46,
        'DEV_PDM7_DATA': 0x47,
        'PLL_CLK_OUT': 0x4a,
        '24.576 MHz': 0x4b,
        '24 MHz': 0x4c,
        '11.2896 MHz': 0x4d,
        '12.288 MHz': 0x4e,
        '12 MHz': 0x4f,
        '11.2896 MHz': 0x50,
        '6.144 MHz': 0x51,
        '6 MHz': 0x52,
        '5.6448 MHz': 0x53,
        '2.4 MHz': 0x54,
        '48 kHz': 0x55,
        'PDM MOD CLK OUT': 0x5e,
        'PDM MOD DATA OUT': 0x5f}


    def __init__(self, link, dev_map=None):
        self._link = link
        self._dev_map = dev_map 
        self.fpga = GenericDevice(link.get_i2c(bus=2, i2c_addr=0xca), GenericDevice.definition_path(__file__, ['audiohub2_fpga.xml']))
        self.pll = GenericDevice(link.get_i2c(bus=0, i2c_addr=0x9c), GenericDevice.definition_path(__file__, ['./device_xml/cs2300.xml']))


    def initialize(self):
        """Perform an initial set of writes.

        """
        self.fpga.write_field('DEV_GLOBAL_HIZ', 0)


    def reset_dut(self):
        """Toggle the DUT_RESET pin.

        """
        self.fpga.write_field('FORCE_DUT_RESETN', 1)
        delay.delay_s(.1)
        self.fpga.write_field('FORCE_DUT_RESETN', 0)
        delay.delay_s(.2)  # wait for reset line to deassert


    def reset_sys(self):
        """Toggle the SYS_RESET pin.

        """
        self.fpga.write_field('FORCE_SYS_RESETN', 1)
        delay.delay_s(.1)
        self.fpga.write_field('FORCE_SYS_RESETN', 0)
        delay.delay_s(.2)  # wait for reset line to deassert


    def configure_pll(self, out_clk, in_clk=48, in_ref_clk_src='XUSB_FCLK'):
        """configure a PLL to generate a clock based on the internal 48kHz clock

        Args:
            out_clk (int, float): output clock in MHz

        """
        # self.fpga.write_field('PLL_CLK_IN_SEL', 2)  # 48kHz
        self.fpga.write_field('PLL_CLK_IN_SEL', self._lookup_mux[in_ref_clk_src])  # 48kHz

        in_clk=float(in_clk)/1000

        coef = int(round(out_clk/in_clk*(2**20)))
        coefs = [(coef>>(8*i))&0xff for i in range(4)]
        print 'pll coefficient : '+hex (coef)

        self.pll.write_register(0x05, 0x09)  # freeze register writes
        # self.pll.write_register(0x02, 0x00)  # enable AUX, enable CLK_OUT
        self.pll.write_field('CLK_OUT_DIS', 0x00)  # enable CLK_OUT
        self.pll.write_field('AUX_OUT_DIS', 0x00)  # enable AUX
        self.pll.write_register(0x03, 0x07)  # Ratio Mod = 1, enable PLL Lock, enable CP
        self.pll.write_register(0x06, coefs[3])  # Byte 3
        self.pll.write_register(0x07, coefs[2])  # Byte 2
        self.pll.write_register(0x08, coefs[1])  # Byte 1
        self.pll.write_register(0x09, coefs[0])  # Byte 0
        self.pll.write_register(0x16, 0x10)  # disable clock skipping, AUX_OUT is PUSH-PULL, enable CP
        self.pll.write_register(0x17, 0x08)  # clocks low when unlocked, high precision 12.20
        self.pll.write_register(0x1e, 0x70)  # min loop bandwidth = 128Hz
        self.pll.write_register(0x05, 0x01)  # clear freeze bit, register writes take effect, enable CP ]
    
    
    def program_board_id(self, value, bus=0, addr=0xA0):
        """Program the EEPROM with a Board ID value.
        
        """
        eeprom = GenericDevice(self._link.get_i2c(bus=bus, i2c_addr=addr, map_size=2))
        
        board_id_bytes = repack.int_to_array(value, 4)
        
        eeprom.write_register(12, board_id_bytes[3])  # bits 31-24
        delay.delay_ms(10)
        eeprom.write_register(13, board_id_bytes[2])  # bits 23-16
        delay.delay_ms(10)
        eeprom.write_register(14, board_id_bytes[1])  # bits 15-8
        delay.delay_ms(10)
        eeprom.write_register(15, board_id_bytes[0])  # bits 7-0
        delay.delay_ms(10)
    
    
    def read_board_id(self, bus=0, addr=0xA0):
        """Read the EEPROM that contains the board ID.
        
        """
        eeprom = GenericDevice(self._link.get_i2c(bus=bus, i2c_addr=addr, map_size=2))
        
        board_id_bytes = []        
        board_id_bytes.append(eeprom.read_register(12))  # bits 31-24
        board_id_bytes.append(eeprom.read_register(13))  # bits 23-16
        board_id_bytes.append(eeprom.read_register(14))  # bits 15-8
        board_id_bytes.append(eeprom.read_register(15))  # bits 7-0
        
        board_id_bytes.reverse()
        board_id = repack.array_to_int(board_id_bytes)

        return board_id
# ----------------------------------------------------------------------------

# ----------------------------------------------------------------------------
# low level routing methods
# ----------------------------------------------------------------------------
    def _mux(self, pin, source=None, skip_dir=False):
        """set up one anything-to-anything mux (direction + mux source)

        Args:
            pin (str): pin name to configure
            source (str): name of mux source, set to 'None' for Hi-Z
            skip_dir (str): don't attempt to write to "x_DIR" field

        """
        pin_name = pin

        if source is None:
            if not skip_dir: self.fpga.write_field(pin_name+ '_DIR', 1)
        else:
            self.fpga.write_field(pin_name + '_SEL', self._lookup_mux[source])
            if not skip_dir: self.fpga.write_field(pin_name+ '_DIR', 0)
# ----------------------------------------------------------------------------


# ----------------------------------------------------------------------------
# high level routing methods
# ----------------------------------------------------------------------------
    def route_mclk(self, source):
        """Route a single MCLK source to everything!

        Args:
            source (str): source of the master clock

        """
        for name in ['SAI_MCLK', 'SAO_MCLK', 'PDMIO_MCLK', 'DEV_MCLK1', 'DEV_MCLK2']:
            if name in source:
                self._mux(name)  # input (can't source itself)
            else:
                self._mux(name, source)


    def route_saio(self, dev_port, master):
        """Connect SAIO headers to a device ASP port. SAO is always slaved.
        DEV_ASPx_DATA1 is routed from SAI DATA1
        DEV_ASPx_DATA2 is routed to SAO DATA1

        Args:
            device (string): device ASP port, will attempt to lookup mapping
            master (bool): specifies clock direction, set True for device master

        """
        # attempt to lookup device <-> audiohub mapping
        if self._dev_map is not None:
            try:
                dev_port = self._dev_map[dev_port]
            except KeyError:
                pass

        # route device and SAI clocks
        if master == 1:
            self._mux(dev_port+'_BCLK')
            self._mux(dev_port+'_FCLK')
            self._mux('SAI_BCLK', dev_port+'_BCLK')
            self._mux('SAI_FCLK', dev_port+'_FCLK')
        elif master == 0:
            self._mux('SAI_BCLK')
            self._mux('SAI_FCLK')
            self._mux(dev_port+'_BCLK', 'SAI_BCLK')
            self._mux(dev_port+'_FCLK', 'SAI_FCLK')
        else:
            raise ValueError(master)

        # route data and SAO clocks (always slave)
        self._mux('SAO_BCLK', dev_port+'_BCLK')
        self._mux('SAO_FCLK', dev_port+'_FCLK')
        self._mux(dev_port+'_DATA1', 'SAI_SDI1')
        self._mux(dev_port+'_DATA2')
        self._mux('SAO_SDO1', dev_port+'_DATA2', skip_dir=True)


    def route_usb(self, dev_port):
        """Connect USB Audio Module (master only) to a device ASP port
        DEV_ASPx_DATA1 is routed from USB Audio SDO1
        DEV_ASPx_DATA2 is routed to USB Audio SDIN1

        Args:
            device (string): device ASP port, will attempt to lookup mapping
            master (bool): specifies clock direction, set True for device master

        """
        # attempt to lookup device <-> audiohub mapping
        if self._dev_map is not None:
            try:
                dev_port = self._dev_map[dev_port]
            except KeyError:
                pass

        # route clocks and data (USB always master)
        self._mux(dev_port+'_BCLK', 'XUSB_BCLK')
        self._mux(dev_port+'_FCLK', 'XUSB_FCLK')
        self._mux(dev_port+'_DATA1', 'XUSB_SDO1')
        self._mux(dev_port+'_DATA2')
        self._mux('XUSB_SDIN1', dev_port+'_DATA2', skip_dir=True)


    def route_pdmio(self, hdr, dev_port, clk_dir, data_dir):
        """Connect a PDMIO header to a device PDM port.

        Args:
            hdr (int): PDMIO header, can be 1 or 2
            dev_port (string): device PDM port, will attempt to lookup mapping
            clk_dir (bool): specifies clock direction, set True for device -> HDR
            data_dir (bool): specifies data direction, set True for device -> HDR

        """
        # attempt to lookup device <-> audiohub mapping
        if self._dev_map is not None:
            try:
                dev_port = self._dev_map[dev_port]
            except KeyError:
                pass

        # route PDM CLK
        if clk_dir == True:
            self._mux(dev_port+'_CLK')
            self._mux('PDMIO_CLK'+str(hdr), dev_port+'_CLK')
        elif clk_dir == False:
            self._mux('PDMIO_CLK'+str(hdr))
            self._mux(dev_port+'_CLK', 'PDMIO_CLK'+str(hdr))
        else:
            raise ValueError(clk_dir)

        # route PDM Data
        if data_dir == True:
            self._mux(dev_port+'_DATA')
            self._mux('PDMIO_DAT'+str(hdr), dev_port+'_DATA')
        elif data_dir == False:
            self._mux('PDMIO_DAT'+str(hdr))
            self._mux(dev_port+'_DATA', 'PDMIO_DAT'+str(hdr))
        else:
            raise ValueError(data_dir)
# ----------------------------------------------------------------------------
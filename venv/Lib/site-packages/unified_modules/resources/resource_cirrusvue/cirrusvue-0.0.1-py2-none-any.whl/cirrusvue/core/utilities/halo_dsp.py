# ----------------------------------------------------------------------------
# halo_dsp.py
# Gabriel Seitz
# 2018-20-4
# contains generic functions for downloading Halo DSP firmware
# ----------------------------------------------------------------------------

# Imports
# ----------------------------------------------------------------------------
from .compatability import *
# ----------------------------------------------------------------------------

# Functions
# ----------------------------------------------------------------------------
def read_memory_file(path_to_file, index_start=0, index_end=None, index_stride=1, zero_fill=True):
    """Input a memory file and parse its contents. 
    Arguments index_start and index_end provide an option to only return a subset of the memory file. 
    Note that index =/= register address!
    
    Example .PM format (index_stride=2):
    @0
    @000000 78DEADBEEF
    @000002 FACE123456
    @000004 05BA11B01D
    @000006 CA11AB1EF0
    @000018 78DEADBEEF
    @00001a FACE123456
    @00001c 05BA11B01D
    @00001e CA11AB1EF0    
    
    zero_fill=False will return two memory blocks, one for indexes 0x0-0x6 and another for indexes 0x18-0x1e
    zero_fill=True will return one memory block with 0's filled in for indexes 0x8-0x16 and 0x20-index_end
    
    Args:
        path_to_file (str): path to memory file to parse
        index_start (int): skip lines before a specified index
        index_end (int): skip lines after a specified index, None = continue until end of file
        index_stride (int): expected gap between index values
        zero_fill (bool): set True to fill in missing indexes with 0's or False to return segmented memory blocks
    
    Returns:
        memory_chunks (list of dict): contains [{'index_start', 'values'}]
            - index_start (int): starting index of a memory block
            - values (list of int): memory data

    """
    memory_chunks = []
    values = []
    first_index = index_start
    old_index = index_start
    with open(path_to_file, 'r') as f:
        for line in f:
            # process lines with index + data and skip the rest
            try:
                line_split = line.lstrip('@').split()
                new_index = int(line_split[0], 16)
                new_value = int(line_split[1], 16)
            except IndexError:
                continue
            
            # optionally skip to a specified index
            if new_index < index_start:
                continue
            
            # optionally quit at a specified index
            if index_end != None and new_index >= index_end:
                break
            
            # detect gaps in addresses
            if (new_index > old_index + index_stride):
                if zero_fill:  # fill in missing addresses with 0
                    for _ in xrange((new_index-old_index)/index_stride - 1):
                        values.append(0)
                else:  # store [index, data] chunk
                    memory_chunks.append({'first_index': first_index, 'values':values})
                    values = []
                    first_index = new_index
                    
            # save index and add value to list
            values.append(new_value)
            old_index = new_index
        
        # zero 
        if index_end != None and index_end >= old_index and zero_fill:
            for _ in xrange((index_end-old_index)/index_stride - 1):
                values.append(0)
        
        # reached end of file, save contents
        memory_chunks.append({'first_index': first_index, 'values':values})
            
    return memory_chunks
    
    
def repack_memory_data(input_values, input_value_size, output_value_size, max_values=None):
    """reformats an list of integers to switch between 'unpacked' and 'packed'.
    
    Example packed 40-bit data:
    Word 0: 0x78DEADBEEF
    Word 1: 0xFACE123456
    Word 2: 0x05BA11B01D
    Word 3: 0xCA11AB1EF0
    
    Example unpacked 32-bit data:
    Addr 0: 0xDEADBEEF
    Addr 1: 0x12345678
    Addr 2: 0xB01DFACE
    Addr 3: 0xF005BA11
    Addr 4: 0xCA11AB1E

    Args:
        input_values (list of int): memory values to be repacked
        input_value_size (int): number of hex characters per input value (=bytes*2)
        output_value_size (int): number of hex characters per output value (=bytes*2)
        max_values (int): maximum number of elements per list, None=no maximum limit
        
    Returns:
        output_values (list of list of int): repacked memory values,
            for example: [[data0_word0, data0_word1, ... data0_wordN], [data1_word0, data1_word1, ... data1_wordN]]
    
    """
    output_values = []
    output_chunk = []
    leftover_values = ''
    
    for input_value in input_values:
        # convert input value to the specified number of hex characters and merge with leftover hex characters
        leftover_values = ('{1:0{2}X}{0}'.format(leftover_values, input_value, input_value_size))
        
        # run as many times as there are complete output values
        for _ in xrange(len(leftover_values)/output_value_size):
            # save a complete set of hex characters
            output_value = leftover_values[-output_value_size:]
            # output_values.append(int(output_value, 16))
            output_chunk.append(int(output_value, 16))
            if max_values != None and len(output_chunk) >= max_values:
                output_values.append(output_chunk)
                output_chunk=[]
                
            # carry over remaining hex characters for the next iteration
            leftover_values = leftover_values[:len(leftover_values)-output_value_size]
            
    else:
        if len(output_chunk) > 0:
            output_values.append(output_chunk)
    
    return output_values
# ----------------------------------------------------------------------------
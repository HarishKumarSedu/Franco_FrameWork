# Copyright (c) 2016-2017 Cirrus Logic, Inc and
# Cirrus Logic International Semiconductor Ltd.  All rights reserved.
#
# This software as well as any related documentation is furnished under
# license and may only be used or copied in accordance with the terms of the
# license.  The information in this file is furnished for informational use
# only, is subject to change without notice, and should not be construed as
# a commitment by Cirrus Logic.  Cirrus Logic assumes no responsibility or
# liability for any errors or inaccuracies that may appear in this document
# or any software that may be provided in association with this document.
#
# Except as permitted by such license, no part of this document may be
# reproduced, stored in a retrieval system, or transmitted in any form or by
# any means without the express written consent of Cirrus Logic.
#
# Warning
#   This software is specifically written for Cirrus Logic devices.
#   It may not be used with other devices.
#
## @file   _EqBand.py
## @brief  Object that represents the state one EQ band, and contains helper
##         functions for graphing.
from Common import Common

import cmath
import copy
import math
import matplotlib.pyplot as plt


class Biquad(object):
    """
    Object defining a biquad filter. Includes access helper methods and a
    transfer_function method. Biquad filters are represented as::

        H(s) = b_0 + b_1.z^-1 + b_2.z^-2
               -------------------------
               a_0 + a_1.z^-1 + a_2.z^-2

    """
    def __init__(self, b0=1, b1=0, b2=0, a1=0, a2=0, verbose=0):
        """
        NB: pass through by default

        """
        self.a0 = 1

        self.b0 = b0
        self.b1 = b1
        self.b2 = b2

        self.a1 = a1
        self.a2 = a2

        self.b0_hex = Common.dec2hex(b0, verbose)
        self.b1_hex = Common.dec2hex(b1, verbose)
        self.a1_hex = Common.dec2hex(-a1, verbose)
        self.a2_hex = Common.dec2hex(-a2, verbose)
        self.b2_hex = Common.dec2hex(b2, verbose)

        self.verbose = verbose

    def __str__(self):
        order = ["a0", "a1", "a2", "b0", "b1", "b2"]
        return "<" + ", ".join([(k + " : " + str(v))
                                for (k, v)
                                in zip(order, self.get_as_list())]) + ">"
    def __repr__(self):
        return "Biquad (b0={}, b1={}, b2={}, a1={}, a2={})".format(str(self.b0), str(self.b1), str(self.b2), str(self.a1), str(self.a2))

    def __hex__(self):
        order = ["b0", "b1", "a1", "a2", "b2"]
        return "<" + ", ".join([(k + " : " + str(v))
                                for (k, v)
                                in zip(order, self.get_as_hex_list())]) + ">"

    def __eq__(self, other):
        return other != None and self.get_as_list() == other.get_as_list()

    def set_verbose(self, verbose=1):
        self.verbose = verbose

    def set_coeffs(self, b0, b1, b2, a1, a2):
        """
        Change coefficients of Biquad

        """
        if b0 is not None:
            self.b0 = b0
        if b1 is not None:
            self.b1 = b1
        if b2 is not None:
            self.b2 = b2
        if a1 is not None:
            self.a1 = a1
        if a2 is not None:
            self.a2 = a2

    def get_as_list(self):
        """
        Returns Biquad coeffs as a list

        """
        return [self.a0, self.a1, self.a2, self.b0, self.b1, self.b2]

    def get_as_hex_list(self, str=1):
        """Return hex S1.30 coeff following Cirrus EQ Coeff program sequence b0, b1, a1, a2, b2."""
        if str:
            return [self.b0_hex, self.b1_hex, self.a1_hex, self.a2_hex, self.b2_hex]
        else:
            return [int(self.b0_hex, 16), int(self.b1_hex, 16), int(self.a1_hex, 16), int(self.a2_hex, 16), int(self.b2_hex, 16)]

    def convert_coeff_to_dec(self, a1, a2, b0, b1, b2):
        """Convert biquad coefficient from S1.30 fixed point hex to fractons.

        Note: Assume transfer function 'y[n] = b0x[n] + b1x[n-1] + b2x[n-2] + a1y[n-1] + a2y[n-2]'
        Args:
            a1,a2,b0,b1,b2 (int) S1.30 hex fixed point biquad coefficient

        Return:
            a1,a2,b0,b1,b2 (float) biquad coefficient
        """
        b0_converted = Common.hex2dec(b0, self.verbose)
        b1_converted = Common.hex2dec(b1, self.verbose)
        b1_converted = -(b1_converted+2) if (b1_converted < 0) else ((b1_converted) if b1_converted != 0 else 0)
        a1_converted = -Common.hex2dec(a1, self.verbose)
        a2_converted = Common.hex2dec(a2, self.verbose)
        a2_converted = (a2_converted + 2) if (a2_converted < 0) else ((a2_converted-2) if a2_converted != 0 else 0)
        b2_converted = Common.hex2dec(b2, self.verbose)

        if self.verbose:
            print '**********************************************************'
            print 'biquad coefs generated assumes filter function '
            print 'y[n] = b0x[n] + b1x[n-1] + b2x[n-2] + a1y[n-1] + a2y[n-2]'
            print 'pay attention to the sign of a1 & a2 coeff'
            print '**********************************************************'
            print ("b0 = " + str(b0_converted))
            print ("b1 = " + str(b1_converted))
            print ("b2 = " + str(b2_converted))
            print ("a1 = " + str(a1_converted))
            print ("a2 = " + str(a2_converted))

        return a1_converted, a2_converted, b0_converted, b1_converted, b2_converted

    def convert_coeff_to_hex(self, a1, a2, b0, b1, b2):
        """Convert biquad coefficient from fractions to S1.30 fixed point hex.

        Note: Assume transfer function 'y[n] = b0x[n] + b1x[n-1] + b2x[n-2] + a1y[n-1] + a2y[n-2]'
        Args:
            a1,a2,b0,b1,b2 (float) biquad coefficient

        Return:
            a1,a2,b0,b1,b2 (int) S1.30 hex fixed point biquad coefficient
        """
        b0_hex = Common.dec2hex(b0, self.verbose)
        b1_hex = Common.dec2hex(b1, self.verbose)
        a1_hex = Common.dec2hex(-a1, self.verbose)
        a2_hex = Common.dec2hex(-a2, self.verbose)
        b2_hex = Common.dec2hex(b2, self.verbose)

        if self.verbose:
            print '**********************************************************'
            print 'hex code generated assumes filter function '
            print 'y[n] = b0x[n] + b1x[n-1] + b2x[n-2] + a1y[n-1] + a2y[n-2]'
            print 'pay attention to the sign of a1 & a2 coeff'
            print '**********************************************************'
            print ("b0 = " + str(self.b0_hex))
            print ("b1 = " + str(self.b1_hex))
            print ("a1 = " + str(self.a1_hex))
            print ("a2 = " + str(self.a2_hex))
            print ("b2 = " + str(self.b2_hex))

        return a1_hex, a2_hex, b0_hex, b1_hex, b2_hex

    def transfer_function(self, freq_array):
        """
        Generates transfer function array

        :param freq_array: a list of frequencies (`complex`, `float`, `int`,
        `double`) over which transfer function must be computed

        :returns: an array with transfer function evaluated for every
        frequency point

        """
        eval_tf = [cmath.exp(1j * el) for el in freq_array]

        coeffs = self.get_as_list()
        denominator = Common.poly_val(coeffs[:3], eval_tf)
        numerator = Common.poly_val(coeffs[3:], eval_tf)

        H = [(n / d) for (n, d) in zip(numerator, denominator)]

        return H

    def is_equal(self, biquad):
        """
        Check if passed object is equalt to current one.
        """
        # check passed object
        if biquad == None:
            return False
        # check b0 
        if self.b0 != biquad.b0:
            return False
        # check b1
        if self.b1 != biquad.b1:
            return False
        # check b2
        if self.b2 != biquad.b2:
            return False
        # check a0
        if self.a0 != biquad.a0:
            return False
        # check a1
        if self.a1 != biquad.a1:
            return False
        # check a2
        if self.a2 != biquad.a2:
            return False

        return True


class EqBand(object):
    """
    Each instance of this class represents one IIR EQ band (one biquad).
    This class contains helper functions for generating EQ response.

    :param fc: frequency [Hz]
    :param q: Q factor [-] (damping)
    :param gainDb: gain [dB]
    :param filter_type: filter type

    """
    """ Constants for Filter Type """
    PEAKING = 0
    LPF_BUTTER_1ST = 1
    HPF_BUTTER_1ST = 2
    LPF_BUTTER_2ND = 3
    HPF_BUTTER_2ND = 4
    LOW_SHELF_2ND = 5
    HI_SHELF_2ND = 6
    LPF_ADJ_Q = 7
    HPF_ADJ_Q = 8
    BESSEL = 9
    LOW_SHELF_1ST = 10
    HI_SHELF_1ST = 11
    ALLPASS_1ST = 12
    ALLPASS_2ND = 13
    NOTCH = 14

    _lookup_filter_type = {
        0: "PEAKING",
        1: "LPF_BUTTER_1ST",
        2: "HPF_BUTTER_1ST",
        3: "LPF_BUTTER_2ND",
        4: "HPF_BUTTER_2ND",
        5: "LOW_SHELF_2ND",
        6: "HI_SHELF_2ND",
        7: "LPF_ADJ_Q",
        8: "HPF_ADJ_Q",
        9: "BESSEL",
        10: "LOW_SHELF_1ST",
        11: "HI_SHELF_1ST",
        12: "ALLPASS_1ST",
        13: "ALLPASS_2ND",
        14: "NOTCH"
    }

    NO_GAIN_FILTER_TYPES = (LPF_BUTTER_1ST,
                            HPF_BUTTER_1ST,
                            LPF_BUTTER_2ND,
                            HPF_BUTTER_2ND,
                            LPF_ADJ_Q,
                            HPF_ADJ_Q,
                            BESSEL,
                            ALLPASS_1ST,
                            ALLPASS_2ND,
                            NOTCH)

    NO_Q_FILTER_TYPES = (LPF_BUTTER_1ST,
                         HPF_BUTTER_1ST,
                         LPF_BUTTER_2ND,
                         HPF_BUTTER_2ND,
                         BESSEL,
                         LOW_SHELF_1ST,
                         HI_SHELF_1ST,
                         ALLPASS_1ST)

    def __init__(self, fc=1000.0, q=0.707, gainDb=0.0,
                 filter_type=PEAKING, pregain_lin=1, sample_rate=Common.FS_48K, verbose=0):

        self.biquad = None
        self.biquad_old = None

        self.manual = False
        self.enabled = True

        self.fc = fc
        self.q = q
        self.saved_q = None
        self.gainDb = gainDb
        self.saved_gainDb = None
        self.filter_type = filter_type
        self.filter_type_str = self._lookup_filter_type[filter_type]
        self.pregain_lin = pregain_lin

        self.sample_rate = sample_rate

        # save initial values
        self._set_defaults()

        self.gain_points = []
        self.phase_points = []

        # refresh self.biquad
        self.calc_biquad()
        self.verbose = verbose

    # def __str__(self):
    #     man = "m" if self.manual else "g"
    #     en = "E" if self.enabled else "D"
    #     biquad_str = str(self.biquad)
    #     return "EqBand ({}, {})\n".format(man, en) + biquad_str

    def __str__(self):
        return "Filter= {}, Fc= {}, Q= {}, Gain= {}\nBiquad:{}\n".format(self.filter_type_str, str(self.fc), str(self.q), str(self.gainDb), str(self.biquad))

    def __repr__(self):
        return "EqBand(fc={}, q={}, gainDb={}, filter_type=EqBand.{}, sample_rate={}".format(str(self.fc), str(self.q), str(self.gainDb), self.filter_type_str, str(self.sample_rate))

    def _set_defaults(self):
        """
        Save initial values for reset()

        """
        self.sample_rate_default = copy.deepcopy(self.sample_rate)
        self.fc_default = copy.deepcopy(self.fc)
        self.q_default = copy.deepcopy(self.q)
        self.gainDb_default = copy.deepcopy(self.gainDb)
        self.filter_type_default = copy.deepcopy(self.filter_type)
        self.filter_type_str_default = copy.deepcopy(self.filter_type_str)
        self.pregain_lin_default = self.pregain_lin
        self.manual_default = copy.deepcopy(self.manual)
        self.enabled_default = copy.deepcopy(self.enabled)

    def set_verbose(self, verbose=1):
        """Enable/disable print statement."""
        self.verbose = verbose

    def get_available_filter_type(self):
        """Return a dictionary of filter type available."""
        return self._lookup_filter_type

    def get_filter_type_str(self):
        """Return filter type string."""
        return self.filter_type_str

    def reset(self):
        """
        Restore params given to __init__()

        """
        self.sample_rate = copy.deepcopy(self.sample_rate_default)
        self.fc = copy.deepcopy(self.fc_default)
        self.q = copy.deepcopy(self.q_default)
        self.gainDb = copy.deepcopy(self.gainDb_default)
        self.filter_type = copy.deepcopy(self.filter_type_default)
        self.filter_type_str = copy.deepcopy(self.filter_type_str_default)
        self.pregain_lin = self.pregain_lin_default
        self.manual = copy.deepcopy(self.manual_default)
        self.enabled = copy.deepcopy(self.enabled_default)
        self.calc_biquad()

    def get_as_dict(self):
        """
        returns data held in EqBand as `dict`

        """
        # check we're up to date:
        self.calc_biquad()

        out = {"fc": float(self.fc) if self.fc is not None else self.fc,
               "q": float(self.q) if self.q is not None else self.q,
               "gainDb": float(self.gainDb) if self.gainDb is not None else self.gainDb,
               "filter_type": int(self.filter_type) if self.filter_type is not None else self.filter_type,
               "filter_type_str": str(self.filter_type_str) if self.filter_type_str is not None else self.filter_type_str,
               "pregain_lin": float(self.pregain_lin) if self.pregain_lin is not None else self.pregain_lin,
               "state": {"manual": self.manual, "enabled": self.enabled},
               "sample_rate": self.sample_rate,
               "biquad": self.biquad.get_as_list()}
        return out

    def set_from_dict(self, data):
        """
        Sets params and biquad (if in manual) according to :data: dict

        :param data: `dict` containing data sufficient to define an EqBand

        """

        if data["state"]["manual"]:
            self.fc = None
            self.q = None
            self.gainDb = None
            self.filter_type = None
            self.pregain_lin = None
        else:
            self.set_params(fc=data["fc"], q=data["q"],
                            gainDb=data["gainDb"],
                            filter_type=data["filter_type"],
                            sample_rate=data["sample_rate"],
                            pregain_lin=data["pregain_lin"])

        self.manual = data["state"]["manual"]
        self.enabled = data["state"]["enabled"]

        if self.manual:
            # NB data["biquad"] in format [self.a0, self.a1, self.a2, self.b0,
            #                              self.b1, self.b2]
            self.set_biquad_coeffs(b0=data["biquad"][3], b1=data["biquad"][4],
                                   b2=data["biquad"][5], a1=data["biquad"][1],
                                   a2=data["biquad"][2])
        else:
            self.calc_biquad()

    # Other setters:

    def set_enabled(self, value):
        """
        Sets self.enabled to value. Also saves current self.biquad if
        self.manual to not lose it when reenabled

        :param value: `bool` to set self.enabled to

        """
        self.enabled = value
        if self.manual:
            if self.enabled:
                # recover biquad_old
                if self.biquad_old is not None:
                    self.biquad = copy.deepcopy(self.biquad_old)
            else:
                # save current biquad values for recovery
                self.biquad_old = copy.deepcopy(self.biquad)
        self.calc_biquad()

    def set_manual(self, value):
        """
        Sets self.manual to value. NB: can only switch into manual using
        this method.

        :param value: `bool` to set self.manual to

        """
        # ensure you can only switch into manual (not out)
        if (not self.manual):
            # check that we've got up to date biquad object
            self.calc_biquad()

            self.manual = value
            # eliminate data stored in params (for now we can keep the
            # default data - user can still reset??)
            self.fc = None
            self.q = None
            self.gainDb = None
            self.filter_type = None
            self.pregain_lin = None

    def set_biquad_coeffs(self, b0=None, b1=None, b2=None, a1=None, a2=None):
        """
        If self.manual, the user can directly set the biquad coefficients.

        """
        if not self.manual:
            return False

        self.biquad.set_coeffs(b0, b1, b2, a1, a2)

    def set_params(self, fc=None, q=None, gainDb=None, filter_type=None,
                   sample_rate=None, pregain_lin=None):
        """
        For setting biquad params.

        :param fc: frequency [Hz]
        :param q: Q factor [-] (damping)
        :param gainDb: gain [dB]
        :param filter_type: filter type
        :param sample_rate: sample rate used in biquad calcs

        """
        if self.manual:
            return False
        changed = False
        if (fc is not None) and (fc != self.fc):
            self.fc = fc
            changed = True
        if (q is not None) and (q != self.q):
            self.q = q
            changed = True
        if (gainDb is not None) and (gainDb != self.gainDb):
            self.gainDb = gainDb
            changed = True
        if (filter_type is not None) and (filter_type != self.filter_type):
            if (filter_type in EqBand.NO_GAIN_FILTER_TYPES) and (
                    self.filter_type not in EqBand.NO_GAIN_FILTER_TYPES):
                self.saved_gainDb = self.gainDb
            if (filter_type not in EqBand.NO_GAIN_FILTER_TYPES) and (
                    self.filter_type in EqBand.NO_GAIN_FILTER_TYPES) and (
                        self.saved_gainDb is not None):
                self.gainDb = self.saved_gainDb
            if (filter_type in EqBand.NO_Q_FILTER_TYPES) and (
                    self.filter_type not in EqBand.NO_Q_FILTER_TYPES):
                self.saved_q = self.q
            if (filter_type not in EqBand.NO_Q_FILTER_TYPES) and (
                    self.filter_type in EqBand.NO_Q_FILTER_TYPES) and (
                        self.saved_q is not None):
                self.q = self.saved_q
            self.filter_type = filter_type
            changed = True
        if (pregain_lin is not None) and (pregain_lin != self.pregain_lin):
            self.pregain_lin = pregain_lin
            changed = True
        if (sample_rate is not None) and (sample_rate != self.sample_rate):
            self.sample_rate = sample_rate
            changed = True

        if changed:
            # refresh biquad
            self.calc_biquad()
        return changed

    def calc_magnitude_response(self, ideal_points):
        """
        Generates the gain response of the EqBand (based on biquad coeffs)

        :param ideal_points: List of frequency (x) values
        """
        self.calc_biquad()

        self.gain_points = []
        if None in self.biquad.get_as_list():
            raise Exception("biquad has FAILED!")
        for x in ideal_points:
            x = float(x)
            intermed = (x) / self.sample_rate * (2 * math.pi)
            sin_omega = math.sin(intermed)
            cos_omega = math.cos(intermed)
            sin_two_omega = math.sin(2.0 * intermed)
            cos_two_omega = math.cos(2.0 * intermed)

            z1 = complex(cos_omega, -sin_omega)
            z2 = complex(cos_two_omega, -sin_two_omega)

            numerator = (z1 * self.biquad.b1) + (
                z2 * self.biquad.b2) + self.biquad.b0
            denominator = (z1 * self.biquad.a1) + (
                z2 * self.biquad.a2) + self.biquad.a0
            trasfer = numerator / denominator
            transferR = trasfer.real
            transferI = trasfer.imag
            magnitude = math.sqrt(
                transferR * transferR + transferI * transferI)
            magnitudeDb = 20.0 * math.log10(magnitude)

            if denominator == 0:
                raise Exception("Denominator of biquad {} is zero.".format(
                    [self.biquad.a0, self.biquad.a1, self.biquad.a2,
                     self.biquad.b0, self.biquad.b1, self.biquad.b2]))
            self.gain_points.append((x, magnitudeDb))

    def calc_phase_response(self, ideal_points):
        """
        Routine to calculate a set of points representing the phase response of
        the biquad coeffs b0, b1, b2, a1, a2 within EqBand.

        :param ideal_points: `list` of points

        """

        self.calc_biquad()

        if None in self.biquad.get_as_list():
            raise Exception("biquad not correct!")

        self.phase_points = []
        tf = self.biquad.transfer_function(ideal_points)

        phase = [((180/math.pi) * cmath.phase(el)) for el in tf]

        intermed = [(x) / self.sample_rate * (2 * math.pi) for x in ideal_points]

        self.phase_points = zip(intermed, phase)

    def calc_biquad(self):
        """
        Calculates and sets the values of the biquad coefficients in
        self.biquad

        """

        # check if EqBand is on/off
        if not self.enabled:
            # return biquad with unity gain (pass-through)
            self.biquad = Biquad()
            return

        if self.manual:
            return

        if (self.filter_type in (
                EqBand.LPF_BUTTER_2ND, EqBand.HPF_BUTTER_2ND, EqBand.LPF_ADJ_Q,
                EqBand.HPF_ADJ_Q, EqBand.BESSEL)):
            # gain not allowed for lowpass, highpass, nor butterworth.
            self.gainDb = 0.0

        if (self.filter_type in (EqBand.LPF_BUTTER_2ND,
                                 EqBand.HPF_BUTTER_2ND)):
            self.q = .7071  # butterworth filter always has .7071
        elif(self.filter_type == EqBand.BESSEL):
            self.q = 0.578  # bessel

        # Calculate Biquads for each active Channel, Band
        a0 = 1.0
        a1 = 0.0
        a2 = 0.0
        b0 = 0.0
        b1 = 0.0
        b2 = 0.0

        if (self.filter_type in (EqBand.LOW_SHELF_2ND, EqBand.HI_SHELF_2ND)):
            A = pow(10.0, (
                self.gainDb / 40.0))  # peaking and shelving filters only
        else:
            A = pow(pow(10.0, (self.gainDb / 20.0)), .5)

        W0 = (2 * math.pi) * self.fc / float(self.sample_rate)
        cosW0 = math.cos(W0)
        sinW0 = math.sin(W0)
        alpha = sinW0 / (2.0 * self.q)

        if (self.filter_type == EqBand.PEAKING):
            # Note(aiden): where unclear what variable names taken directly
            #              from Biquad.m were, they have been left as is.
            w_cutoff = (2 * self.fc) / float(self.sample_rate)
            K = math.tan((math.pi / 2.0) * w_cutoff)
            V = 10 ** (self.gainDb / 20.0)
            if self.gainDb >= 0:
                norm = 1 / (1.0 + K * (1 / float(self.q) + K))
                b0 = (1 + V / float(self.q) * K + K * K) * norm
                b2 = (1 - V / float(self.q) * K + K * K) * norm
                a2 = (1 - 1 / float(self.q) * K + K * K) * norm
            else:
                V = 1 / V
                norm = 1 / (1.0 + K * (V / float(self.q) + K))
                b0 = (1 + 1 / float(self.q) * K + K * K) * norm
                b2 = (1 - 1 / float(self.q) * K + K * K) * norm
                a2 = (1 - V / float(self.q) * K + K * K) * norm
            a1 = 2 * (K * K - 1) * norm
            b1 = a1

        elif (self.filter_type == EqBand.LPF_BUTTER_1ST):
            # compute low pass coefficients b_0/4, b_1/4, b_2/4,
            # a_1/2 and a_2/2
            xx = (cosW0 + sinW0 - 1) / (cosW0 - sinW0 - 1)
            a0 = 1.0
            b0 = ((1.0 + xx) * .5)
            b1 = b0
            b2 = 0.0
            a1 = xx
            a2 = 0.0
        elif (self.filter_type == EqBand.HPF_BUTTER_1ST):
            xx = (cosW0 + sinW0 - 1) / (cosW0 - sinW0 - 1)
            a0 = 1.0
            b0 = ((1.0 - xx) * .5)
            b1 = -b0
            b2 = 0.0
            a1 = xx
            a2 = 0.0
        elif (self.filter_type in (EqBand.LPF_BUTTER_2ND, EqBand.LPF_ADJ_Q)):
            # LPF, LPF adj Q/Butterworth.. GUI should set proper Q ok
            biquad = 0.0
            order = 2.0
            k = math.pow(10.0, self.gainDb / 20.0)
            damping = 0.0
            if (self.filter_type == EqBand.LPF_BUTTER_2ND):
                # the commented line does not work (it does on calculator but
                # not here) so hardcoding to the typical butterworth damping.
                damping = 2.0 * math.sin(math.pi * (
                    1.0 + 2.0 * (order / 2.0 - 1.0 - biquad)) / (2.0 * order))
                damping = 1.41421356237309490000
            else:
                damping = 1.0 / self.q

            # negate parameter aa for second quadrant of unit circle to reduce
            #  sweep noise
            aa = (2.0 - (damping * sinW0)) / (2.0 + (damping * sinW0))
            if (W0 > (math.pi / 2.0)):
                aa = -aa
            bb = cosW0

            # compute low pass coefficients b_0/4, b_1/4, b_2/4, a_1/2 and
            # a_2/2
            # note that these were copied from assembly and the /4, /2's
            # were removed.
            b0 = ((1.0 + aa) * (1.0 - bb) * (k / 4.0))
            b1 = 2.0 * b0
            b2 = b0
            a1 = -(1.0 + aa) * bb
            a2 = aa
        elif (self.filter_type in (
                EqBand.HPF_BUTTER_2ND, EqBand.HPF_ADJ_Q, EqBand.BESSEL)):
            # HPF, HPF adj Q/Butterworth/bessel.. GUI should set proper Q.
            biquad = 0.0
            order = 2.0
            k = math.pow(10.0, self.gainDb / 20.0)
            damping = 0.0
            if (self.filter_type == EqBand.HPF_BUTTER_2ND):
                damping = 1.41421356237309490000
            else:
                damping = 1.0 / self.q

            # negate parameter aa for second quadrant of unit circle to
            # reduce sweep noise
            aa = (2.0 - (damping * sinW0)) / (2.0 + (damping * sinW0))
            if (W0 > (math.pi / 2.0)):
                aa = -aa

            bb = cosW0

            # note that these were copied from assembly and the /4
            # /2's were removed.
            b0 = ((1.0 + aa) * (1.0 + bb) * (k / 4.0))
            b1 = -2.0 * b0
            b2 = b0
            a1 = -(1.0 + aa) * bb
            a2 = aa
        elif (self.filter_type == EqBand.LOW_SHELF_2ND):  # Lowshelf
            b0 = A * ((A + 1.0) - (A - 1.0) * cosW0 + 2.0 * pow(A, .5) * alpha)
            b1 = 2.0 * A * ((A - 1.0) - (A + 1.0) * cosW0)
            b2 = A * ((A + 1.0) - (A - 1.0) * cosW0 - 2.0 * pow(A, .5) * alpha)
            a0 = (A + 1.0) + (A - 1.0) * cosW0 + 2.0 * pow(A, .5) * alpha
            a1 = -2.0 * ((A - 1.0) + (A + 1.0) * cosW0)
            a2 = (A + 1.0) + (A - 1.0) * cosW0 - 2.0 * pow(A, .5) * alpha
        elif (self.filter_type == EqBand.HI_SHELF_2ND):  # HighShelf
            b0 = A * ((A + 1.0) + (A - 1.0) * cosW0 + 2.0 * pow(A, .5) * alpha)
            b1 = -2.0 * A * ((A - 1.0) + (A + 1.0) * cosW0)
            b2 = A * ((A + 1.0) + (A - 1.0) * cosW0 - 2.0 * pow(A, .5) * alpha)
            a0 = (A + 1.0) - (A - 1.0) * cosW0 + 2.0 * pow(A, .5) * alpha
            a1 = 2.0 * ((A - 1.0) - (A + 1.0) * cosW0)
            a2 = (A + 1.0) - (A - 1.0) * cosW0 - 2.0 * pow(A, .5) * alpha
        elif (self.filter_type == EqBand.LOW_SHELF_1ST):  # lowshelf 1st
            tan_omega_c = math.tan(W0 / 2)
            # compute coefficients
            ggg = math.pow(10, self.gainDb / 20)
            if ggg < 1:  # cut
                tan_omega_c = tan_omega_c / ggg
            aaa = (tan_omega_c - 1) / (tan_omega_c + 1)
            # compute low shelf coefficients a_1/2, b_0/4 and b_1/4
            a1 = aaa
            a2 = 0.0
            b0 = (((1 + aaa) / 2) * (ggg / 4) + (1 - aaa) / 8) * 4
            b1 = (((1 + aaa) / 2) * (ggg / 4) - (1 - aaa) / 8) * 4
            b2 = 0.0
            # message.string_set("a1=%f,b0=%f,b1=%f"%(a1,b0,b1))
        elif (self.filter_type == EqBand.HI_SHELF_1ST):  # highshelf 1st
            tan_omega_c = math.tan(W0 / 2)
            # compute coefficients
            ggg = math.pow(10, self.gainDb / 20)
            if ggg < 1:  # cut
                tan_omega_c = tan_omega_c * ggg
            aaa = (tan_omega_c - 1) / (tan_omega_c + 1)
            # compute high shelf coefficients a_1/2, b_0/4 and b_1/4
            a1 = aaa
            a2 = 0.0
            b0 = ((1 + aaa) / 8 + ((1 - aaa) / 2) * (ggg / 4)) * 4
            b1 = ((1 + aaa) / 8 - ((1 - aaa) / 2) * (ggg / 4)) * 4
            b2 = 0.0
            # message.string_set("a1=%f,b0=%f,b1=%f"%(a1,b0,b1))
        elif (self.filter_type == EqBand.ALLPASS_1ST):  # 1st Order Allpass
            omega_c = (2 * math.pi) * self.fc / self.sample_rate
            tan_omega_c = math.tan(omega_c / 2.0)
            a = (tan_omega_c - 1.0) / (tan_omega_c + 1.0)
            b0 = a
            a1 = a
            b1 = 1.0
            a2 = 0.0  # zero out second order coeffs for first order allpass.
            b2 = 0.0  # zero out second order coeffs for first order allpass.
        elif (self.filter_type == EqBand.ALLPASS_2ND):  # 2nd Order Allpass
            b0 = (1 - (2 * alpha)) / (1 + (2 * alpha))
            b1 = -2 * cosW0 / (1 + (2 * alpha))
            b2 = 1
            a1 = b1
            a2 = b0
        elif (self.filter_type == EqBand.NOTCH):
            b0 = 1 / (1 + (2 * alpha))
            b1 = -2 * cosW0 / (1 + (2 * alpha))
            b2 = b0
            a1 = b1
            a2 = (1 - (2 * alpha)) / (1 + (2 * alpha))
        if (self.filter_type not in (EqBand.PEAKING, EqBand.ALLPASS_2ND)):
            b0 = b0 / a0
            b1 = b1 / a0
            b2 = b2 / a0
            a1 = a1 / a0
            a2 = a2 / a0

        # apply linear pre-gain
        b0 *= self.pregain_lin
        b1 *= self.pregain_lin
        b2 *= self.pregain_lin

        self.biquad = Biquad(b0, b1, b2, a1, a2)

    def is_equal(self, eqBand):
        """
        Check if passed object is equalt to current one.
        """
        # check passed object
        if eqBand == None:
            return False
        # check manual
        if self.manual != eqBand.manual:
            return False
        # check enabled
        if self.enabled != eqBand.enabled:
            return False
        # check fx
        if self.fc != eqBand.fc:
            return False
        # check q
        if self.q != eqBand.q:
            return False
        # check  gainDb
        if self.gainDb != eqBand.gainDb:
            return False
        # check filter type
        if self.filter_type != eqBand.filter_type:
            return False
        # check pregain lin
        if self.pregain_lin != eqBand.pregain_lin:
            return False
        # check sample rate
        if self.sample_rate != eqBand.sample_rate:
            return False
        # check biquad
        if self.biquad == None:
            return False
        if not self.biquad.is_equal(eqBand.biquad):
            return False

        return True

    def plot(self, start_freq, stop_freq, **kwargs):
        """Plot magnitude response of EQ band.

        Args:
            start_freq (flot)
            stop_freq (float)
        """
        try:
            kwargs['verbose'] = self.verbose | kwargs['verbose']
        except KeyError:
            kwargs['verbose'] = self.verbose
        self.calc_magnitude_response(Common.get_freq_points(start_freq, stop_freq, **kwargs))
        mag_list = []
        freq_list = []
        for (frequency, magnitude) in self.gain_points:
            mag_list.append(magnitude)
            freq_list.append(frequency)
        # title = "Magnitude response: Filter="+self.filter_type_str+", Fc=" + str(self.fc) + ", Q=" + str(self.q) + ", Gain=" + str(self.gainDb)
        title = "Magnitude response: Filter= {}, Fc= {}, Q= {}, Gain= {}".format(self.filter_type_str, str(self.fc), str(self.q), str(self.gainDb))
        Common.plot(start_freq, stop_freq, freq_list, mag_list, title)


class MultiBandEq(object):
    """Each instance of this class consist of multiple instance of EQ_Band (IIR Filter).

    This class contains helper function to evaluate multiband eq filter response.
    """

    def __init__(self, eq_bands=None, verbose=0):
        """Instantiate a multibandeq object.

        Args:
            eq_bands (list of EQ_Band)
            verbose (int): 0 = mute print statement, 1 = print
        """
        self.num_bands = len(eq_bands)
        self.eq_bands = eq_bands
        self.verbose = verbose
        self.mag_list = []
        self.freq_list = []
        self.gain_points = []

    def set_verbose(self, verbose=1):
        """Enable/disable print statement."""
        self.verbose = verbose

    def set_eq_bands(self, eq_bands):
        """Set EQ Bands. Return an error if object already contained non-zero number of EQ bands.

        Args:
            eq_bands (list of EQ_Band)
        """
        if self.eq_bands is None:
            self.eq_bands = eq_bands
            if self.verbose:
                print self.eq_bands
        else:
            raise RuntimeError("Multiband EQ is not empty, please use add eq_band or initiate a new multiband EQ.")

    def get_eq_bands(self):
        """Return EQ Bands stored."""
        return self.eq_bands

    def get_eq_band(self, num):
        """Return a specified EQ Band from stored EQ Bands."""
        return self.eq_bands[num]

    def get_as_dict(self):
        """
        returns data held in EqBand as `dict`

        """
        eqs = {}
        for i, eq in enumerate (self.eq_bands):
            eqs["EQ"+str(i)] = {"fc": float(eq.fc) if eq.fc is not None else eq.fc,
                                "q": float(eq.q) if eq.q is not None else eq.q,
                                "gainDb": float(eq.gainDb) if eq.gainDb is not None else eq.gainDb,
                                "filter_type": int(eq.filter_type) if eq.filter_type is not None else eq.filter_type,
                                "pregain_lin": float(eq.pregain_lin) if eq.pregain_lin is not None else eq.pregain_lin,
                                "state": {"manual": eq.manual, "enabled": eq.enabled},
                                "sample_rate": eq.sample_rate}
        return eqs

    def add_eq_band(self, eq_band):
        """Add one or more eq band to existing eq_bands."""
        if type(eq_band) is list:
            self.eq_bands.extend(eq_band)
        else:
            self.eq_bands.append(eq_band)
        if self.verbose:
            print self.eq_bands

    def calc_magnitude_response(self, start_freq, stop_freq, **kwargs):
        """Calculate combined magnitude response of multiband EQ.

        Args:
            start_freq (float)
            stop_freq (float)
        """
        try:
            kwargs['verbose'] = self.verbose | kwargs['verbose']
        except KeyError:
            kwargs['verbose'] = self.verbose
        for eq in self.eq_bands:
            eq.calc_magnitude_response(Common.get_freq_points(start_freq, stop_freq, **kwargs))
            for i, (frequency, magnitude) in enumerate(eq.gain_points):
                try:
                    self.mag_list[i] += magnitude
                except IndexError:
                    self.mag_list.append(magnitude)
                    self.freq_list.append(frequency)

        # self.mag_list = [magnitude/len(self.eq_bands) for magnitude in self.mag_list]
        for mag, freq in zip(self.mag_list, self.freq_list):
            self.gain_points.append((mag, freq))

    def plot(self, start_freq, stop_freq, **kwargs):
        """Plot combined magnitude response of Multiband EQ."""
        self.calc_magnitude_response(start_freq, stop_freq, **kwargs)
        title = "Combined Magnitude Response"
        Common.plot(start_freq, stop_freq, self.freq_list, self.mag_list, title)


class EqBandPair(object):
    """
    Simple wrapper class holding a pair of EqBand objects, but only exposing
    one.
    Offers same base interface as EqBand, and forwards on method calls to
    active EqBand (L, R).
    Also uses __getattr__ for getters of active EqBand member data

    """
    def __init__(self, fc=1000.0, q=1.0, gainDb=0.0,
                 filter_type=EqBand.PEAKING, pregain_lin=1, sample_rate=Common.FS_48K):
        """
        initially makes only one EqBand object (assumes linked,
        and that L is active_channel)

        """
        self.channels = {"L": EqBand(fc, q, gainDb, filter_type, pregain_lin, sample_rate),
                         "R": None}
        self.linked = True
        self.active_channel = "L"

    def __str__(self):
        return "\n".join([(k + ":\n" + str(v)) for (k, v)
                          in self.channels.items()])

    ## EqBandPair state changers:

    def set_linked(self, value):
        """
        Changes whether or not L and R are linked. As __init__ assumes
        linked and only builds one Eqband, we have to copy over the
        data to the other None channel.

        :param value: bool to be assigned to self.linked

        """
        self.linked = value
        if not value:
            for name in self.channels:
                if self.channels[name] is None:
                    self.channels[name] = copy.deepcopy(
                        self.channels[self.active_channel])

    def set_active_channel(self, name, band=None):
        """
        Change self.active_channel to be name. If that channel is empty,
        copy over what we have from the other.

        :param name: "L" or "R"
        :param band: EqBand object to be slotted in if needs be

        """
        if name not in ("L", "R"):
            raise KeyError("Not an available channel")

        if self.linked:
            return

        # overwrite current EqBand at :name: with optional :band: arg
        if isinstance(band, EqBand):
            self.channels[name] = band
        elif self.channels[name] is None:
            self.channels[name] = copy.deepcopy(
                self.channels[self.active_channel])

        self.active_channel = name

    def __getattr__(self, attr):
        """
        Forwards all same interface calls onto active_channel

        """
        return getattr(self.channels[self.active_channel], attr)

    def get_as_dict(self):
        """
        Here we get the self.channels dict, but with each EqBand get_as
        dict()ed

        """

        out = {"linked": self.linked, "active_channel": self.active_channel}
        if self.linked:
            # just return active (or Master) channel
            out["channels"] = {self.active_channel:
                               self.channels[
                                   self.active_channel].get_as_dict()}
        else:
            # check we're not spitting out None
            for k, v in self.channels.items():
                if v is None:
                    self.channels[k] = copy.deepcopy(
                        self.channels[self.active_channel])
            out["channels"] = dict([(k, self.channels[k].get_as_dict())
                                    for k in self.channels])

        return out

    def get_biquads_for_anx(self):
        """
        Generates biquad pairs in easy parsable format.

        :returns: biquad coefficients (L and R if unlinked) in dict keyed by
        names from stg-project

        """
        coeffs = {}
        if self.linked:
            coeffs["B0"] = [self.channels[self.active_channel].biquad.b0] * 2
            coeffs["B1"] = [self.channels[self.active_channel].biquad.b1] * 2
            coeffs["B2"] = [self.channels[self.active_channel].biquad.b2] * 2
            coeffs["MA1"] = [-self.channels[self.active_channel].biquad.a1] * 2
            coeffs["MA2"] = [-self.channels[self.active_channel].biquad.a2] * 2
        else:
            coeffs["B0"] = []
            coeffs["B1"] = []
            coeffs["B2"] = []
            coeffs["MA1"] = []
            coeffs["MA2"] = []
            for ch in ("L", "R"):
                coeffs["B0"].append(self.channels[ch].biquad.b0)
                coeffs["B1"].append(self.channels[ch].biquad.b1)
                coeffs["B2"].append(self.channels[ch].biquad.b2)
                coeffs["MA1"].append(-self.channels[ch].biquad.a1)
                coeffs["MA2"].append(-self.channels[ch].biquad.a2)
        return coeffs

    def set_from_dict(self, data):
        """
        Loop through "L" and "R" channels and set EqBands with set_from_dict

        :param data: `dict` containing info for EqbandPair
        """

        self.active_channel = data["active_channel"]
        self.linked = data["linked"]

        for channel_name in self.channels:
            if (channel_name == data["active_channel"]) or (
                    not data["linked"]):
                if self.channels[channel_name] is None:
                    self.channels[channel_name] = EqBand()
                self.channels[channel_name].set_from_dict(
                    data["channels"][channel_name])
            else:
                self.channels[channel_name] = None

    def is_equal(self, eqBandPair):
        """
        Check if passed object is equalt to current one.
        """
        # check passed object
        if eqBandPair == None:
            return False
        # check linked
        if self.linked != eqBandPair.linked:
            return False
        # check active channel
        if self.active_channel != eqBandPair.active_channel:
            return False
        # check left channel
        if self.channels["L"] == None:
            return False
        if not self.channels["L"].is_equal(eqBandPair.channels["L"]):
            return False
        # check right channel and if it is None do nothing as it is default state
        if self.channels["R"] != None and not self.channels["R"].is_equal(eqBandPair.channels["R"]):
            return False

        return True

# ----------------------------------------------------------------------------
# generic.py
# Gabriel Seitz
# 2016-11-1
# contains classes for a generic device (com object + register map)
# ----------------------------------------------------------------------------

# Imports
# ----------------------------------------------------------------------------

from cirrusvue.core.utilities import reg_map, file_parser
#from core.utilities.compatability import *

# ----------------------------------------------------------------------------

# Definitions
# ----------------------------------------------------------------------------
class GenericDevice(object):
    """generic device class

    """
    def __init__(self, com, definition_file=None, verify=True, page_address=None, devname = 'unnamed'):
        """instantiate a generic I2C device object

        Args:
            com (obj): commmunication object containing write() and read() methods
            definition_file (list): path to device definition file
            page_address (int): address of page register

        """
        self.com = com
        self.device_name = devname
        self._default_verify = verify
        self._page_address = page_address
        

        if definition_file is not None:
            if '.xml' in definition_file:
                parse = reg_map.parse_xml
            elif '.json' in definition_file:
                parse = reg_map.parse_json
            elif '.txt' in definition_file:
                parse = reg_map.parse_cpmap
            elif '.html' in definition_file:
                parse = reg_map.parse_html
            else:
                raise ValueError(definition_file)
            self.fields, self.regs = parse(definition_file)


    @staticmethod
    def definition_path(starting_file, relative_path):
        """create a robust and cross-platform file path

        Args:
            starting_file (?): beginning point of relative path, usually __file__ 
            relative_path (list): sequence of steps from start to target file

        """
        return file_parser.get_absolute_path(starting_file, relative_path)


    def _check_access(self, access, register_access, field_access=None):
        """
        """
        if access == 'read':
            if 'R/W' in register_access or 'R/O' in register_access:
                if field_access is None:
                    access_ok = True
                else:
                    if 'R/W' in field_access or 'R/O' in field_access:
                        access_ok = True
                    else:
                        access_ok = False
            else:
                access_ok = False
        elif access == 'write':
            if 'R/W' in register_access or 'W/O' in register_access:
                if field_access is None:
                    access_ok = True
                else:
                    if 'R/W' in field_access or 'W/O' in field_access:
                        access_ok = True
                    else:
                        access_ok = False
            else:
                access_ok = False
        else:
            raise ValueError(access)

        return access_ok


    def _read_modify_write(self, com, reg_info, field_info, value, verify, *args, **kwargs):
        """write to a single bit-field, leaving the others untouched

        Args:
            com (class): communication object (e.g. device.i2c)
            field_info (dict): must contain 'mask', and 'lsbit'
                access (str): read / write access of the field
                mask (int): bit locations that belong to the field (1=included)
                lsbit (int): lowest bit location of the field
            reg_info (dict): must contain 'access', 'default' and 'length'
                address (int): address of register
                access (str): read / write access of the register
                default (int): default value of the register
                length (int): number of bits in the register
            value (int): new field setting

        """
        # input value should be within range of the mask
        if field_info['mask']&(value<<field_info['lsb']) != (value<<field_info['lsb']):
            raise ValueError("Incorrect value ({:#x}), mask ({:#x}), or lsb ({})".format(value, field_info['mask'], field_info['lsb']))

        # sort access types:
        read_ok = self._check_access('read', reg_info['access'], field_info['access'])

        # get value of register to modify
        if read_ok:
            prev_val = com.read(reg_info['address'], *args, **kwargs)
        else:
            prev_val = reg_info['default']

        # calculate register value to be written (masked write)
        new_val = ((value<<field_info['lsb'])&field_info['mask'])|(prev_val&(~field_info['mask']))

        # write value to device
        com.write(reg_info['address'], new_val, *args, **kwargs)

        # option to check that value was written correctly
        if verify and read_ok:
            check_val = com.read(reg_info['address'], *args, **kwargs)
            if check_val != new_val:
                raise RuntimeError("Error writing to {:#x}. Value read back ({:#x}) does not match written value ({:#x})".format(reg_info['address'], check_val, new_val))


    def _read_masked(self, com, reg_info, field_info, *args, **kwargs):
        """reads and returns the value of a bit-field

        Args: (outdated)
            com (class): communication object (e.g. device.i2c)
            field_info (dict): must contain 'mask', and 'lsbit'
                access (str): read / write access of the field
                mask (int): bit locations that belong to the field (1=included)
                lsbit (int): lowest bit location of the field
            reg_info (dict): must contain 'access', 'default' and 'length'
                address (int): address of register
                access (str): read / write access of the register
                default (int): default value of the register
                length (int): number of bits in the register

        Returns:
            field_value (int): value of the bit-field

        """
        # sort access types:
        if not self._check_access('read', reg_info['access'], field_info['access']):
            print("Warning! Attempting read from {} field in {} register at {:#x}".format(field_info['access'], reg_info['access'], reg_info['address']))

        # read register value from device
        reg_value = com.read(reg_info['address'], *args, **kwargs)

        # calculate value of the field
        field_value = (reg_value&field_info['mask'])>>field_info['lsb']
        field_value = int(field_value)  # remove trailing 'L' that indicates a long int

        return field_value


    def _write_with_context(self, com, reg_info, value, verify, *args, **kwargs):
        """write to a single register using device knowledge

        Args:
            com (class): communication object (e.g. device.i2c)
            reg_info (dict): must contain 'access' and 'length'
                address (int): address of register
                access (str): read / write access of the register
                length (int): number of bits in the register
            value (int): new register setting
            verify (bool): option to read the field to verify the write was succesfull, only applies for 'R/W'

        """
        # write value to device
        com.write(reg_info['address'], value, *args, **kwargs)

        # option to check that value was written correctly
        if verify and 'R/W' in reg_info['access']:
            check_val = com.read(reg_info['address'], *args, **kwargs)
            if check_val != value:
                raise RuntimeError("Error writing to {:#x}. Value read back ({:#x}) does not match written value ({:#x})".format(reg_info['address'], check_val, value))


    def _read_with_context(self, com, reg_info, *args, **kwargs):
        """read from a single register using device knowledge

        Args:
            com (class): communication object (e.g. device.i2c)
            reg_info (dict): must contain 'access' and 'length'
                address (int): address of register
                access (str): access property of the register
                length (int): number of bits in the register

        """
        # Retrieve parameters from dictionaries
        address = reg_info['address']
        reg_access = reg_info['access']

        # check access to register
        if reg_access not in ['R/W', 'R/O']:
            print("Warning! Attempting to read {} register at {:#x}".format(reg_access, address))

        # read register value from device
        reg_value = com.read(address, *args, **kwargs)
        reg_value = int(reg_value)  # remove trailing 'L' that indicates a long int

        return reg_value


    def _get_field_info(self, name):
        """
        """
        try:  # to get all of the required variables
            if isinstance(name, str):  # dictionary based
                field_info = dict(self.fields[name])
            else:  # object based
                field_info = {'register': name.register, 'mask': name.mask, 'lsb': name.lsb, 'access': name.access, 'default': None}
        except (KeyError, AttributeError):
            raise RuntimeError('Could not lookup ' +name)

        return field_info


    def _get_register_info(self, register, unknown_access='R/W'):
        """
        """
        try:
            register_info = dict(self.regs[register])
            if isinstance(register_info, (int, long)): 
                raise AttributeError  # cp_map doesn't contain register info
        except (KeyError, AttributeError):  # set default unknown register properties
            register_info = {'address': register, 'access': unknown_access}

        return register_info


    def write_field(self, name, value, verify=None):
        """Perform a read-modify-write by bitfield name
        then optionally read again to verify the write took place.

        Args:
            name (str): field name
            value (int): value to write

        """
        if verify is None:
            verify = self._default_verify

        field_info = self._get_field_info(name)
        register_info = self._get_register_info(field_info['register'])

        if self._page_address is not None:
            self.com.write(self._page_address, register_info['page'])
        self._read_modify_write(self.com, register_info, field_info, value, verify)


    def read_field(self, name):
        """Read by bitfield name and return the value of the bitfield.

        Args:
            name (str): field name

        Returns:
            value (int): value of bitfield

        """
        field_info = self._get_field_info(name)
        register_info = self._get_register_info(field_info['register'])

        if self._page_address is not None:
            self.com.write(self._page_address, register_info['page'])
        value = self._read_masked(self.com, register_info, field_info)

        return value


    def write_register(self, register, value, verify=None):
        """configure a register using device knowledge and
        then optionally read to verify the write took place.

        Args:
            register (str): register address
            value (int): value to write

        """
        if verify is None:
            verify = self._default_verify

        register_info = self._get_register_info(register, 'W/O')

        if self._page_address is not None:
            self.com.write(self._page_address, register_info['page'])
        self._write_with_context(self.com, register_info, value, verify)


    def read_register(self, register):
        """read from a register by address and return its value. If possible, use device knowledge.

        Args:
            register (int): register address

        Returns:
            value (int): value of register

        """
        register_info = self._get_register_info(register, 'R/O')

        if self._page_address is not None:
            self.com.write(self._page_address, register_info['page'])
        value = self._read_with_context(self.com, register_info)

        return value


    def search_for_field(self, search_name):
        """
        """
        for field_name in self.fields.keys():
            if search_name in field_name:
                print(field_name)
# ----------------------------------------------------------------------------
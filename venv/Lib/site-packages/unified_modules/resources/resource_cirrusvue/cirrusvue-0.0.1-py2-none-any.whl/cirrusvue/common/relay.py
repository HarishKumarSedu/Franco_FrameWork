# ----------------------------------------------------------------------------
# relay.py
# Dakota Koelling
# 2018-07-04
# contains classes for a Relay
# ----------------------------------------------------------------------------

# Imports
# ----------------------------------------------------------------------------
from .generic import GenericDevice
# ----------------------------------------------------------------------------

# Definitions
# ----------------------------------------------------------------------------


class RelayController(GenericDevice):
    """Relay device class

    """

    def __init__(self, number: int, com, definition_file=None, page_address=None):
        """instantiate a generic I2C device object

        Args:
            number (int): Relay Controller index number
            com (obj): commmunication object containing write() and read() methods
            definition_file (list): path to device definition file
            page_address (int): address of page register

        """

        self.number = number
        self.com = com
        GenericDevice.__init__(com, definition_file, page_address)

        # Setup GPIO expander
        self.com.write(0x02, 0x00)  # Set output port 0 to drive all zeros
        self.com.write(0x03, 0x00)  # Set output port 1 to drive all zeros
        self.com.write(0x06, 0x00)  # Configure port 0 as all outputs
        self.com.write(0x07, 0x00)  # Configure port 1 as all outputs


class Relay:
    """Relay device class

    """

    def __init__(self, name: str, port: int, bit: int, controller: RelayController = None):
        """instantiate a generic I2C device object

        Args:
            name (str): Name
            definition_file (list): path to device definition file
            page_address (int): address of page register

        """

        self.name = name
        self.port = port
        self.bit = bit
        self.controller = controller

    def set_relay(self, on_off: int = 0):
        """Sets the relays on the EEB.

         [INPUTS]
           on_off (int): 0 - set relay to default state (off), 1 - switch relay (on)

         ex: eeb.set_relay(1)  # close AIN1 CMRR relay
        """

        if on_off != 0:
            on_off = 1  # This makes it easier to account for shift issues when not passing in a 1

        if self.controller:  # GPIO expander (1/2/3/4 - EEB; 5/6/7 - PSRR DC)
            # Get relay port information
            rly_port = self.port
            rly_bit = self.bit

            if rly_port == 0:
                status_reg = 0x00
                write_reg = 0x02
            elif rly_port == 1:
                status_reg = 0x01
                write_reg = 0x03
            else:
                assert False, 'Invalid port'

            # Mask current register setting with new bit value
            read_val = self.controller.com.read(status_reg)  # read from input registers
            bit_mask = ~(1 << rly_bit)  # create mask to clear bit
            read_val_masked = read_val & bit_mask  # clear bit
            write_val = read_val_masked | on_off << rly_bit  # write to appropriate bit
            self.controller.com.write(write_reg, write_val)  # write to GPIO expander to set relay
        else:  # FPGA controls relay
            assert False, "Connect fpga controls in relay.py"
            #write_reg = self.FPGA_REG
            #self.fpga_write_field(fpga.(write_reg), on_off)

# ----------------------------------------------------------------------------
# apb.py
# Gabriel Seitz
# 2016-11-14
# contains functions to generate apb SPI parameters required for the Linux Driver
# ----------------------------------------------------------------------------

# Imports
# ----------------------------------------------------------------------------
from . import repack
# ----------------------------------------------------------------------------

# Definitions
# ----------------------------------------------------------------------------
def create_cmd_resp(mode, apb_ctrl, address=0, block_length=0, apb_cmd=0):
    # create empty Command Response Buffer
    cmd_resp = []

    # Byte[0:3] convert register address from int to reversed byte array (msb is low)
    # cmd_resp[0] = address (msb)
    # cmd_resp[1] = address
    # cmd_resp[2] = address (lsb)
    # cmd_resp[3] = address (unused)
    addr_bytes = repack.int_to_array(address, 3)
    cmd_resp.extend(addr_bytes)
    cmd_resp.append(0)

    # Byte[4:5] convert block length from int to reversed byte array (msb is low)
    # cmd_resp[4] = block length (msb)
    # cmd_resp[5] = block length (lsb)
    blk_len_bytes = repack.int_to_array(block_length, 2)
    cmd_resp.extend(blk_len_bytes)

    # cmd_resp[6] = APB Command
    cmd_resp.append(apb_cmd)

    # Byte[7] APB Control
    cmd_resp.append(apb_ctrl)

    # Byte[8] Full Duplex vs APB
    if mode == 'apb':
        cmd_resp.append(1)
    else: # full duplex
        cmd_resp.append(0)
    
    return cmd_resp

    
def create_apb_ctrl(mode, apb_cmd=None):
    if mode == 'apb':
        poll_status = True
        return_status = False
        transaction = True
        send_block_length = True  # don't care
        send_address = True  # don't care
        if apb_cmd == 0xB2:  # write 4 bytes
            read_writeb = False
            word_byteb = True
        elif apb_cmd == 0xB5:  # write 1 byte
            read_writeb = False
            word_byteb = False
        elif apb_cmd == 0xC4:  # read 4 bytes
            read_writeb = True
            word_byteb = True
        elif apb_cmd == 0xC6:  # read 1 byte
            read_writeb = True
            word_byteb = False
        else:
            raise ValueError("Invalid APB_CMD ({})".format(apb_cmd))
    else:
        poll_status = False
        return_status = False
        transaction = False  # perform single APB command
        read_writeb = False  # ?
        word_byteb = False  # ?
        send_block_length = False  # ?
        send_address = False  # ?

    apb_ctrl = (poll_status<<6) | (return_status<<5) | (transaction<<4) | (read_writeb<<3) | (word_byteb<<2) | (send_block_length<<1) | (send_address<<0)

    return apb_ctrl
# ----------------------------------------------------------------------------
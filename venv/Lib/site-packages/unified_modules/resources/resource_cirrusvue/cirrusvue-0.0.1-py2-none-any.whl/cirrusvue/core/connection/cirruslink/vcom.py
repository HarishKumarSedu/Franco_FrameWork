# ----------------------------------------------------------------------------
# vcom.py
# Gabriel Seitz
# 2018-xx-xx
# contains the CirrusLink class that communicates over CDC Serial to the 
# CirrusLink Server running on the Zynq
# ----------------------------------------------------------------------------

# Imports
# ----------------------------------------------------------------------------
import binascii
from ...utilities import repack
import os
import serial
from serial.tools import list_ports
# ----------------------------------------------------------------------------

# Definitions
# ----------------------------------------------------------------------------
class CirrusLinkClient(object):
    """CirrusLink class to open a client socket and communicate with the cl_server

    """

    _TX_SYNC = [0x19, 0x79]
    _RX_SYNC = [0x19, 0x78]
    _FLAG = 0x40  # always request a return packet to check for errors
    _HOST_ID = 0x90  # can be anything
    _CDC_MULTI_VID = "0429"
    _CDC_MULTI_PID = "0142"


    def __init__(self, address, timeout=1, verbose=False):
        """Instantiate a CirrusLinkClient object.
        
        Args:
            address (str): target hostname or IP address
            timeout (int): packet wait time in seconds
            verbose (bool): option to print detailed information

        """
        self._verbose = verbose
        self._address = address
        self._timeout = timeout
        self._pkt_id = 0x00
        self._com_port = None
        self._handle = None
        self._connect()
        if self._verbose:
            print("Connected to {}".format(self._com_port))
        

    def __del__(self):
        self._disconnect()


    def set_verbose(self, state):
        """Control printing behavior

        Args:
            state (int, bool): turn on or off verbose print statements

        """
        self._verbose = True if state else False

    def _connect(self):
        """Open a new serial connection and save the object

        """
        # self._handle = socket.create_connection((self._address, self._port), self._timeout)

        try:
            if self._verbose:
                print ('Looking for COM port with VID:PID {}:{}'.format(self._CDC_MULTI_VID, self._CDC_MULTI_PID))

            comm_ports = self._get_comm_port()

            num_ports = len(comm_ports)

            if num_ports == 0:
                print('No COM ports found')
                return
            else:
                if self._verbose:
                    print "    Found %d valid comm ports" % num_ports
                    print "    Port(s) found %s" % comm_ports
                if num_ports > 1:
                    nb = raw_input('Choose port index (0,1,2,...n): ')
                    nb_index = int(nb)
                    if nb_index > num_ports:
                        print "Invalid index"
                        return
                    else:
                        comm_port = comm_ports[nb_index]
                else:
                    comm_port = comm_ports[0]
                print "    Using comm port %s" % comm_port

                self._handle = serial.Serial(
                    port=comm_port,
                    baudrate=4000000,
                    parity=serial.PARITY_NONE,
                    stopbits=serial.STOPBITS_ONE,
                    bytesize=serial.EIGHTBITS,
                    timeout=None
                )
                self._com_port = comm_port
        except Exception as e:
            print e

        finally:
            if self._com_port == None:
                raise RuntimeError('USBConnect_CDC COM port with VID:PID {}:{} not found'.format(self._CDC_MULTI_VID, self._CDC_MULTI_PID))

    def _disconnect(self):
        """Cleanly close the serial port

        """
        if self._handle is not None:
            if self._verbose:
                print("Disconnecting from {}".format(self._com_port))
            self._flush()
            self._handle.close()

    def _flush(self):
        """Read from the receive buffer until empty

        """
        self._handle.flush()

    def _generate_new_pkt_id(self):
        """Increment the packet ID

        """
        self._pkt_id = (self._pkt_id+1)%255  # 0 to 0xFE since 0xFF is special

    def _construct_packet(self, clink_class, clink_class_ext, clink_payload):
        """Create a generic packet according to the CirrusLink Protocol

        Args:
            clink_class (int): CLASS byte
            clink_class_ext (list of int): CLASS_EXT (0-255 bytes)
            clink_payload (list of int): PAYLOAD (0-2048 bytes)

        Returns:
            packet (bytearray): complete CirrusLink packet

        """
        # if self._verbose:
        # print("CLASS:", hex(clink_class))
        # print("CLASS_EXT:", [hex(i) for i in clink_class_ext])
        # print("PAYLOAD:", [hex(i) for i in clink_payload])

        packet = bytearray(self._TX_SYNC)

        packet.append(self._FLAG)

        packet.append(clink_class)

        packet.extend(clink_class_ext)

        packet.append(self._HOST_ID)

        packet.append(self._pkt_id)

        payload_length = len(clink_payload)
        packet.extend(repack.int_to_array(payload_length, 2))

        packet.extend(clink_payload)

        crc32 = binascii.crc32(packet) & 0xffffffff  # avoid negative numbers
        packet.extend(repack.int_to_array(crc32, 4))

        return packet

    def _transmit(self, packet):
        """Write all bytes to the transmit buffer

        Args:
            packet (bytearray): bytes to transmit

        """
        if self._verbose:
            print("Transmit Packet:")
            print([hex(i) for i in packet])
            print("")

        self._handle.write(packet)

    def _receive(self, class_ext_length):
        """Read one CirrusLink packet from the receive buffer

        Args:
            class_ext_length (int): expected number of bytes in the CLASS_EXT

        Returns:
            payload (list of int): returned payload bytes
            error (int): error flag, 1 indicates an error occured

        """
        packet = bytearray()

        remaining_bytes = class_ext_length + 8  # read partial packet to get variable payload length
        while remaining_bytes > 0:
            chunk = self._handle.read(remaining_bytes)  # Get available data
            packet.extend(chunk)  # Add to message
            remaining_bytes -= len(chunk)

        sync_pkt = [i for i in packet[:2]]
        if sync_pkt != self._RX_SYNC:
            raise RuntimeError("returned SYNC ({}) is invalid.".format(sync_pkt))

        host_id_pkt = packet[class_ext_length + 4]
        if host_id_pkt != self._HOST_ID:
            raise RuntimeError(
                "returned HOST_ID ({}) does not match sent HOST_ID ({}).".format(host_id_pkt, self._HOST_ID))

        pkt_id_pkt = packet[class_ext_length + 5]
        if pkt_id_pkt != self._pkt_id:
            raise RuntimeError("returned PKT_ID ({}) does not match sent PKT_ID ({}).".format(pkt_id_pkt, self._pkt_id))

        payload_length = (packet[class_ext_length + 6] << 8) | packet[class_ext_length + 7]

        remaining_bytes = payload_length + 4
        while remaining_bytes > 0:
            chunk = self._handle.read(remaining_bytes)  # Get available data
            packet.extend(chunk)  # Add to message
            remaining_bytes -= len(chunk)

        # check crc32 of return packet
        crc32_calc = binascii.crc32(packet[:len(packet) - 4]) & 0xffffffff  # avoid negative numbers
        crc32_pkt = repack.array_to_int(i for i in packet[-4:])
        if crc32_pkt != crc32_calc:
            raise RuntimeError(
                "returned CRC32 ({}) does not match calculated CRC32 ({}).".format(crc32_pkt, crc32_calc))

        error = (packet[2] >> 5) & 1

        payload_bytes = packet[class_ext_length + 8:-4]
        payload = [i for i in payload_bytes]  # convert bytearray to list of ints

        if self._verbose:
            print("Received Packet")
            print([hex(i) for i in packet])
            print("")

        return payload, error


    def send(self, clink_class, clink_class_ext=None, clink_tx_payload=None):
        """Perform a CirrusLink transaction (construct, transmit and receive)

        Args:
            clink_class (int): CLASS byte
            clink_class_ext (list of int): CLASS_EXT (0-255 bytes), defaults to None
            clink_tx_payload (list of int): PAYLOAD (0-2048 bytes), defaults to None

        Returns:
            clink_rx_payload: payload bytes returned from CirrusLink Server

        """
        if clink_tx_payload is None:
            clink_tx_payload = []

        if clink_class_ext is None:
            clink_class_ext = []

        self._generate_new_pkt_id()

        tx_packet = self._construct_packet(clink_class, clink_class_ext, clink_tx_payload)

        try:
            self._transmit(tx_packet)
            clink_rx_payload, clink_error = self._receive(len(clink_class_ext))
        except RuntimeError as e:
            print("Serial packet error occurred, automatically flushing serial buffers...")
            self._flush()
            raise RuntimeError(e)

        if clink_error:
            for byte in clink_rx_payload:
                if byte != 0xff and byte != 0x00:  # temporary workound
                    e = ((-byte) & 0xff) >> 4
                    raise RuntimeError(
                        "CirrusLink Server reported an error occurred: [Errno {}] {}".format(e, os.strerror(e)))
            else:
                raise RuntimeError("CirrusLink Server reported an unknown error occurred: {:#x}".format(
                    repack.array_to_int(clink_rx_payload)))

        return clink_rx_payload


    def _get_comm_port(self):
        """ Get list of COM ports

        :return: list of COM ports found
        """
        found_ports = []
        for port in list(list_ports.comports()):
            # print (port[0] + " : " + port[2] + " : " + port[1])
            if (self._CDC_MULTI_VID in port[2].lower()) and \
                    (self._CDC_MULTI_PID in port[2].lower()):
                found_ports.append(port[0])
        return found_ports

# ----------------------------------------------------------------------------
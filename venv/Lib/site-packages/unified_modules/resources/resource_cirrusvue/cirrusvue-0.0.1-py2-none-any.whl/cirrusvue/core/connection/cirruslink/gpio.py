# ----------------------------------------------------------------------------
# gpio.py
# Gabriel Seitz
# 2018-05-23
# contains the communication class that implements the CirrusLink GPIO protocol
# ----------------------------------------------------------------------------

# Imports
# ----------------------------------------------------------------------------
from ...utilities import repack
# ----------------------------------------------------------------------------

# Definitions
# ----------------------------------------------------------------------------
class GPIO(object):
    """Communication class for GPIO.

    """
    _CLINK_CLASS_CONFIG = 0x40
    _CLINK_CLASS_WRITE = 0x41
    _CLINK_CLASS_READ = 0x42
    _REG_NUM = 0  # only value used

    def __init__(self, clink, pin, direction='preserve', verbose=False):
        """Instantiate an GPIO object.

        Args:
            clink (obj): CirrusLinkClient object
            pin (int): number corresponding to pin, can be 0-31
            direction (str): pin direction, can be "in", "out", "high", "low", or "preserve"
            verbose (bool): option to print detailed information

        Returns:
            GPIO: gpio handle

        """
        self._verbose = verbose
        self._clink = clink
        self._pin = pin
        self._mask = (~(1<<self._pin))&0xffffffff
        
        direction = direction.lower()
            
        if direction in ['in', 'input', 'hiz', 'hi-z']:
            self.set_direction(0)
        
        if direction == 'low':
            self.write(0)
        if direction == 'high':
            self.write(1)
            
        if direction in ['out', 'output', 'high', 'low']:
            self.set_direction(1)


    def set_verbose(self, state):
        """Control printing behavior

        Args:
            state (int, bool): turn on or off verbose print statements

        """
        self._verbose = True if state else False
        
        
    def _set_configuration(self, value):
        """
        """
        clink_class_ext = [self._REG_NUM, 0]
        data_bytes = repack.int_to_array(value, 4)
        self._clink.send(self._CLINK_CLASS_CONFIG, clink_class_ext, data_bytes)
        
        
    def _get_configuration(self):
        """
        """
        clink_class_ext = [self._REG_NUM, 1]
        data_bytes = self._clink.send(self._CLINK_CLASS_CONFIG, clink_class_ext)
        value = repack.array_to_int(data_bytes)
        
        return value
    
    
    def set_direction(self, direction):
        """configure the input/output direction of the GPIO pin

        Args:
            direction (str, int, bool): can be 'out'=1 or 'in'=0

        """
        if isinstance(direction, str):
            if direction.lower() in ['out', 'output']:
                direction = 1
            if direction.lower() in ['in', 'input', 'hiz', 'hi-z']:
                direction = 0
        
        old_value = self._get_configuration()
        new_value = ((direction<<self._pin)&(~self._mask))|(old_value&self._mask)
        self._set_configuration(new_value)

        if self._verbose:
            print("GPIO Configuration: Pin = {}; Direction = {}".format(self._pin, direction))
    
    
    def _write_all(self, payload):
        """
        """
        clink_class_ext = repack.int_to_array(self._mask, 4)
        self._clink.send(self._CLINK_CLASS_WRITE, clink_class_ext, payload)
    
    
    def _read_all(self):
        """
        """
        payload = self._clink.send(self._CLINK_CLASS_READ)
        return payload
    
    def write(self, state):
        """Set the output state. The direction must be set to output.

        Args:
            state (int, bool): drive pin high/low

        """
        data_bytes = [0xff, 0xff, 0xff, 0xff] if state else [0x00, 0x00, 0x00, 0x00]
        self._write_all(data_bytes)

        if self._verbose:
            print("GPIO Write: Pin = {}; State = {}".format(self._pin, state))
        
    
    def read(self):
        """Get the current state

        Returns:
            state (int): high/low status of pin

        """
        data_bytes = self._read_all()
        state = (repack.array_to_int(data_bytes)>>self._pin)&1

        if self._verbose:
            print("GPIO Read: Pin = {}; State = {}".format(self._pin, state))

        return state
# ----------------------------------------------------------------------------
# ----------------------------------------------------------------------------
# isense.py
# Dakota Koelling
# 2018-07-14
# contains classes for a Current Sense
# ----------------------------------------------------------------------------

# Imports
# ----------------------------------------------------------------------------
from .generic import GenericDevice
import time
# ----------------------------------------------------------------------------

# Definitions
# ----------------------------------------------------------------------------


class ISense(GenericDevice):
    """Current Sense device class

    """

    def __init__(self, number: int, com, resistor: int = 10, definition_file=None, page_address=None):
        """Instantiate a DAC device object

        Args:
            number (int): DAC index number
            com (obj): communication object containing write() and read() methods
            resistor (int): value of current sense resistor in ohms
            definition_file (list): path to device definition file
            page_address (int): address of page register

        """

        self.number = number
        self.com = com
        self.resistor = resistor
        GenericDevice.__init__(com, definition_file, page_address)

        # Configuration register
        cfg_rst = '0'  # writing '1' issues POR. This bit self-clears.
        cfg_avg = '000'  # 1 average (default)
        cfg_vbusct = '100'  # vbus voltage conversion time is 1.1ms (default). This affects accuracy.
        cfg_vshct = '100'  # shunt voltage conversion time is 1.1ms (default). This affects accuracy.
        cfg_mode = '111'  # shunt and bus voltage measurements are continuous (default).

        cfg_wr_val = int(cfg_rst + '100' + cfg_avg + cfg_vbusct + cfg_vshct + cfg_mode, 2)
        self.com.write(0x00, cfg_wr_val)

    def read_from_isns(self, isns_res: int = -1):
        """function [current, voltage, current_valid, voltage_valid] = read_from_isns(isns_res)

        [INPUT]
          isns_res: value of current sense resistor (ohms) [numeric]
            If not specified, uses defined value

        [OUTPUT]
          current: measured shunt current (uA) [double]
          voltage: measured VBUS voltage (V) [double]
          current_valid: indicated whether current reading is valid [numeric]
              This is a simple check to see if the code read out is the absolute
              min or max of the register range.
          voltage_valid: indicated whether voltage reading is valid [numeric]
              This is a simple check to see if the code read out is the absolute
              min or max of the register range.

        example: eeb.read_from_isns('80', 10)
        """

        # ISENSE parameters
        vsht_lsb = 2.5e-6  # shunt voltage resolution is 2.5uV
        vbus_lsb = 1.25e-3  # vbus voltage resolution is 1.25mV
        isense_reg_width = 16  # register width is 16 bits

        # BUS Voltage Register
        vbus_rd_val = self.com.read(0x02)
        vbus_rd_min = True if vbus_rd_val == 0x0000 else False
        vbus_rd_max = True if vbus_rd_val == 0x7FFF else False
        vbus_rd_val = int(vbus_rd_val)  # vbus is only represented as 15-bit positive (MSB is always 0, according to DS)
        voltage = vbus_rd_val * vbus_lsb  # Calculate voltage (V)

        # Shunt Voltage Register
        vsht_rd_val = self.com.read(0x01)
        vsht_rd_min = True if vsht_rd_val == 0x8000 else False
        vsht_rd_max = True if vsht_rd_val == 0x7FFF else False
        vsht_rd_val = twoscomp2dec(vsht_rd_val, isense_reg_width)  # vsht is represented as 16-bit two's complement
        vsht_rd_val = vsht_rd_val * vsht_lsb  # Calculate voltage (V)
        if isns_res == -1:
            isns_res = self.resistor
        current = (vsht_rd_val / isns_res) * 1e6  # calculate current (uA)

        # Check limits (ALERT pin isn't used)
        if vsht_rd_min or vsht_rd_max:
            assert False, 'Current is out of ISENSE range. The measurement is invalid!\n'
            current_valid = 0
        else:
            current_valid = 1
        if vbus_rd_min or vbus_rd_max:
            assert False, 'VBUS voltage is out of ISENSE range. The measurement is invalid!\n'
            voltage_valid = 0
        else:
            voltage_valid = 1

        return (current, voltage, current_valid, voltage_valid)

    def get_isns_meas(self):
        """(current, voltage, current_valid, voltage_valid) = get_isns_meas()

        [INPUT]
          supply: DAC output to measure
              Pass multiple DACs as a cell of structs. Single DACs are passed in
              as either a cell-struct or a struct. If 'ALL' is passed in, all
              supplies will be measured.

        [OUTPUT]
          current: measured current (uA) [double]
          voltage: measured voltage (V) [double]
          current_valid: indicated whether current reading is valid [numeric]
              This is a simple check to see if the code read out is the absolute
              min or max of the register range.
          voltage_valid: indicated whether voltage reading is valid [numeric]
              This is a simple check to see if the code read out is the absolute
              min or max of the register range.

        example: eeb.get_isns_meas(eeb.VDD_D);
        """

        isense_input_res = 830e3  # due to an ISENSE hook-up oversight, this causes a parasitic current in the measurement

        # WORKAROUND: disable DAC I2C level shifter (DAC broadcast address is the same as ISENSE #8)
        self.reg.cp_dac_i2c_en = 0  # disable DAC I2C level shifter

        time.sleep(0.05)
        (current, voltage, current_valid, voltage_valid) = self.read_from_isns()
        current = current - ((voltage / isense_input_res) * 1e6)  # WORKAROUND: trim out parasitic ISENSE current (uA)

        # WORKAROUND: re-enable DAC I2C level shifter (DAC broadcast address is the same as ISENSE #8)
        self.reg.cp_dac_i2c_en = 1  # disable DAC I2C level shifter
        time.sleep(0.05)
        return (current, voltage, current_valid, voltage_valid)
